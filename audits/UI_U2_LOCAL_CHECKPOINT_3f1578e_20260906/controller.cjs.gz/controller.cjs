const fs=require('node:fs'),p=require('node:path'),cp=require('node:child_process'),c=require('node:crypto');
const owned='/Users/nick/Projects/celestial-frontier-openai-mac',expectedSource=process.argv[2],short=expectedSource?.slice(0,7),base='/private/tmp/cf-u2-checkpoint-'+short+'-20260906',candidate=p.join(base,'candidate');
const git=(args,cwd=owned)=>cp.execFileSync('git',args,{cwd,encoding:'utf8'}).trim();
const source=git(['rev-parse','HEAD']);if(source!==expectedSource)throw Error('unexpected correction source');
fs.mkdirSync(base);fs.copyFileSync(__filename,p.join(base,'controller.cjs'));const hash=b=>c.createHash('sha256').update(b).digest('hex'),ambientHash=hash(fs.readFileSync(p.join(owned,'.DS_Store')));
const state={schema:'cf-u2-local-validation-execution/v1',source,ownedWorkspace:owned,testArtifact:candidate,startedAt:new Date().toISOString(),status:'running',ambientSha256:ambientHash,stages:[],hostedActions:0};
function save(){fs.writeFileSync(p.join(base,'execution.json'),JSON.stringify(state,null,2)+'\n');}
function stage(name,cmd,args,cwd=owned,extraEnv={}){const record={name,command:[cmd,...args],cwd,startedAt:new Date().toISOString(),status:'running',log:name+'.log'};state.stages.push(record);save();console.log(name+' started');const fd=fs.openSync(p.join(base,record.log),'wx');let result;try{result=cp.spawnSync(cmd,args,{cwd,env:{...process.env,...extraEnv},stdio:['ignore',fd,fd]});}finally{fs.closeSync(fd);}record.endedAt=new Date().toISOString();record.exitCode=result.status;record.signal=result.signal;record.error=result.error?.message??null;record.status=result.status===0&&!result.error?'pass':'fail';save();console.log(name+' '+record.status);if(record.status!=='pass')throw Error(name+' stopped: '+JSON.stringify({status:result.status,signal:result.signal,error:record.error}));}
function clean(){if(git(['rev-parse','HEAD'],candidate)!==source||git(['branch','--show-current'],candidate)!=='openai/mac'||git(['status','--porcelain=v1','--untracked-files=all'],candidate)||fs.existsSync(p.join(candidate,'main.js')))throw Error('candidate source cleanliness/identity changed');}
try{
  stage('signature','git',['-c','gpg.ssh.allowedSignersFile=/private/tmp/cf-u1-navigation-allowed-signers','verify-commit',source]);
  stage('clone','git',['clone','--no-local','--single-branch','--branch','openai/mac',owned,candidate]);clean();
  stage('root-install','npm',['ci','--offline','--no-audit','--no-fund'],candidate);
  stage('v2-install','npm',['ci','--offline','--no-audit','--no-fund'],p.join(candidate,'port/v2'));clean();
  const env={CF_BROWSER:'/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'},sliceId='local-u2-'+short+'-20260906-slice';
  state.runIds={slice:sliceId,small:'local-u2-'+short+'-20260906-small-phone',large:'local-u2-'+short+'-20260906-large-phone'};save();
  const productSource='8015ee4ff257b9c12db4eec2ff37808ec38d06ad',changed=git(['diff','--name-only',productSource,source,'--','port/v2/apps/game','port/v2/packages','port/v2/version.json']).split('\n').filter(Boolean),allowed=['port/v2/apps/game/src/sheet-layout.ts','port/v2/apps/game/src/ui-sheet-style.ts','port/v2/apps/game/src/release-content.ts'];if(changed.length!==allowed.length||changed.some(file=>!allowed.includes(file)))throw Error('generic capacity correction product scope mismatch');state.productSource=productSource;state.changedProduct=changed;
  state.visualPredecessor={source:'56648b27b9063132ef01c08ffa8a683d9f45dc25',manifest:'audits/UI_U2_LOCAL_CHECKPOINT_56648b2_20260906/manifest.json',scope:'retained20-row/60PNG normal Settings and standalone-lane proof; new generic sheet and standalone Planetside pressure use canonical native phone outcome checks, not repeated unchanged Settings review'};save();
  stage('static-develop',process.execPath,[p.join(candidate,'port/v2/tools/check-profile.mjs'),'--profile=develop']);clean();
  stage('small-phone',process.execPath,[p.join(candidate,'port/v2/tools/glassmatrix.mjs'),'--viewport=small-phone'],owned,{...env,CF_V2_GLASSMATRIX_RUN_ID:state.runIds.small});clean();
  stage('large-phone',process.execPath,[p.join(candidate,'port/v2/tools/glassmatrix.mjs'),'--viewport=large-phone'],owned,{...env,CF_V2_GLASSMATRIX_RUN_ID:state.runIds.large});clean();
  stage('slice',process.execPath,[p.join(candidate,'port/v2/tools/smokereport.mjs'),'--profile=develop'],owned,{...env,CF_V2_SLICE_SMOKE_RUN_ID:sliceId});clean();
  stage('slice-verify',process.execPath,[p.join(candidate,'port/v2/tools/smokereport.mjs'),'--verify-run='+sliceId,'--profile=develop']);clean();
  if(hash(fs.readFileSync(p.join(owned,'.DS_Store')))!==ambientHash)throw Error('original ambient file changed');
  if(git(['rev-parse','HEAD'])!==source||git(['diff','--name-only','HEAD']))throw Error('owned source changed during evidence');
  state.status='pass';
}catch(error){state.status='fail';state.failure=String(error);process.exitCode=1;console.error(state.failure);}
finally{state.endedAt=new Date().toISOString();save();console.log('execution '+p.join(base,'execution.json'));}
