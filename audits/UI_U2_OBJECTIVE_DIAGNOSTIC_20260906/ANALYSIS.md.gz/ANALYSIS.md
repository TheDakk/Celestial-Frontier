# U2 Objective/Planetside isolated native diagnostic — qualified result

One browser run completed on source437a3aa08f1e5cb3c1b0b134e02f8cbe92c56204 under the whole-job lock.
This is synthetic DOM presentation with the actual AppChrome, SheetLayout, Panels and current CSS owners.
It is not the retained Glass state, not a U2 checkpoint retry, and not certification. No product edits.

The settled fixture has Objective[148,60,310,276.5], Planetside[12,254,252.859375,326],
Planetside72px, published surface-chrome-bottom284.5 and sheet floor326. The intended upper start
292.5 leaves33.5px before that floor, so the existing72px floor cannot fit. Its rendered strip
therefore overlaps the Objective by22.5px even after font readiness and two animation frames.
The Objective centre(229,168.25) remains hittable; this does NOT reproduce the original centre
collision(229,191.44) with its262.88px-high Objective. The retained report lacks actual toast,
Planetside and published lane values; no values for those original objects are inferred here.

The first post-Close sample already has updated top-chrome variables; the SheetLayout height
receipt changes180→72 by the two-frame sample, while actual strip geometry stays254→326.
This native dispatched event's callback ordering is not identical to Glass's synchronous
Runtime.evaluate panelCloseOutcome close.click() path, so it does not isolate that path's
pre-microtask instant.

LIMITATION FOUND AFTER THE ONE RUN: generated index.html omitted meta charset (and the local
server supplied no HTML charset), so the static HTML emoji decoded incorrectly. The TS module's
Objective, hint/context and Planetside strings are UTF-8 and intact; static shell icon text is not.
Retain all raw files unchanged. No correction/rerun was attempted. This qualified fixture can
show a persistent capacity mechanism, but cannot close437's cause or justify a specific product fix.

Next bounded evidence should wrap the original Charters Close owner and opener audit: retain
same-task post-close, microtask, named fonts→two-rAF, then atomic settled hit/geometry. Include
full body classes, objective text/font/rect, topbar rect/offsetHeight, Planetside/header rect,
hint/context/dock/toast rect and display/opacity, toast text/serial/inline target, document/body
scroll, all published floor/top variables, panel/card/mode and exact opener focus. Preserve the
same live toast identity/paint condition across any settlement so expiry cannot launder the red.
No geometry threshold,72px useful strip or44px target should change before that evidence.

/private/tmp/cf-u2-objective-native-diagnostic-20260906.mjs — 11050 bytes — SHA256 d33b8724a809be30360d8e63128cff07cd00f310bf492efe018ad87ce3c7b891

/private/tmp/cf-u2-objective-native-diagnostic-20260906.log — 18031 bytes — SHA256 0414036938a8d4150ad340f5d3893ab3fd9cea433d2eeef78095c010c5db8d47

/private/tmp/cf-u2-437a3aa-objective-native-20260906/report.json — 27850 bytes — SHA256 a51adba53960b4ceee9eef47ffb5e4edda740abbe1f6a631d55acbfa5876dd70

/private/tmp/cf-u2-437a3aa-objective-native-20260906/index.html — 67073 bytes — SHA256 18c1694a061e976690004064b761f8d0e7310be38b606afa913ecd6e84b1efeb

/private/tmp/cf-u2-437a3aa-objective-native-20260906/bootstrap.js — 4280 bytes — SHA256 ae86c1629f3ef4a717c93e8b51ad74ce8db75a0fc7f039d552ac92a66d9a64bb

/private/tmp/cf-u2-437a3aa-objective-native-20260906/settled.png — 174990 bytes — SHA256 c140ef5b918957358f8dac9bcc0e1441ab75589c18e8d146bd947d183ba6e1b1
