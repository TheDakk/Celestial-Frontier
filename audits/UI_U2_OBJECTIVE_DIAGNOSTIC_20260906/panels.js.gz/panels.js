const PANELS = [];
const MODAL_SEL = "#importsheet,#inventorysheet";
/* Fixed and dynamic non-dismiss chrome declares this ownership on its own
root. Search intentionally remains outside this set until the later panel-
coexistence/Escape policy decides otherwise; true modals stay separate. */
const PANEL_BOUNDARY_SEL = "[data-panel-boundary]";
export function registerPanel(def) {
	PANELS.push(def);
	def.el.style.display = "none";
	def.el.setAttribute("role", "region");
	def.el.setAttribute("aria-hidden", "true");
	for (const button of def.btns || []) {
		if (!button) continue;
		button.setAttribute("aria-controls", def.el.id);
		button.setAttribute("aria-expanded", "false");
	}
	/* the corner ✕ — one per rail panel, first child, survives refills via
	the refill helper below (the game seats it with a MutationObserver;
	the slice's panels refill through fillPanel, which re-seats) */
	seatPnx(def);
}
function seatPnx(def, retained) {
	const existing = [...def.el.querySelectorAll("[data-pnx]")];
	const x = retained || existing[0] || document.createElement("button");
	for (const duplicate of existing) if (duplicate !== x) duplicate.remove();
	x.setAttribute("data-pnx", def.id);
	x.setAttribute("aria-label", "Close " + (def.el.getAttribute("aria-label") || def.id));
	x.textContent = "✕";
	x.classList.add("surface-close", "panel-close", "sheet-close");
	def.el.prepend(x);
	/* Keep both siblings direct: Close geometry and Compendium's virtual list
	depend on that ownership. Style the existing title without copying it. */
	const title = [...def.el.children].find((child) => child.matches("h2,h3"));
	title?.classList.add("sheet-header");
	title?.setAttribute("data-sheet-kind", def.id);
}
/** refill a panel's content WITHOUT losing the sticky ✕ */
export function fillPanel(id, html) {
	const def = PANELS.find((p) => p.id === id);
	if (!def) return;
	const close = def.el.querySelector(":scope > [data-pnx]") || undefined;
	const closeOwnedFocus = close !== undefined && document.activeElement === close;
	close?.remove();
	def.el.innerHTML = html;
	seatPnx(def, close);
	if (closeOwnedFocus) close?.focus({ preventScroll: true });
}
let _opener = null;
let _pendingOpener = null;
/* Pointer activation does not focus buttons consistently on every desktop
browser. One capture owner records the exact registered opener before the
shared bubble toggle owner runs. Per-opener closures made listener count
grow with every new panel even while every panel was closed. */
document.addEventListener("click", (event) => {
	const target = event.target;
	if (!(target instanceof Element)) return;
	for (const panel of PANELS) {
		for (const button of panel.btns || []) {
			if (button?.contains(target)) {
				_pendingOpener = button;
				return;
			}
		}
	}
}, true);
function focusIfRendered(target) {
	if (!target?.isConnected || target.inert || target.getClientRects().length === 0) return false;
	const style = getComputedStyle(target);
	if (style.display === "none" || style.visibility === "hidden") return false;
	try {
		target.focus();
	} catch {
		return false;
	}
	return document.activeElement === target;
}
function restorePanelFocus() {
	/* A visible right-rail opener can become hidden when Survey reopens while
	its panel is still up. Never strand focus on the detached/hidden close:
	return to that newly active Survey control, then the exploration canvas. */
	if (focusIfRendered(_opener)) return;
	if (focusIfRendered(document.getElementById("docksurvey"))) return;
	focusIfRendered(document.querySelector("canvas"));
}
export function openPanel(id, opener) {
	const active = document.activeElement instanceof HTMLElement && document.activeElement !== document.body ? document.activeElement : null;
	_opener = opener === undefined ? _pendingOpener || active : opener;
	_pendingOpener = null;
	closePanels(id);
	const def = PANELS.find((p) => p.id === id);
	if (!def) return false;
	const wasVisible = def.el.style.display !== "none";
	if (!wasVisible) def.onOpen?.();
	def.el.style.display = "block";
	document.body.classList.add("panel-open");
	def.el.setAttribute("aria-hidden", "false");
	for (const b of def.btns || []) {
		b?.classList.add("on", "sel");
		b?.setAttribute("aria-expanded", "true");
	}
	/* Panels are non-modal regions, but keyboard users still need a reliable
	entry point. Focus the sticky close control; closing restores the exact
	opener captured above. */
	def.el.querySelector("[data-pnx]")?.focus();
	return !wasVisible;
}
/**
* A content-bearing panel sometimes has two entry paths: an ordinary open
* that uses its default `onOpen` population, and an explicit request (for
* example, a name-filtered Compendium). Stage the request through the real
* hidden -> visible lifecycle; if the panel is already visible, refresh it
* directly. Either route invokes `populate` exactly once.
*/
export function createPanelOpenController(options) {
	let staged = null;
	const onOpen = () => {
		const request = staged ? staged.request : options.defaultRequest();
		/* Consume before population so a nested action cannot accidentally reuse
		the outer request. */
		staged = null;
		options.populate(request);
	};
	const present = (request, opener) => {
		staged = { request };
		let transitioned = false;
		try {
			transitioned = openPanel(options.id, opener);
		} finally {
			staged = null;
		}
		if (!transitioned && openPanelId() === options.id) options.populate(request);
	};
	return Object.freeze({
		onOpen,
		present
	});
}
export function closePanels(except) {
	for (const p of PANELS) {
		if (p.id === except) continue;
		const wasVisible = p.el.style.display !== "none";
		p.el.style.display = "none";
		p.el.setAttribute("aria-hidden", "true");
		for (const b of p.btns || []) {
			b?.classList.remove("on", "sel");
			b?.setAttribute("aria-expanded", "false");
		}
		if (wasVisible) p.onClose?.();
	}
	document.body.classList.toggle("panel-open", PANELS.some((p) => p.el.style.display !== "none"));
	if (!except && _opener) {
		restorePanelFocus();
		_opener = null;
	}
}
export function togglePanel(id) {
	const def = PANELS.find((p) => p.id === id);
	if (!def) return;
	if (def.el.style.display === "none") openPanel(id);
	else {
		_pendingOpener = null;
		closePanels();
	}
}
export function openPanelId() {
	const p = PANELS.find((q) => q.el.style.display !== "none");
	return p ? p.id : null;
}
/* Every registered opener shares one bubble owner. This pairs with the
capture-phase focus lineage above and prevents closed panels from retaining
one dormant closure per dock/rail copy. */
document.addEventListener("click", (event) => {
	const target = event.target;
	if (!(target instanceof Element)) return;
	for (const panel of PANELS) {
		for (const button of panel.btns || []) {
			if (button?.contains(target)) {
				togglePanel(panel.id);
				return;
			}
		}
	}
});
/* tap-empty-to-close + the delegated corner ✕ (main.js 16056/16070) */
document.addEventListener("pointerdown", (e) => {
	const t = e.target;
	if (!(t instanceof Element)) return;
	if (t.closest(MODAL_SEL)) return;
	for (const p of PANELS) {
		if (p.el.contains(t)) return;
		for (const b of p.btns || []) if (b && b.contains(t)) return;
	}
	if (t.closest(PANEL_BOUNDARY_SEL)) return;
	closePanels();
});
document.addEventListener("click", (e) => {
	const target = e.target;
	if (!(target instanceof Element)) return;
	const x = target.closest("[data-pnx]");
	if (x) closePanels();
});
