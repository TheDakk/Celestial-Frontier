from pathlib import Path
p=Path('/Users/nick/Projects/celestial-frontier-openai-mac/port/v2/tools/glassmatrix.mjs')
s=p.read_text();start=s.index('        /* With the card closed, the living-world strip');end=s.index("        await evalIn(`(()=>{ const b=document.getElementById('dockguide');",start);r=s[start:end]
def rep(a,b):
 global r
 assert r.count(a)==1,(r.count(a),a[:100]);r=r.replace(a,b,1)
rep("""        await evalIn(`document.getElementById('docksurvey')?.click()`);
        await waitFor('survey closed for top-chrome clearance', `!window.__CF_SLICE__.api.state().cardOpen`);""", """        const topChromeFrameOwner = `(async(label)=>{const read=${readReviewFrameSettlements.toString()},prior=read()?.invocations?.at(-1)?.id??0;
          await (${reviewFrameSettlement.toString()})(label);const frames=read();
          return {label,expectedFrameId:prior+1,frame:frames?.invocations?.at(-1)??null,overflow:frames?.overflow??true};})`;
        const topChromeFrameValid = receipt => {
          const assessed=assessReviewFrameSettlement(receipt?.frame,vp);
          return {ok:assessed.pass&&receipt?.frame?.label===receipt?.label&&receipt?.frame?.id===receipt?.expectedFrameId&&receipt?.overflow===false,
            receipt,assessment:assessed};
        };
        const closeSurveyForTopChrome = async () => {
          const read=`(()=>{const state=window.__CF_SLICE__?.api?.state?.();return {cardOpen:state?.cardOpen??null,panelOpen:state?.panelOpen??null};})()`;
          const before=await evalIn(read);let activation=null;
          if(typeof before?.cardOpen!=='boolean')stopInstrumentControl(`${vp.label}: malformed Survey close predecessor (${JSON.stringify(before)})`);
          if(before.cardOpen){
            activation=await activateRealControl('#docksurvey','post-close top-chrome native Survey close');
            if(!activation?.ok)stopInstrumentControl(`${vp.label}: native Survey close input refused (${JSON.stringify({before,activation})})`);
          }
          const after=await evalIn(read);
          if(after?.cardOpen!==false)stopInstrumentControl(`${vp.label}: native Survey close did not leave the card closed (${JSON.stringify({before,activation,after})})`);
          const settlement=await evalIn(`${topChromeFrameOwner}('post-close.top-chrome.fonts-two-frames')`);
          const checked=topChromeFrameValid(settlement),settled=await evalIn(read);
          if(!checked.ok||settled?.cardOpen!==false)stopInstrumentControl(`${vp.label}: post-close top-chrome settlement failed (${JSON.stringify({before,activation,after,settled,checked})})`);
          return {before,activation,after,settled,settlement};
        };
        const topChromeClose = await closeSurveyForTopChrome();
        // Painted owner geometry differs from AppChrome's conservative wrapper
        // variable below. A pointer-transparent wrapper adds no empty padding.
        const topChromeFixedRows = `(()=>{const header=document.getElementById('topbar'),nodes=[...new Set([header,...(header?.children??[]),
          ...['searchbox','objchip','sceneactions'].map(id=>document.getElementById(id))])].filter(Boolean);
          return nodes.map(el=>{const r=el.getBoundingClientRect(),s=getComputedStyle(el),excluded=el===header&&s.pointerEvents==='none',
            visible=!excluded&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||'1')>0&&r.width>0&&r.height>0;
            return {id:el.id,visible,excluded,opacity:Number(s.opacity||'1'),rect:[r.left,r.top,r.right,r.bottom],bottom:r.bottom};});})()`;""")
rep("return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0?r.bottom:0;", "return s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||'1')>0&&r.width>0&&r.height>0?r.bottom:0;")
rep("        const chromeRestoreBaseline = await evalIn(chromeRestoreCheck);", "        const chromeRestoreBaseline = {...await evalIn(chromeRestoreCheck),precondition:topChromeClose};")
rep("""              fixedRows=['topbar','searchbox','objchip','sceneactions'].map(id=>{const el=document.getElementById(id),r=el?.getBoundingClientRect(),s=el?getComputedStyle(el):null;
                return {id,visible:!!r&&s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0,bottom:r?.bottom??null};}),""", "              fixedRows=${topChromeFixedRows},")
rep("const trailVisible=ts.display!=='none'&&ts.visibility!=='hidden'&&t.width>0&&t.height>0,", "const trailVisible=ts.display!=='none'&&ts.visibility!=='hidden'&&Number(ts.opacity||'1')>0&&t.width>0&&t.height>0,")
rep("""            const portraitControls = await evalIn(`(()=>{const trail=document.getElementById('trail'),header=document.getElementById('topbar'),""", """            const portraitControls = await evalIn(`(async()=>{const trail=document.getElementById('trail'),header=document.getElementById('topbar'),
              settlements=[],cleanupErrors=[],settle=async label=>{const receipt=await ${topChromeFrameOwner}(label);settlements.push(receipt);return receipt;},""")
rep("""                window.dispatchEvent(new Event('resize'));
                const injectedBaseline=${portraitBandCheck},injectedRect=trail.getBoundingClientRect();""", """                window.dispatchEvent(new Event('resize'));await settle('portrait.fixture.injected.fonts-two-frames');
                const injectedBaseline=${portraitBandCheck},injectedRect=trail.getBoundingClientRect();""")
rep("                band=(()=>{ const side=", "                band=await (async()=>{ const side=")
rep("""              try{side.style.setProperty('transform',requested,'important');mutation={requested,""", """              try{side.style.setProperty('transform',requested,'important');await settle('portrait.band.mutated.fonts-two-frames');mutation={requested,""")
rep("""              finally{if(prior.value===''&&prior.priority==='')side.style.removeProperty('transform');else side.style.setProperty('transform',prior.value,prior.priority);}
              const restored={property:{value:side.style.getPropertyValue('transform')""", """              finally{if(prior.value===''&&prior.priority==='')side.style.removeProperty('transform');else side.style.setProperty('transform',prior.value,prior.priority);
                try{await settle('portrait.band.restored.fonts-two-frames');}catch(cause){cleanupErrors.push(String(cause?.message||cause));}}
              const restored={property:{value:side.style.getPropertyValue('transform')""")
rep("                fallback=(()=>{ const root=", "                fallback=await (async()=>{ const root=")
rep("""              try{root.style.setProperty('--safe-bottom',requested,'important');window.dispatchEvent(new Event('resize'));
                const a=""", """              try{root.style.setProperty('--safe-bottom',requested,'important');window.dispatchEvent(new Event('resize'));await settle('portrait.fallback.mutated.fonts-two-frames');
                const a=""")
rep("visible=s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0;return {id,visible,gap:a.top-r.bottom};}),", "visible=s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||'1')>0&&r.width>0&&r.height>0;return {id,visible,gap:a.top-r.bottom};}),")
rep("""                  fixedClear=fixedRows.every(row=>!row.visible||row.gap>=5.5),outcome={ok:fallback&&ts.display==='none'&&meaningful&&scrollOk&&fixedClear,fallback,trailDisplay:ts.display,meaningful,scrollOk,side:[a.left,a.top,a.right,a.bottom],trail:[t.left,t.top,t.right,t.bottom],clientHeight:side.clientHeight,scrollHeight:side.scrollHeight,overflowY:ss.overflowY,fixedClear,fixedRows,baseSafe,forcedSafe};""", """                  actualFixedRows=${topChromeFixedRows},fixedClear=fixedRows.every(row=>!row.visible||row.gap>=5.5)&&actualFixedRows.every(row=>!row.visible||a.top-row.bottom>=5.5),
                  outcome={ok:fallback&&ts.display==='none'&&meaningful&&scrollOk&&fixedClear,fallback,trailDisplay:ts.display,meaningful,scrollOk,side:[a.left,a.top,a.right,a.bottom],trail:[t.left,t.top,t.right,t.bottom],clientHeight:side.clientHeight,scrollHeight:side.scrollHeight,overflowY:ss.overflowY,fixedClear,fixedRows,actualFixedRows,baseSafe,forcedSafe};""")
rep("""              finally{if(prior.value===''&&prior.priority==='')root.style.removeProperty('--safe-bottom');else root.style.setProperty('--safe-bottom',prior.value,prior.priority);window.dispatchEvent(new Event('resize'));}""", """              finally{if(prior.value===''&&prior.priority==='')root.style.removeProperty('--safe-bottom');else root.style.setProperty('--safe-bottom',prior.value,prior.priority);window.dispatchEvent(new Event('resize'));
                try{await settle('portrait.fallback.restored.fonts-two-frames');}catch(cause){cleanupErrors.push(String(cause?.message||cause));}}""")
rep("""                const h=header.getBoundingClientRect();trail.style.setProperty('display','flex');""", """                try{const h=header.getBoundingClientRect();trail.style.setProperty('display','flex');""")
rep("""                window.dispatchEvent(new Event('resize'));const c=trail.getBoundingClientRect();""", """                window.dispatchEvent(new Event('resize'));await settle('portrait.fixture.cleanup-contained.fonts-two-frames');const c=trail.getBoundingClientRect();""")
rep("""                    &&c.left>=h.left-1&&c.right<=h.right+1&&c.top>=h.top-1&&c.bottom<=h.bottom+1};
                trail.setAttribute('style','');trail.removeAttribute('style');if(originalStyle.present)trail.setAttribute('style',originalStyle.value);
                window.dispatchEvent(new Event('resize'));
              }
              const restoredStyle=""", """                    &&c.left>=h.left-1&&c.right<=h.right+1&&c.top>=h.top-1&&c.bottom<=h.bottom+1};
                }catch(cause){cleanupErrors.push(String(cause?.message||cause));}
                finally{trail.setAttribute('style','');trail.removeAttribute('style');if(originalStyle.present)trail.setAttribute('style',originalStyle.value);
                  window.dispatchEvent(new Event('resize'));
                  try{await settle('portrait.fixture.native-restored.fonts-two-frames');}catch(cause){cleanupErrors.push(String(cause?.message||cause));}}
              }
              error??=cleanupErrors[0]??null;
              const restoredStyle=""")
rep("""                witness={...fixture,restoredStyle,nativeRestored,cleanup,error};
              return {band:{...band,fixture:witness,error},fallback:{...fallback,fixture:witness,error}};})()`);
            const bandControlAssessment=""", """                witness={...fixture,restoredStyle,nativeRestored,cleanup,error,cleanupErrors};
              return {band:{...band,fixture:witness,error},fallback:{...fallback,fixture:witness,error},settlements};})()`);
            const expectedSettlements=['portrait.fixture.injected','portrait.band.mutated','portrait.band.restored','portrait.fallback.mutated',
              'portrait.fallback.restored','portrait.fixture.cleanup-contained','portrait.fixture.native-restored'].map(label=>label+'.fonts-two-frames');
            const settlementChecks=portraitControls.settlements?.map(topChromeFrameValid)??[];
            if(JSON.stringify(portraitControls.settlements?.map(row=>row.label))!==JSON.stringify(expectedSettlements)||settlementChecks.some(row=>!row.ok))
              stopInstrumentControl(`${vp.label}: portrait fixture settlement evidence failed (${JSON.stringify({portraitControls,settlementChecks})})`);
            const bandControlAssessment=""")
rep("""          const rows=['playerchip','hpbar','searchbox','trail','objchip','sceneactions'].map(id=>{const el=document.getElementById(id),s=el?getComputedStyle(el):null,r=el?.getBoundingClientRect();
            const visible=!!el&&s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0;
            const overlap=visible&&a.left<r.right-1&&a.right>r.left+1&&a.top<r.bottom-1&&a.bottom>r.top+1;
            return {id,visible,overlap,rect:r?[r.left,r.top,r.right,r.bottom]:null};});return {ok:rows.every(r=>!r.overlap),side:[a.left,a.top,a.right,a.bottom],rows};})()`;""", """          const rows=${topChromeFixedRows}.map(row=>{const r=row.rect;
            return {...row,overlap:row.visible&&a.left<r[2]-1&&a.right>r[0]+1&&a.top<r[3]-1&&a.bottom>r[1]+1};});
          return {ok:rows.every(r=>!r.overlap),side:[a.left,a.top,a.right,a.bottom],rows};})()`;""")
assert s.count(s[start:end])==1
out=s[:start]+r+s[end:];t=p.with_suffix('.mjs.tmp');t.write_text(out);t.replace(p)
