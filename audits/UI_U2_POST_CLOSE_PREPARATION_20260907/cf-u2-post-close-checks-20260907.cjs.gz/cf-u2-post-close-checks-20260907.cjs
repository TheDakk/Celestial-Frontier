const cp=require('node:child_process');
for(const [name,command,args] of [
 ['syntax',process.execPath,['--check','port/v2/tools/glassmatrix.mjs']],
 ['runner-syntax',process.execPath,['--check','/private/tmp/cf-u2-run-post-close-20260907.cjs']],
 ['focused','npm',['--prefix','port/v2','test','--','tests/glass-survey-post-close.test.ts','tests/glass-post-close-geometry.test.ts','tests/glass-guidance-preference.test.ts','tests/glass-charters-settlement.test.ts','tests/glass-survey-settlement.test.ts','tests/glass-sticky-header-scroll.test.ts','tests/sheet-layout.test.ts']],
 ['typecheck','npm',['--prefix','port/v2','run','typecheck']],
 ['root-validate',process.execPath,['tools/validate.js']],
]){console.log('U2 POST-CLOSE '+name);const r=cp.spawnSync(command,args,{stdio:'inherit'});if(r.status!==0||r.error){console.error('STOP '+name);process.exit(r.status||1);}}
