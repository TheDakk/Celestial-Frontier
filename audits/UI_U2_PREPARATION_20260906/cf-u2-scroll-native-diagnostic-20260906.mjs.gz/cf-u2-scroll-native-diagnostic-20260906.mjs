import fs from 'node:fs';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { openChromiumCdp } from '/Users/nick/Projects/celestial-frontier-openai-mac/port/v2/tools/browsercdp.mjs';
const root='/Users/nick/Projects/celestial-frontier-openai-mac',out='/private/tmp/cf-u2-scroll-native-diagnostic-20260906.json';
assert(!fs.existsSync(out));const source=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
assert.equal(source,'2dba37946ef73d8d67e3aa9cdd8771ca5d541132');
const glass=fs.readFileSync(root+'/port/v2/tools/glassmatrix.mjs','utf8'),a='  const setExactScrollPosition = (owner, left, top) => {',b='  const scrollControlIntoView = (el, root, viewport, rememberScroll = null) => {';
assert.equal(glass.split(a).length,2);assert.equal(glass.split(b).length,2);
const current=glass.slice(glass.indexOf(a),glass.indexOf(b));
assert.equal(current.split("owner.style.cssText = '';").length,2);
const proposed=current.replace("owner.style.cssText = '';","owner.setAttribute('style', '');");
const report={source,kind:'synthetic isolated native CSSOM diagnostic, not a game checkpoint',strategies:{current,proposed},rows:[],status:'running'};
let browser;
try{
 browser=await openChromiumCdp({label:'U2 isolated scroll style diagnostic',userDataPrefix:'cf-u2-scroll-style'});report.browser=browser.browser;
 const {targetId}=await browser.send('Target.createTarget',{url:'about:blank'}),{sessionId}=await browser.send('Target.attachToTarget',{targetId,flatten:true});
 for(const [strategy,implementation] of Object.entries({current,proposed}))for(const prior of [null,'','color: red; scroll-behavior: smooth !important; transform: none;']){
  const expression=`(()=>{document.body.innerHTML='<style>#card { height: 100px; width:240px; overflow:auto; }</style><section id="card"><div style="height:1000px">synthetic scroll owner</div></section>';const owner=document.getElementById('card'),prior=${JSON.stringify(prior)};if(prior!==null)owner.setAttribute('style',prior);const selectorName=n=>n.id;${implementation}\nconst before={style:owner.getAttribute('style'),scrollTop:owner.scrollTop};let result,error;try{result=setExactScrollPosition(owner,0,77);}catch(e){error=String(e);}const after={style:owner.getAttribute('style'),scrollTop:owner.scrollTop,computed:getComputedStyle(owner).scrollBehavior};return{before,result:result??null,error:error??null,after};})()`;
  const r=await browser.send('Runtime.evaluate',{expression,returnByValue:true},sessionId);assert(!r.exceptionDetails,JSON.stringify(r.exceptionDetails));report.rows.push({strategy,prior,expression,result:r.result.value});fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');
 }
 report.status='complete';
}catch(e){report.status='fail';report.error=String(e);process.exitCode=1;}
finally{if(browser)await browser.close();fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify({status:report.status,rows:report.rows.map(({strategy,prior,result})=>({strategy,prior,...result}))},null,2));
