import fs from 'node:fs';
import crypto from 'node:crypto';
import {compendiumProducerAuthority} from '/Users/nick/Projects/celestial-frontier-openai-mac/port/v2/tools/compendiummem-contract.mjs';
import {findCandidateSpeciesArtBuildGraph} from '/Users/nick/Projects/celestial-frontier-openai-mac/port/v2/tools/speciesart-build.mjs';
const root='/Users/nick/Projects/celestial-frontier-openai-mac',dist=root+'/port/v2/apps/game/dist';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function write(rel,old,next){const p=root+'/'+rel;if(fs.readFileSync(p,'utf8')!==old||old===next)throw Error('changed or unchanged '+rel);fs.writeFileSync(p+'.u2tmp',next,{flag:'wx'});fs.renameSync(p+'.u2tmp',p);}
function once(s,a,b){if(s.split(a).length!==2)throw Error('nonunique '+a);return s.replace(a,b);}
const graph={index:{relativePath:'index.html',sha256:sha(fs.readFileSync(dist+'/index.html'))},...findCandidateSpeciesArtBuildGraph(dist),serviceWorker:{relativePath:'service-worker.js',sha256:sha(fs.readFileSync(dist+'/service-worker.js'))}};
const authority=compendiumProducerAuthority(graph),rel='port/v2/budgets/compendium-memory-v1.json',old=fs.readFileSync(root+'/'+rel,'utf8'),budget=JSON.parse(old),previous=budget.producerAuthority;
if(previous.sha256!=='fc32587d6affa2b3cf10ef7175f722863ecd1cfb34f182bb7f3cb0ad09194ad7')throw Error('wrong preceding authority');
budget.producerAuthority=authority;budget.calibration.selectionRule += ' U2 landed guidance accessibility refinement (2026-09-06): producer '+previous.sha256+' becomes '+authority.sha256+'. Clipped one-pixel scene guidance remains available to assistive technology and is explicitly excluded from lane measurements while yielded. Native measurement is restored before every capacity decision. '+Object.entries(graph).map(([k,v])=>k+' '+v.relativePath+' '+v.sha256).join('; ')+'. Measurement/ruler/ceilings/history unchanged. Native verification pending; no fresh Compendium certification claimed.';
write(rel,old,JSON.stringify(budget,null,2)+'\n');
const test='port/v2/tests/compendium-budget.test.ts',testOld=fs.readFileSync(root+'/'+test,'utf8');let next=once(testOld,previous.sha256,authority.sha256);for(const k of Object.keys(graph)){const a=previous.inputs[k],b=graph[k];if(a.relativePath!==b.relativePath)next=once(next,a.relativePath,b.relativePath);if(a.sha256!==b.sha256)next=once(next,a.sha256,b.sha256);}write(test,testOld,next);
const receipt={previous:previous.sha256,authority,draftCount:81,draftSha256:'8b9e5246cfd4c9b365cfc487a468777b6f6db7c5f90c6e5865ddba594920b475',measurementUnchanged:true,ceilingsUnchanged:true};fs.writeFileSync('/private/tmp/cf-u2-landed-accessibility-producer-20260906.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({producer:authority.sha256},null,2));
