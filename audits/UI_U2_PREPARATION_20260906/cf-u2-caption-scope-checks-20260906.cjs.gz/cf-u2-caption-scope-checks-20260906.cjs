const cp=require('node:child_process');
for(const [name,command,args] of [
 ['focused','npm',['--prefix','port/v2','test','--','tests/glass-guidance-preference.test.ts','tests/glass-charters-settlement.test.ts','tests/glass-survey-settlement.test.ts','tests/glass-sticky-header-scroll.test.ts']],
 ['typecheck','npm',['--prefix','port/v2','run','typecheck']],
 ['root-validate',process.execPath,['tools/validate.js']],
]){console.log('U2 CAPTION '+name);const r=cp.spawnSync(command,args,{stdio:'inherit'});if(r.status!==0||r.error){console.error('STOP '+name);process.exit(r.status||1);}}
