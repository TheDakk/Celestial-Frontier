const cp=require('node:child_process');
const steps=[
 ['focused','npm',['--prefix','port/v2','test','--','tests/sheet-layout.test.ts','tests/panels.test.ts','tests/glass-charters-settlement.test.ts','tests/glass-survey-settlement.test.ts','tests/glass-sticky-header-scroll.test.ts','tests/glass-guidance-preference.test.ts']],
 ['typecheck','npm',['--prefix','port/v2','run','typecheck']],
 ['root-validate',process.execPath,['tools/validate.js']],
 ['evidence-build','npm',['--prefix','port/v2/apps/game','run','build','--','--mode','evidence']],
 ['producer-pins',process.execPath,['/private/tmp/cf-u2-generic-capacity-producer-20260906.mjs']],
 ['pin-checks','npm',['--prefix','port/v2','test','--','tests/compendium-budget.test.ts','tests/guide-release.test.ts','tests/evidence-chain-tools.test.ts','tests/slicesmoke-sixth-red-contract.test.ts']],
];
for(const [name,command,args] of steps){console.log('U2 PREPARATION '+name);const result=cp.spawnSync(command,args,{stdio:'inherit'});if(result.status!==0||result.error){console.error('STOP '+name+': '+JSON.stringify({status:result.status,signal:result.signal,error:result.error?.message}));process.exit(result.status||1);}}
