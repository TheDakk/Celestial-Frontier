# U3 Charters — temporary presentation proposal

Prepared 2026-09-06 by OpenAI/Codex on macOS in the owned `openai/mac` workspace.
This bundle is **not applied, built, tested, rendered or checkpoint evidence**.
It is reserved for the Charters step after the Shipyard, Star Atlas and Compendium checkpoints.
No checkout file was changed by this preparation.

## Proposed change

One scoped CSS addition to the last inline style in `port/v2/apps/game/index.html`:
current-expedition and Starter Charter cards, wrapping progress rows, an active-count
pill and fitted Accept buttons. Existing state attributes add border accents; all
state wording stays visible. Phone goals stack below their labels at 480px and
below, while the existing 400px full-width Accept layout remains in force.
Forced-colors uses system surface/border colors. Product emoji stay unchanged.

No renderer, identifier, content, ordering, reward, progression, Accept transaction,
focus, ARIA, panel dimension, scroll owner, animation or shared U2 header/Close change.
The board-protected and weekly boundary text retain their real current projections.
The useful null-objective Charters opener also remains unchanged.

## Files and application

- `charters.css`: proposed scoped rules (all selectors rooted in `#chpanel`).
- `index.before.html`, `index.proposed.html`: preparation snapshots for review only.
- `charters.patch`: exact unified difference between those snapshots.
- `manifest.json`: current source identity and guard hashes.
- `apply.py`: default read-only authority check; explicit `--apply` makes an exact
  unique-anchor replacement on a temporary copy and atomically replaces only the HTML.

When this ordered checkpoint is reached, review current source first. From the owned
repository, `python3 /private/tmp/cf-u3-charters-prepared-20260906/apply.py` checks guards;
add `--apply` only to apply the reviewed proposal. **Neither command has been run.**
The guards permit unrelated HTML additions but refuse a changed Charters renderer,
Charters/Binder base style block, shared sheet/panel owner or tokens. Earlier U3 work
may cause that refusal; re-review and refresh the proposal instead of bypassing it.
Do not copy the whole proposed HTML over a later source file.

## Authority and later verification

The exact U3 brief is `port/UI_PARITY_PROGRAM_U1_U4.md:302–308`: one ordered panel
reskin checkpoint, v1 golden/v2 before/after PNGs, stable IDs and focus through existing
main-wiring tests. It specifies no new Charters features. Current projections are
`main.ts:4189` and `starter-charters.ts:656`; native seating/focus belongs to `panels.ts`.
`UI_PRESENTATION.md` and `QUESTS_AND_CHAPTERS.md` describe presentation and real current
Charter boundaries. The current source supersedes older stale gameplay prose.

At the later checkpoint, parent owns required root validation, focused existing
Starter Charter/main-wiring/panel tests, normal-build native Objective → Charters →
Close focus/scroll evidence, phone/desktop/landscape/large-text bounds and the v1/v2
screenshot comparison. Review accepted, available, progress, completed and protected
markup through existing legitimate owners; this bundle fabricates no populated save
or reward outcome. Include live geometry fault rejection/restoration for new checks.
There is no claim that CSS source inspection proves native layout or accessibility.

Keep the two older U1 causes open: unsolicited navigation and the portrait-restoration
Runtime.evaluate timeout. U2 remains parent's active checkpoint. No hosted actions,
Inkscape, production version or Phase 2 work is included.

Coordination: Codex holds this temporary proposal until the ordered Charters step;
Claude's worktree remains untouched and Nick need not open Claude for this preparation.
