#!/usr/bin/env python3
"""Guarded U3 Charters proposal. Default is read-only; --apply writes one HTML file."""
from pathlib import Path
import argparse, hashlib, json, os, platform, subprocess, tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apply', action='store_true')
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
manifest = json.loads((bundle / 'manifest.json').read_text())
root = Path(manifest['root'])

def require(condition, message):
    if not condition:
        raise SystemExit('REFUSED: ' + message)

def digest(value):
    return hashlib.sha256(value).hexdigest()

require(platform.system() == 'Darwin', 'this proposal is owned by OpenAI/Codex on macOS')
require(Path.cwd().resolve() == root == root.resolve(), 'run from the exact owned physical root')
require(subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], text=True).strip() == str(root), 'Git root mismatch')
require(subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip() == manifest['branch'], 'branch mismatch')
for guard in manifest['guards']:
    data = (root / guard['file']).read_bytes()
    if 'start' in guard:
        text = data.decode('utf-8')
        require(text.count(guard['start']) == text.count(guard['end']) == 1, 'non-unique authority anchor: ' + guard['file'])
        start, end = text.index(guard['start']), text.index(guard['end'])
        require(end > start, 'authority anchor order: ' + guard['file'])
        data = text[start:end].encode('utf-8')
    require(digest(data) == guard['sha256'], 're-review changed authority: ' + guard['file'])
css = (bundle / 'charters.css').read_bytes()
require(digest(css) == manifest['cssSha256'], 'proposal CSS changed')
target = root / manifest['target']
original = target.read_bytes()
text = original.decode('utf-8')
require(text.count(manifest['anchor']) == 1, 'last style anchor must be exact and unique')
require(manifest['marker'] not in text, 'proposal is already present')
require(text.count('<aside id="chpanel" class="glass panel" aria-label="Charters"></aside>') == 1, 'Charters identity changed')
proposed = text.replace(manifest['anchor'], css.decode('utf-8') + manifest['anchor'], 1).encode('utf-8')
receipt = {'mode': 'APPLY' if args.apply else 'READ_ONLY_CHECK', 'target': str(target), 'beforeSha256': digest(original), 'afterSha256': digest(proposed), 'cssSha256': digest(css)}
if args.apply:
    descriptor, name = tempfile.mkstemp(prefix='.charters-u3-', suffix='.tmp', dir=target.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, 'wb') as file:
            file.write(proposed)
        os.chmod(temporary, target.stat().st_mode)
        require(target.read_bytes() == original, 'target changed while preparing its copy')
        os.replace(temporary, target)
        require(target.read_bytes() == proposed, 'applied read-back differs')
    finally:
        if temporary.exists():
            temporary.unlink()
print(json.dumps(receipt, indent=2))
