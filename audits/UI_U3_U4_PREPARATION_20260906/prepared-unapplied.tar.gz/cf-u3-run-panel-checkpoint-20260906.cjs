/* Prepared reusable local U3 runner. NOT EXECUTED during preparation.
 * Under the caller's whole-job lock and approved macOS browser execution:
 * node THIS_FILE CONFIG_JSON
 * Reviewer: node DRIVER CONFIG_JSON NEW_OUTPUT_DIRECTORY -> report.json. */
const fs=require('node:fs'),p=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const configFile=fs.realpathSync(process.argv[2]),config=JSON.parse(fs.readFileSync(configFile,'utf8'));
const owned='/Users/nick/Projects/celestial-frontier-openai-mac',source=config.sourceCommit,panel=config.panel;
const panels=['shipyard','atlas','compendium','charters','records','guide','settings','survey','inventory'];
assert(/^[a-f0-9]{40}$/.test(source)&&panels.includes(panel),'exact signed source and ordered U3 panel required');
const base='/private/tmp/cf-u3-'+panel+'-checkpoint-'+source.slice(0,7)+'-20260906',candidate=p.join(base,'candidate');
assert(!fs.existsSync(base),'one attempt only: prior output is immutable');fs.mkdirSync(base);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const carrier=file=>{const b=fs.readFileSync(file);return{path:file,bytes:b.length,sha256:sha(b)};};
const git=(args,cwd=owned)=>cp.execFileSync('git',args,{cwd,encoding:'utf8'}).trim();
const executionFile=p.join(base,'execution.json'),buildFile=p.join(base,'normal-build-receipt.json');
const state={schema:'cf-u3-panel-validation-execution/v1',source,panel,ownedWorkspace:owned,testArtifact:candidate,
  status:'running',startedAt:new Date().toISOString(),hostedActions:0,stages:[]};
const write=()=>fs.writeFileSync(executionFile,JSON.stringify(state,null,2)+'\n');
const writeNew=(file,value)=>fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const ambient=()=>fs.existsSync(p.join(owned,'.DS_Store'))?carrier(p.join(owned,'.DS_Store')):null;
let lockFile,ownedStatus,beforeFiles;
function ownedGuard(){
  assert.equal(fs.realpathSync(owned),owned);assert.equal(git(['rev-parse','--show-toplevel']),owned);
  assert.equal(git(['branch','--show-current']),'openai/mac');assert.equal(git(['rev-parse','--abbrev-ref','--symbolic-full-name','@{upstream}']),'origin/openai/mac');
  assert.equal(git(['rev-parse','HEAD']),source);assert.equal(git(['diff','--name-only','HEAD']),'');
  if(ownedStatus!==undefined)assert.equal(git(['status','--porcelain=v1','--untracked-files=all']),ownedStatus,'owned status changed');
  if(state.ambient!==undefined)assert.deepEqual(ambient(),state.ambient,'ambient file changed');
  if(state.lock)assert.equal(carrier(lockFile).sha256,state.lock.sha256,'whole-job lock changed');
  if(state.reviewer)assert.equal(carrier(config.reviewer).sha256,state.reviewer.sha256,'reviewer changed');
}
function clean(){
  assert.equal(fs.realpathSync(candidate),candidate);assert.equal(git(['rev-parse','--show-toplevel'],candidate),candidate);
  assert.equal(git(['rev-parse','HEAD'],candidate),source);assert.equal(git(['branch','--show-current'],candidate),'openai/mac');
  assert.equal(git(['status','--porcelain=v1','--untracked-files=all'],candidate),'','candidate must remain completely clean');
  assert(!fs.existsSync(p.join(candidate,'main.js')),'root generated main.js must remain absent');
}
function stage(name,command,args,cwd=owned,extraEnv={}){
  const row={name,command:[command,...args],cwd,startedAt:new Date().toISOString(),status:'running',log:name+'.log'};
  state.stages.push(row);write();console.log(name+' started');const fd=fs.openSync(p.join(base,row.log),'wx');let result;
  try{result=cp.spawnSync(command,args,{cwd,env:{...process.env,...extraEnv},stdio:['ignore',fd,fd]});}finally{fs.closeSync(fd);}
  Object.assign(row,{endedAt:new Date().toISOString(),exitCode:result.status,signal:result.signal,error:result.error?.message??null,
    status:result.status===0&&!result.error?'pass':'fail',carrier:carrier(p.join(base,row.log))});write();console.log(name+' '+row.status);
  assert.equal(row.status,'pass',name+' stopped: '+JSON.stringify({exitCode:row.exitCode,signal:row.signal,error:row.error}));
  ownedGuard();if(fs.existsSync(candidate))clean();
}
function inventory(dir,sub=''){
  return fs.readdirSync(p.join(dir,sub)).sort().flatMap(name=>{const rel=p.join(sub,name),file=p.join(dir,rel),stat=fs.lstatSync(file);
    assert(!stat.isSymbolicLink(),'artifact symlink refused');if(stat.isDirectory())return inventory(dir,rel);
    assert(stat.isFile());const {bytes,sha256}=carrier(file);return[{path:rel,bytes,sha256}];});
}
function admission(receipt,expectedSource){
  assert(['cf-u2-local-validation-execution/v1','cf-u3-panel-validation-execution/v1'].includes(receipt.schema));
  assert.equal(receipt.status,'pass');assert.equal(receipt.source,expectedSource);assert.equal(receipt.hostedActions,0);
  assert(receipt.endedAt&&!receipt.failure&&receipt.stages.every(s=>s.status==='pass'&&s.exitCode===0&&!s.signal&&!s.error));
  let previous=-1;for(const name of ['static-develop','small-phone','large-phone','slice','slice-verify']){
    const matches=receipt.stages.map((s,i)=>s.name===name?i:-1).filter(i=>i>=0);assert.equal(matches.length,1);assert(matches[0]>previous);previous=matches[0];}
  if(panel==='shipyard')assert.equal(receipt.schema,'cf-u2-local-validation-execution/v1');
  else{assert.equal(receipt.schema,'cf-u3-panel-validation-execution/v1');assert.equal(receipt.panel,panels[panels.indexOf(panel)-1]);}
}
(async()=>{try{
  write();assert.equal(process.platform,'darwin');ownedGuard();state.ambient=ambient();
  ownedStatus=git(['status','--porcelain=v1','--untracked-files=all']);assert(ownedStatus===''||ownedStatus==='?? .DS_Store','unexpected owned untracked inputs');
  state.ownedStatus=ownedStatus;state.config=carrier(configFile);state.runner=carrier(fs.realpathSync(__filename));
  fs.copyFileSync(configFile,p.join(base,'input-config.json'));fs.copyFileSync(__filename,p.join(base,'controller.cjs'));
  lockFile='/private/tmp/celestial-frontier-toolchain-'+process.getuid()+'.lock/owner.json';state.lock=carrier(lockFile);
  const lock=JSON.parse(fs.readFileSync(lockFile,'utf8'));let pid=process.ppid,inherited=false;
  for(let depth=0;pid>1&&depth<32;depth++){if(pid===lock.pid){inherited=true;break;}pid=Number(cp.execFileSync('ps',['-o','ppid=','-p',String(pid)],{encoding:'utf8'}).trim());}
  assert(inherited&&typeof lock.token==='string','caller must own the whole-job lock');
  assert(p.isAbsolute(config.reviewer)&&Number.isSafeInteger(config.expectedReviewRows)&&config.expectedReviewRows>0);
  assert.equal(config.reviewSchema,'cf-u3-'+panel+'-normal-review/v1');state.reviewer=carrier(config.reviewer);
  const before=config.before;assert(/^[a-f0-9]{40}$/.test(before.sourceCommit));
  state.beforeAdmission=carrier(fs.realpathSync(before.admissionReceipt));admission(JSON.parse(fs.readFileSync(before.admissionReceipt,'utf8')),before.sourceCommit);
  state.beforeBuild=carrier(fs.realpathSync(before.buildReceipt));const previousBuild=JSON.parse(fs.readFileSync(before.buildReceipt,'utf8'));
  assert.equal(previousBuild.status,'pass');assert.equal(previousBuild.sourceCommit,before.sourceCommit);
  assert.equal(fs.realpathSync(before.directory),previousBuild.directory??previousBuild.before?.directory);
  beforeFiles=inventory(before.directory);assert.deepEqual(beforeFiles,previousBuild.files,'predecessor snapshot differs from its build receipt');
  git(['merge-base','--is-ancestor',before.sourceCommit,source]);write();
  stage('signature','git',['-c','gpg.ssh.allowedSignersFile=/private/tmp/cf-u1-navigation-allowed-signers','verify-commit',source]);
  stage('clone','git',['clone','--no-local','--single-branch','--branch','openai/mac',owned,candidate]);
  state.sourceTree=git(['rev-parse',source+'^{tree}'],candidate);write();
  stage('root-install','npm',['ci','--offline','--no-audit','--no-fund'],candidate);
  stage('v2-install','npm',['ci','--offline','--no-audit','--no-fund'],p.join(candidate,'port/v2'));
  const {assertBuiltGameMode}=await import(pathToFileURL(p.join(candidate,'port/v2/tools/build-mode.mjs')));
  assert.equal(assertBuiltGameMode(before.directory,'distributable'),'distributable');
  stage('normal-build','npm',['run','build','--workspace=@cf/game'],p.join(candidate,'port/v2'));
  const dist=p.join(candidate,'port/v2/apps/game/dist'),snapshot=p.join(base,'normal-dist');assertBuiltGameMode(dist,'distributable');
  const worker=fs.readFileSync(p.join(dist,'service-worker.js'),'utf8'),match=/const ASSETS=Object\.freeze\((\[[^\n]+\])\);/u.exec(worker);assert(match,'native asset inventory missing');
  const assets=JSON.parse(match[1]);assert(assets.length>0);for(const a of assets){const file=fs.realpathSync(p.resolve(dist,'.'+a.path));assert(file.startsWith(dist+p.sep));assert.equal(carrier(file).sha256,a.sha256);}
  const files=inventory(dist);fs.cpSync(dist,snapshot,{recursive:true,force:false,errorOnExist:true});assert.deepEqual(inventory(snapshot),files);assert.deepEqual(inventory(dist),files);assertBuiltGameMode(snapshot,'distributable');
  writeNew(buildFile,{schema:'cf-u3-normal-build/v1',status:'pass',sourceCommit:source,sourceTree:state.sourceTree,directory:snapshot,
    mode:'distributable',builtAt:new Date().toISOString(),buildStage:state.stages.at(-1),files,assets,checkpointReceipt:executionFile,
    limitation:'Normal build and copied bytes only; this panel checkpoint is not admitted until execution.json is terminal pass.'});
  state.currentBuild=carrier(buildFile);write();
  const reviewerConfig=p.join(base,'review-config.json'),reviewOutput=p.join(base,'panel-review');
  writeNew(reviewerConfig,{repository:owned,before:{directory:before.directory,sourceCommit:before.sourceCommit,buildReceipt:before.buildReceipt},current:{directory:snapshot,sourceCommit:source,buildReceipt:buildFile}});
  const env={CF_BROWSER:'/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'},prefix='local-u3-'+panel+'-'+source.slice(0,7)+'-20260906';
  state.runIds={small:prefix+'-small-phone',large:prefix+'-large-phone',slice:prefix+'-slice'};write();
  stage('panel-review',process.execPath,[config.reviewer,reviewerConfig,reviewOutput],owned,env);
  const reportFile=p.join(reviewOutput,'report.json'),report=JSON.parse(fs.readFileSync(reportFile,'utf8'));
  assert.equal(report.schema,config.reviewSchema);assert.equal(report.status,'PASS');assert.equal(report.toolingSource,source);
  assert.equal(report.rows.length,config.expectedReviewRows);assert(report.rows.every(r=>r.status==='PASS'));assert.deepEqual(report.runtimeErrors,[]);
  state.review=carrier(reportFile);write();
  stage('static-develop',process.execPath,[p.join(candidate,'port/v2/tools/check-profile.mjs'),'--profile=develop']);
  stage('small-phone',process.execPath,[p.join(candidate,'port/v2/tools/glassmatrix.mjs'),'--viewport=small-phone'],owned,{...env,CF_V2_GLASSMATRIX_RUN_ID:state.runIds.small});
  stage('large-phone',process.execPath,[p.join(candidate,'port/v2/tools/glassmatrix.mjs'),'--viewport=large-phone'],owned,{...env,CF_V2_GLASSMATRIX_RUN_ID:state.runIds.large});
  stage('slice',process.execPath,[p.join(candidate,'port/v2/tools/smokereport.mjs'),'--profile=develop'],owned,{...env,CF_V2_SLICE_SMOKE_RUN_ID:state.runIds.slice});
  stage('slice-verify',process.execPath,[p.join(candidate,'port/v2/tools/smokereport.mjs'),'--verify-run='+state.runIds.slice,'--profile=develop']);
  assert.deepEqual(inventory(snapshot),files);assert.deepEqual(inventory(before.directory),beforeFiles);
  assert.equal(carrier(before.admissionReceipt).sha256,state.beforeAdmission.sha256);assert.equal(carrier(before.buildReceipt).sha256,state.beforeBuild.sha256);
  assert.equal(carrier(configFile).sha256,state.config.sha256);ownedGuard();clean();state.status='pass';
}catch(error){state.status='fail';state.failure=String(error);process.exitCode=1;console.error(state.failure);}
finally{state.endedAt=new Date().toISOString();write();console.log('execution '+executionFile);}
if(state.status==='pass')writeNew(p.join(base,'next-before.json'),{before:{directory:p.join(base,'normal-dist'),sourceCommit:source,buildReceipt:buildFile,admissionReceipt:executionFile}});
})().catch(error=>{process.exitCode=1;console.error(error);});
