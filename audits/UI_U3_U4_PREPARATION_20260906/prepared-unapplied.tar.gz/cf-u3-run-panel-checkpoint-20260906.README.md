# One U3 panel checkpoint runner — prepared, not executed

Invocation, inside the existing whole-job lock and the approved macOS browser execution context:

```sh
node /private/tmp/cf-u3-run-panel-checkpoint-20260906.cjs /private/tmp/PANEL-checkpoint-config.json
```

Copy-ready config shape (replace placeholders with exact admitted paths and the new signed head):

```json
{
  "panel": "shipyard",
  "sourceCommit": "FULL_NEW_SIGNED_COMMIT",
  "reviewer": "/private/tmp/cf-u3-shipyard-review-prepared-20260906/shipyard-review.mjs",
  "reviewSchema": "cf-u3-shipyard-normal-review/v1",
  "expectedReviewRows": 8,
  "before": {
    "directory": "/private/tmp/cf-u2-checkpoint-781b79c-20260906/normal-predecessor/dist",
    "sourceCommit": "781b79cf75538b711bb770a42c189c6dc70eeb16",
    "buildReceipt": "/private/tmp/cf-u2-checkpoint-781b79c-20260906/normal-predecessor/build-receipt.json",
    "admissionReceipt": "/private/tmp/cf-u2-checkpoint-781b79c-20260906/execution.json"
  }
}
```

These U2 predecessor paths are prospective: no PASS or artifact existence is assumed. Only
run after U2 passes and the separate normal-predecessor snapshot is created. The runner verifies
terminal admission, exact source, full prior snapshot hashes and ancestor relationship. Subsequent
panels copy the prior run’s `next-before.json` object and supply their own compatible review driver,
schema and exact expected row count. Order is enforced: Shipyard, Atlas, Compendium, Charters,
Records/Chronicle (`records`), Guide, Settings, Survey/biosphere (`survey`), Inventory.

One unchanged signed source produces an isolated local clone, offline root/v2 npm ci, one normal
build and immediate full-file hashed snapshot. Normal before/after review runs against immutable
snapshots before the develop static owner can replace candidate dist with evidence bytes. Then:
**develop static → small phone → large phone → Slice → exact named Slice verification**, once each.
Any command, report, source, asset, ambient or lock failure stops the chain and retains RED. There
is no retry, browser installation, network Git source, hosted action, partial-green admission or
second profile/selftest battery. Offline npm ci uses existing caches and locked dependencies.

Each driver follows the prepared Shipyard interface `DRIVER REVIEW_CONFIG NEW_OUTPUT_DIR`, imports
shared helpers from the clean owned source, accepts before/current directory+source+buildReceipt,
and emits `report.json` with the configured schema, uppercase PASS, toolingSource, exact rows all
PASS, and empty runtimeErrors. No later panel driver or all-state model is invented by this runner.
Driver bytes, config, controller, stages/logs, source tree, lock, ambient `.DS_Store`, snapshots and
receipts are retained. Only terminal full PASS creates `next-before.json` for the next panel.

The output path is one-use `/private/tmp/cf-u3-PANEL-checkpoint-SHORT-20260906`; an existing directory
is never overwritten. Whole-job lock ancestry is verified and retained throughout. Owned root/head/
tracked source/full status and untouched ambient file are checked after each stage, while candidate
must be fully clean and root main.js absent. No owned-source edit occurs. This preparation was not
executed or syntax-tested, built, browser-tested, or committed; parent reviews and invokes it once.
