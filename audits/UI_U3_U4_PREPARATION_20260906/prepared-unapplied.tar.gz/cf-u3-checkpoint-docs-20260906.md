# U3 per-panel checkpoint checklist — prepared 2026-09-06

Read-only preparation; no command below was run. U2 must pass before the ordered U3 checkpoints. Current live handoff/audit wins over older quoted records. Follow the existing owner once; this checklist adds no pins or checks.

## Ordered checkpoints and current reference focus

| Order | Panel | Current-reference content to refresh |
|---|---|---|
| 1 | Shipyard | Existing vista, Fabricator/Research segmented controls, counts/EXPAND; Engineering source/actions unchanged |
| 2 | Star Atlas | Existing List/Chart, filters, Home and Remove/Undo; Batch 4 behavior preserved |
| 3 | Compendium | Cards/spacing; variable-height virtual scroll, data-sel/logical identities, detail Back/Escape/focus unchanged |
| 4 | Charters | Objective remains sole opener; current goals/rewards/copy and refill focus unchanged |
| 5 | Records/Chronicle | Existing records/achievement identities and semantic focus preserved |
| 6 | Guide | Existing catalogue/history and ordered development bulletin; no new gameplay claims |
| 7 | Settings | Above-Training law, native Close/Escape and text/motion preferences preserved |
| 8 | Survey/landing + biosphere | Native card/landing actions, measured lanes and current content; preserve live-toast diagnosis |
| 9 | Inventory/paperdoll | Existing exact-instance/list/dialog ownership and accepted min(62vw,240px) cap; no invented equipment slots |

For each, update the current sections of UI_PRESENTATION.md, celestial-frontier-codebase-reference.md, port/v2/README.md and port/V2_PROGRAM_ROADMAP.md in place with a matches-code date. Update the live status in port/UI_PARITY_PROGRAM_U1_U4.md without rewriting approved historical amendments. Add a scoped entry to port/v2/DEVIATIONS.md when behavior intentionally differs from production. PROCESS_LAWS.md changes only for an earned new law. Retain a panel audit and source-bound before/after PNGs paired with existing v1 goldens; archive the superseded ROADMAP.md handoff verbatim newest-first in ROADMAP_ARCHIVE.md, then leave a lean self-contained handoff. Emoji study is already delivered; no repeat or product icon replacement.

## Current live producer pins

Current product producer SHA-256: 627b067cc917dc3d553a36fd85ef5d39e2612e24cac0ae4e8386fee9e7fd9fc8.
Measurement authority remains 4a93479b62b032155a4825bde6425ebd430ccb286979dc69e90064bb3c7f5e12. Numeric ceilings, historical samples/authorities and measurement/ruler inputs stay unchanged.

Only these live producer records move together:

- port/v2/budgets/compendium-memory-v1.json: producerAuthority, including all five input records; append the scoped transition to calibration.selectionRule while preserving its existing history.
- port/v2/tests/compendium-budget.test.ts: EXPECTED_PRODUCER_AUTHORITY and EXPECTED_PRODUCER_AUTHORITY_RECORD; do not replace HISTORICAL_* authorities.
- Current handoff/audit authority receipt and affected current-reference status; do not globally replace hashes in historical text.

Graph inputs are built index.html, the discovered owner/worker/painter graph, and generated service-worker.js. Re-derive from the final evidence-mode build, never guessed asset names or an older normal dist. Main, release-copy, AND CSS/index changes can alter the graph. In particular, the earlier frozen Compendium prep README sentence implying CSS-only work avoids producer re-derivation is incorrect: index.html is itself pinned.

Existing recipe: /private/tmp/cf-u2-landscape-producer-20260906.mjs and its .json receipt. It calls compendiumProducerAuthority from port/v2/tools/compendiummem-contract.mjs and findCandidateSpeciesArtBuildGraph from port/v2/tools/speciesart-build.mjs, then exact-replaces the two current records. This is a reference recipe, not rerunnable: it requires the OLD c821b3c authority and exclusive U2 receipt filename. Prepare the next exact-source copy with the actual previous authority and a distinct receipt; preserve byte/count guards.

Existing commands/owners, when the checkpoint reaches them:

- Evidence build: npm --prefix port/v2/apps/game run build -- --mode evidence.
- Authority printer: from port/v2, node tools/print-producer-authorities.mjs. This owns an unconditional locked evidence build; do not call it as if it were a free read after another unchanged build. It prints/checks authorities and does not edit budgets. Reuse the established owner rather than adding a second build loop.
- Normal before/after PNGs need their own correctly identified normal build. The static/evidence owner replaces dist; do not relabel that dist or older screenshots as normal/current-source proof.

## Preserve the existing 81-bullet development inventory

Player-visible copy owner: port/v2/apps/game/src/release-content.ts, V2_DRAFT_RELEASE. Amend the appropriate EXISTING bullet rather than adding a new count by default. Existing broad presentation bullet is SHEETS KEEP THEIR ROOM; panel-specific Engineering/Atlas bullets also exist. No version bump, shipped-release state change or invented actions.

Current rendered ordered bullet authority: count81, SHA-256 418b46f0e20ab16842c1926a0af3f6f0923d4132099fcab80d258c19ef1aa3a7. Content-only amendments preserve count81 but change the ordered digest.

| Existing owner | Exact live field / responsibility |
|---|---|
| port/v2/tools/slicesmoke.mjs | V2_DRAFT_BULLET_COUNT = 81; GUIDE_DRAFT_BULLET_AUTHORITY count and rendered ordered SHA |
| port/v2/tools/glassmatrix.mjs | expectedBulletCount=81 and the 81-outcome development-inventory description; semantic assertions/negative-control anchors for any edited copy |
| port/v2/tests/guide-release.test.ts | Existing truthful-copy/negative-control outcome expectations; only touched copy anchors change |
| port/v2/tests/evidence-chain-tools.test.ts | Fixed Slice count spelling remains81 |
| port/v2/tests/slicesmoke-sixth-red-contract.test.ts | Count81/Glass81 inventory, JSDOM-rendered ordered digest parity and existing44 copy-mutation anchor checks |
| port/v2/tests/exceptional-crafting-evidence-contract.test.ts | Existing count81 outcome fixture and GUIDE_DRAFT_BULLET_AUTHORITY use; untouched unless relevant copy expectation changes |

Reuse the digest algorithm already in slicesmoke-sixth-red-contract.test.ts: render the actual V2_DRAFT_RELEASE bullets as li nodes with JSDOM, collect textContent in source order, then SHA-256 the JSON array. Do not hash source literals/raw HTML or manually copy a prior digest. Retain existing negative-control intent and exact count81; no new pin inventory.

## Verification/handoff owner

Root validate remains node tools/validate.js. From port/v2, the current local checkpoint uses node tools/check-profile.mjs --profile=develop, then the existing named small-phone and large-phone Glass canaries, then Slice develop and its exact named verifier; current ROADMAP/runner owns exact order and IDs. The profile owns npm test, TypeScript/unused and selected static owners; do not run unchanged owners twice. The program lists typecheck/artunused/Vitest/Glass selftest/Slice/phones requirements, while the latest handoff supplies the active sequential execution order. Use the established isolated clean signed-source runner with root main.js absent and locked dependencies; preserve ambient .DS_Store in the owned checkout. Retain first RED/instrument result and mark successor stages NOT RUN; never retry unchanged source or weaken thresholds.

Record source/build identity, immutable report/log/PNG hashes, scoped versus full coverage, visual review limits and the next panel. Both historical 08cd97d navigation and c57aaaeb restoration causes remain OPEN/unattributed; physical device UAT remains open. U1 acceptance for UAT is not complete UAT. No U4/full-chain/Phase2/hosted escalation is implied by a panel PASS. Pair the handoff steps: Codex continues the next authorized ordered local panel; Claude need not be opened now; a future openai/mac→develop hosted action still needs exact authority.
