# U3 Records / Expedition Chronicle — temporary proposal

Prepared by OpenAI/Codex on macOS, owned `openai/mac` workspace, 2026-09-06.
**Not applied, built, tested, rendered or checkpoint evidence.** Apply only after
Charters passes, in the program's ordered U3 sequence. No checkout file was changed.

## Proposal

Append scoped CSS to the last inline style in `port/v2/apps/game/index.html`:
consistent Records section gaps, rank-card padding, achievement and Binder cards,
wrapping score/action text, fitted native Claim buttons, and native Chronicle gallery
summaries with 44px minimum height and visible keyboard focus. All selectors use
`#recpanel`; no control, section, tab, text, identifier, model, state or writer is added.

Current `fillRecords()` already owns rank/achievements, Binder and Expedition Chronicle
& Museum. Existing disclosure state/order, all 96 achievements, compatibility/protected
copy, Claim behavior, Paragon route/Inspect actions and semantic refill focus stay intact.
Rank/iridescent backgrounds, achievement-status colors, owned Binder rarity surfaces,
missing-slot styling and shared <=400px Claim stacking retain their existing rules.
U2 sheet dimensions/scrolling/header/Close and shared button states stay untouched.
The separate timed **Combat Chronicle** panel is outside this Records proposal.

## Review files and guarded application

`records.css`, `records.patch`, `index.before.html`, `index.proposed.html` and
`manifest.json` describe the proposed single-file edit. `golden-association.json`
records the existing v1 phone/desktop source images, observed hashes and visual notes.
Both were visually read, not regenerated. Their minimal-veteran state is unpopulated.
The v1 tabs/rarity ladder and 89-achievement count differ from current v2; no new
navigation or gameplay is inferred from those images. They are human visual references,
not a byte/pixel acceptance gate. Current-v2 before/after images are not yet available.

At the later ordered checkpoint, review current source, then from the owned repository:
`python3 /private/tmp/cf-u3-records-prepared-20260906/apply.py` checks the exact guards.
Adding `--apply` explicitly applies the reviewed rules via a temporary copy and atomic
replacement. **Neither command was run.** The script refuses changed relevant renderer,
Records wiring, base styles, shared sheet/panel owner or tokens. Refresh guards only after
re-review; do not overwrite later HTML with this snapshot. Unrelated earlier U3 HTML
additions can coexist through the exact, unique last-style insertion anchor.

## Authority and later checkpoint

`port/UI_PARITY_PROGRAM_U1_U4.md:302–308` owns order and per-panel before/after proof.
Current rendering: `main.ts:3915`, `records-rank-panel.ts:58`, `binder-sets.ts:575`,
`expedition-chronicle.ts:223`. `EXPLORATION_SHIPS_LOOT_AND_COMPANIONS.md:64` defines the
four read-only history galleries; current source supersedes older narrower Binder prose.

Parent owns later required validation and existing Records/rank, Starter/Binder wiring,
Expedition Chronicle/model/wiring and panel-focus tests; normal-build native Records
open/Close/focus, disclosure keyboard/pointer outcomes and real reachable Claim/Paragon
states as applicable; phone/desktop/small/landscape/large-text bounds and v1/v2 image
comparison. No fake saved state, reward claim, gameplay result or native-layout PASS is
created here. Any new geometry checks require meaningful failure/restoration controls.

Keep U2 active and both older U1 causes open (unsolicited navigation and the portrait-
restoration Runtime.evaluate timeout). No Inkscape, hosted action or Phase 2 work.
Codex holds this proposal until Charters passes; Claude's worktree is unchanged and Nick
does not need to open Claude for this temporary preparation.
