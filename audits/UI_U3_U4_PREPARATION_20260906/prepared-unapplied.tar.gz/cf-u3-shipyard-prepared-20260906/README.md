# U3 Shipyard preparation — 2026-09-06

Prepared only under /private/tmp. No checkout edits, test/build/browser runs, commit, or U3 checkpoint result.
Apply only after the parent admits the U2 checkpoint. The script fails if any of its three source files changed.

```sh
python3 /private/tmp/cf-u3-shipyard-prepared-20260906/apply.py
python3 /private/tmp/cf-u3-shipyard-prepared-20260906/apply.py --apply
```

Files: engineering-panel.ts, index.html, engineering-panel.test.ts, mirrored below this directory.
`shipyard.css` is a review extract; `manifest.json` contains source/prepared SHA256 and exact-once replacements.
The apply script preflights all source hashes, every exact match and the final prepared bytes before writing copies
and atomically replacing the three files. A second apply fails against the original baseline.

The existing authored SVG supplies the vista. The same Engineering & Shipyard heading gains the shared U2
sheet-header treatment and rocket emoji; native Close and its ownership are untouched. Two 44px native buttons
form a segmented jump group: Fabricator and Research open/reveal/focus only their existing target summary.
They are navigation controls, have no selected-tab claim, emit no engineering action and remain usable during
pending work just as native disclosure summaries already do. Mining, Skimming, Research and Fabricator retain
exact IDs, ordering, default open states, action wiring and four-section diagnostic inventory.

Fabrication categories become native details, initially open, with stable semantic focus keys, live available
counts and EXPAND/COLLAPSE labels. Only available recipes with a connected live effect count. No fake tiers or
screenshot counts are introduced because the read model has no authored tier field. A separate closed-group
receipt retains deliberate collapse through refill/pilot round trips and lets newly introduced groups start open.
Recipe rows, immediate row-list children, canonical order, DOM attributes and native action requests remain.

Three focused tests are prepared: pointer/keyboard-origin click routing without action emission or pending unlock;
invalid target rejection; category counts/collapse/focus through changed models and pilot round trips, including
new group defaults and protected mode; independent 44px rule fault controls. Two old summary inventories are
narrowed to the original four engineering owners, preserving their intent. These tests have NOT RUN.

The existing main-wiring file is unchanged because its integration owner is unchanged. The parent should run
engineering-panel.test.ts, training-main-wiring.test.ts, and the existing Shipyard disclosure identity suite after
application under the shared lock, plus root/app typechecks and required validation/release/producer maintenance.
The per-panel native checkpoint still needs matched v1/v2 before/after screenshots, native keyboard activation,
small phone/landscape bounds, scrolling/sticky Close, nested category collapse/refill, and unchanged action outcomes.
No phase or historical evidence status is changed by these temporary files.
