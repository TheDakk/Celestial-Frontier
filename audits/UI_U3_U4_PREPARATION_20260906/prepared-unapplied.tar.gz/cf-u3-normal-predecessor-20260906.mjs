/* One-use preparation runner; invoke only after the exact U2 canonical terminal PASS.
 * Under the caller's existing tools/with-toolchain-lock.mjs whole-job lock:
 * node THIS_FILE FULL_U2_SHA /private/tmp/cf-u2-checkpoint-SHORT-20260906/execution.json
 * No browser, test, install, network, retry, U3 source change or evidence build. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
const [source, executionArg] = process.argv.slice(2);
assert(/^[a-f0-9]{40}$/.test(source), 'exact full admitted U2 SHA required');
const owned = '/Users/nick/Projects/celestial-frontier-openai-mac';
const base = '/private/tmp/cf-u2-checkpoint-' + source.slice(0, 7) + '-20260906';
const candidate = path.join(base, 'candidate'), output = path.join(base, 'normal-predecessor');
assert(!fs.existsSync(output), 'one use only: predecessor output already exists');
fs.mkdirSync(output);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const carrier = file => { const bytes = fs.readFileSync(file); return { path: file, bytes: bytes.length, sha256: hash(bytes) }; };
const git = (args, cwd = candidate) => execFileSync('git', args, { cwd, encoding: 'utf8' }).trim();
const receiptPath = path.join(output, 'build-receipt.json');
const receipt = { schema: 'cf-u3-normal-predecessor/v1', status: 'running', sourceCommit: source, candidate,
  startedAt: new Date().toISOString(), node: process.version, hostedActions: 0, builds: 0, stages: [] };
const write = () => fs.writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n');
function stage(name, command, args, cwd) {
  const log = path.join(output, name + '.log'), row = { name, command: [command, ...args], cwd, startedAt: new Date().toISOString(), status: 'running', log };
  receipt.stages.push(row); write(); const fd = fs.openSync(log, 'wx'); let result;
  try { result = spawnSync(command, args, { cwd, env: process.env, stdio: ['ignore', fd, fd] }); }
  finally { fs.closeSync(fd); }
  Object.assign(row, { endedAt: new Date().toISOString(), exitCode: result.status, signal: result.signal,
    error: result.error?.message ?? null, status: result.status === 0 && !result.error ? 'pass' : 'fail', carrier: carrier(log) });
  write(); assert.equal(row.status, 'pass', name + ' failed; no retry');
}
function clean() {
  assert.equal(fs.realpathSync(candidate), candidate); assert.equal(git(['rev-parse', '--show-toplevel']), candidate);
  assert.equal(git(['branch', '--show-current']), 'openai/mac'); assert.equal(git(['rev-parse', 'HEAD']), source);
  assert.equal(git(['status', '--porcelain=v1', '--untracked-files=all']), '', 'candidate must remain completely clean');
  assert(!fs.existsSync(path.join(candidate, 'main.js')), 'root generated main.js must remain absent');
}
function files(directory, sub = '') {
  return fs.readdirSync(path.join(directory, sub)).sort().flatMap(name => {
    const relative = path.join(sub, name), full = path.join(directory, relative), stat = fs.lstatSync(full);
    assert(!stat.isSymbolicLink(), 'snapshot cannot follow symlinks');
    if (stat.isDirectory()) return files(directory, relative);
    assert(stat.isFile(), 'non-file artifact'); const { bytes, sha256 } = carrier(full); return [{ path: relative, bytes, sha256 }];
  });
}
try {
  write(); receipt.runner = carrier(fs.realpathSync(process.argv[1]));
  assert.equal(process.platform, 'darwin'); assert.equal(fs.realpathSync(owned), owned);
  assert.equal(git(['rev-parse', '--show-toplevel'], owned), owned); assert.equal(git(['branch', '--show-current'], owned), 'openai/mac');
  const executionFile = fs.realpathSync(executionArg); assert.equal(executionFile, path.join(base, 'execution.json'));
  receipt.u2Execution = carrier(executionFile); const execution = JSON.parse(fs.readFileSync(executionFile, 'utf8'));
  assert.equal(execution.schema, 'cf-u2-local-validation-execution/v1'); assert.equal(execution.status, 'pass');
  assert.equal(execution.source, source); assert.equal(execution.ownedWorkspace, owned); assert.equal(execution.testArtifact, candidate);
  assert.equal(execution.hostedActions, 0); assert(Number.isFinite(Date.parse(execution.endedAt)) && !execution.failure);
  assert(execution.stages.length >= 9 && execution.stages.every(s => s.status === 'pass' && s.exitCode === 0 && !s.signal && !s.error));
  for (const name of ['signature', 'clone', 'root-install', 'v2-install', 'static-develop', 'small-phone', 'large-phone', 'slice', 'slice-verify'])
    assert.equal(execution.stages.filter(s => s.name === name).length, 1, 'missing/duplicated U2 stage: ' + name);
  const lockFile = '/private/tmp/celestial-frontier-toolchain-' + process.getuid() + '.lock/owner.json';
  receipt.lock = carrier(lockFile); const owner = JSON.parse(fs.readFileSync(lockFile, 'utf8'));
  let pid = process.ppid, ancestor = false;
  for (let depth = 0; pid > 1 && depth < 32; depth++) {
    if (pid === owner.pid) { ancestor = true; break; }
    pid = Number(execFileSync('ps', ['-o', 'ppid=', '-p', String(pid)], { encoding: 'utf8' }).trim());
  }
  assert(ancestor && typeof owner.token === 'string', 'caller must hold the inherited whole-job lock');
  clean(); receipt.sourceTree = git(['rev-parse', source + '^{tree}']);
  stage('signature', 'git', ['-c', 'gpg.ssh.allowedSignersFile=/private/tmp/cf-u1-navigation-allowed-signers', 'verify-commit', source], candidate);
  receipt.builds++; write(); stage('normal-build', 'npm', ['run', 'build', '--workspace=@cf/game'], path.join(candidate, 'port/v2')); clean();
  const dist = path.join(candidate, 'port/v2/apps/game/dist'), snapshot = path.join(output, 'dist');
  const { assertBuiltGameMode } = await import(pathToFileURL(path.join(candidate, 'port/v2/tools/build-mode.mjs')));
  receipt.mode = assertBuiltGameMode(dist, 'distributable');
  const worker = fs.readFileSync(path.join(dist, 'service-worker.js'), 'utf8');
  const match = /const ASSETS=Object\.freeze\((\[[^\n]+\])\);/u.exec(worker); assert(match, 'missing native asset inventory');
  receipt.assets = JSON.parse(match[1]); assert(receipt.assets.length > 0);
  for (const asset of receipt.assets) {
    const file = fs.realpathSync(path.resolve(dist, '.' + asset.path)); assert(file.startsWith(dist + path.sep));
    assert.equal(carrier(file).sha256, asset.sha256, 'native asset hash mismatch: ' + asset.path);
  }
  receipt.files = files(dist); fs.cpSync(dist, snapshot, { recursive: true, force: false, errorOnExist: true });
  assert.deepEqual(files(snapshot), receipt.files, 'snapshot bytes differ'); assert.deepEqual(files(dist), receipt.files, 'build changed during snapshot');
  assert.equal(assertBuiltGameMode(snapshot, 'distributable'), 'distributable'); clean();
  assert.equal(carrier(executionFile).sha256, receipt.u2Execution.sha256, 'U2 terminal receipt changed');
  assert.equal(carrier(lockFile).sha256, receipt.lock.sha256, 'whole-job lock changed');
  receipt.before = { directory: snapshot, sourceCommit: source, buildReceipt: receiptPath };
  fs.writeFileSync(path.join(output, 'shipyard-before.json'), JSON.stringify({ before: receipt.before }, null, 2) + '\n', { flag: 'wx' });
  receipt.status = 'pass';
} catch (error) { receipt.status = 'fail'; receipt.failure = String(error); process.exitCode = 1; }
finally { receipt.endedAt = new Date().toISOString(); write(); console.log(JSON.stringify({ status: receipt.status, receipt: receiptPath, before: receipt.before ?? null, failure: receipt.failure ?? null })); }
