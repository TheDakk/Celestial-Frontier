/* Prepared U4 contract: DOM reading and assessment have no product mutations.
 * The explicit fault owner below is diagnostic-only and restores exact carriers.
 * Call only after normal native opening and the existing font/two-frame boundary. */
import { GLASS_MATRIX_VIEWPORTS } from './glassmatrix-evidence-contract.mjs';
export const LAYOUT_VIEWPORTS = Object.freeze(GLASS_MATRIX_VIEWPORTS.slice(0, 10));
export const LAYOUT_FAMILIES = Object.freeze(['VIEWPORT', 'TOPBAR_SYNC', 'DOCK_IDENTITY', 'DOCK_GEOMETRY',
  'TARGET_FLOOR', 'TARGET_HIT', 'INTERACTIVE_OVERLAP', 'LANE_OVERLAP', 'SHEET_POPULATION', 'SHEET_HEADER', 'CONTENT_CLIP']);

/** Self-contained for Runtime.evaluate serialization; no imported helper closure. */
export function readLayoutSnapshot() {
  const action = 'button,input:not([type="hidden"]),select,textarea,a[href],summary,[role="button"],[role="link"],[tabindex]:not([tabindex="-1"])';
  const native = 'button,input,select,textarea,a[href],summary';
  const sheetSelector = '.panel,#survey,#planetside,#inventorysheet';
  const key = el => {
    if (!el) return null;
    if (el.id) return '#' + CSS.escape(el.id);
    const parts = []; for (let node = el; node && node !== document.documentElement; node = node.parentElement) {
      if (node.id) { parts.unshift('#' + CSS.escape(node.id)); break; }
      parts.unshift(node.tagName.toLowerCase() + ':nth-of-type(' + ([...node.parentElement.children].filter(n => n.tagName === node.tagName).indexOf(node) + 1) + ')');
    } return parts.join('>');
  };
  const box = r => ({ left:r.left, top:r.top, right:r.right, bottom:r.bottom, width:r.width, height:r.height });
  const intersect = (a,b) => { const left=Math.max(a.left,b.left),top=Math.max(a.top,b.top),right=Math.min(a.right,b.right),bottom=Math.min(a.bottom,b.bottom);
    return {left,top,right:Math.max(left,right),bottom:Math.max(top,bottom),width:Math.max(0,right-left),height:Math.max(0,bottom-top)}; };
  const visible = el => {
    if (!el.getClientRects().length) return false;
    for (let p=el;p;p=p.parentElement) { const s=getComputedStyle(p);
      if (s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||Number(s.opacity)===0||p.hidden) return false;
      if (p.tagName==='DETAILS'&&!p.open&&el!==p&&!p.querySelector(':scope > summary')?.contains(el)) return false;
    } return true;
  };
  const viewport={left:0,top:0,right:innerWidth,bottom:innerHeight,width:innerWidth,height:innerHeight};
  const clipping = (el,includeSelf=false) => {
    const clips=[]; for(let p=includeSelf?el:el.parentElement;p;p=p.parentElement) { const s=getComputedStyle(p),r=p.getBoundingClientRect();
      const x=/^(auto|scroll|hidden|clip)$/.test(s.overflowX),y=/^(auto|scroll|hidden|clip)$/.test(s.overflowY);
      if(x||y) clips.push({key:key(p),rect:{left:r.left+p.clientLeft,top:r.top+p.clientTop,right:r.left+p.clientLeft+p.clientWidth,bottom:r.top+p.clientTop+p.clientHeight},
        x,y,modeX:s.overflowX,modeY:s.overflowY,scrollLeft:p.scrollLeft,scrollTop:p.scrollTop,scrollWidth:p.scrollWidth,scrollHeight:p.scrollHeight,clientWidth:p.clientWidth,clientHeight:p.clientHeight});
    } return clips;
  };
  const geometry = el => { const rect=box(el.getBoundingClientRect()),style=getComputedStyle(el),clips=clipping(el);let exposed=intersect(rect,viewport);
    for(const clip of clips) exposed=intersect(exposed,{left:clip.x?clip.rect.left:-Infinity,right:clip.x?clip.rect.right:Infinity,top:clip.y?clip.rect.top:-Infinity,bottom:clip.y?clip.rect.bottom:Infinity});
    return {key:key(el),rect,exposed,visible:visible(el)&&rect.width>0&&rect.height>0,clips,position:style.position,
      overflowX:style.overflowX,overflowY:style.overflowY,scrollWidth:el.scrollWidth,scrollHeight:el.scrollHeight,clientWidth:el.clientWidth,clientHeight:el.clientHeight}; };
  const rootIds=['topbar','dock','hintpill','ctxbar','toast'];
  const roots=Object.fromEntries(rootIds.map(id=>{const el=document.getElementById(id);return[id,el?geometry(el):null]}));
  const elements=[...document.querySelectorAll(action)].filter(el=>!el.closest('svg')&&(el.tagName!=='CANVAS'||el.closest(sheetSelector)));
  const overflow=elements.length>2000;
  const controls=elements.slice(0,2000).map(el=>{
    const label=el.matches('input[type=radio],input[type=checkbox]')?(el.closest('label')||(el.id?document.querySelector('label[for="'+CSS.escape(el.id)+'"]'):null)):null;
    const touchOwner=label||el,g=geometry(touchOwner),r=g.rect,nativeOwner=el.closest(native)||el,ancestors=[];
    for(let p=el.parentElement;p;p=p.parentElement)ancestors.push(key(p));
    const hit=g.exposed.width>0&&g.exposed.height>0?document.elementFromPoint((g.exposed.left+g.exposed.right)/2,(g.exposed.top+g.exposed.bottom)/2):null;
    return {...g,key:key(el),touchOwner:key(touchOwner),nativeOwner:key(nativeOwner),ancestors,enabled:!el.disabled&&!el.closest('[inert]'),
      fullExposure:g.exposed.width>=r.width-1&&g.exposed.height>=r.height-1,hit:!!hit&&(hit===touchOwner||touchOwner.contains(hit)),hitOwner:key(hit),
      name:(el.getAttribute('aria-label')||el.textContent||el.getAttribute('title')||el.getAttribute('placeholder')||'').trim().slice(0,160)};
  });
  let textCount=0,contentOverflow=false;
  const sheets=[...document.querySelectorAll(sheetSelector)].filter(visible).map(el=>{
    const g=geometry(el),header=el.querySelector('.sheet-header,.survey-head,h2'),close=el.querySelectorAll('[data-pnx],[data-survey-close],[data-inventory-sheet-close]');
    const content=[],walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let node;
    while((node=walker.nextNode())) { const owner=node.parentElement;if(!node.textContent.trim()||!visible(owner)||header?.contains(owner)||owner.closest('script,style,.sheet-header,.survey-head,[data-pnx],[data-survey-close],[data-inventory-sheet-close]'))continue;
      const range=document.createRange();range.selectNodeContents(node);
      for(const rect of range.getClientRects()){if(rect.width<=0||rect.height<=0)continue;if(++textCount>2000){contentOverflow=true;break;}
        content.push({owner:key(owner),text:node.textContent.trim().slice(0,100),rect:box(rect),clips:clipping(owner,true)});}
      if(contentOverflow)break;
    }
    return {...g,header:header?geometry(header):null,closeKeys:[...close].map(key),content,
      fixture:el.getAttribute('data-u2-fixture')||el.getAttribute('data-layout-fixture')||null};
  });
  const dock=document.getElementById('dock'),buttons=dock?[...dock.querySelectorAll('button')].filter(visible):[];
  const dockButtons=buttons.map(el=>{const style=getComputedStyle(el),children=[...el.children].filter(visible);
    const vertical=name=>parseFloat(style[name])||0;
    const needed=children.reduce((sum,child)=>{const s=getComputedStyle(child);return sum+child.getBoundingClientRect().height+(parseFloat(s.marginTop)||0)+(parseFloat(s.marginBottom)||0)},0)
      +Math.max(0,children.length-1)*(parseFloat(style.rowGap)||0)+['paddingTop','paddingBottom','borderTopWidth','borderBottomWidth'].reduce((sum,name)=>sum+vertical(name),0);
    const face=el.querySelector('.utility-face');return {...geometry(el),id:el.id,intrinsicHeight:Math.max(44,needed),face:face?geometry(face):null};
  });
  const rootStyle=getComputedStyle(document.documentElement),css=name=>parseFloat(rootStyle.getPropertyValue(name));
  return {schema:'cf-v2-layout-snapshot/v1',viewport:{...viewport,dpr:devicePixelRatio},bodyClass:document.body.className,
    compact:innerWidth<=700||(innerWidth<=900&&innerWidth>innerHeight),panelOpen:document.body.classList.contains('panel-open'),
    safe:{top:css('--safe-top')||0,right:css('--safe-right')||0,bottom:css('--safe-bottom')||0,left:css('--safe-left')||0},
    published:{topbar:css('--topbar-h'),dock:css('--dock-h')},roots,controls,sheets,dockButtons,
    pageOverflow:document.documentElement.scrollWidth>innerWidth+1,inventoryOverflow:overflow||contentOverflow,
    exclusions:[{kind:'scene-backdrop',selectors:[...document.querySelectorAll('canvas')].filter(el=>!el.closest(sheetSelector)).map(key)}]};
}

/** Findings carry both observed rectangles and the exact independent expectation. */
export function assessLayoutSnapshot(snapshot,{viewport,expectedSheets=[],requireActiveSheet=true}={}) {
  const findings=[],exclusions=[...(snapshot?.exclusions||[])];
  const add=(code,target,detail,actual,expected)=>findings.push({code,target,detail,actual,expected});
  if(!snapshot||snapshot.schema!=='cf-v2-layout-snapshot/v1'||!Array.isArray(snapshot.controls)||!Array.isArray(snapshot.sheets)
    ||!Array.isArray(snapshot.dockButtons)||!snapshot.roots||!snapshot.safe||!snapshot.published||!snapshot.viewport)return{pass:false,findings:[{code:'SNAPSHOT',detail:'missing required layout carrier'}],exclusions};
  const s=snapshot,v=s.viewport,match=LAYOUT_VIEWPORTS.find(row=>row.label===viewport?.label);
  if(!match||v.width!==match.width||v.height!==match.height||v.dpr!==match.dpr)add('SNAPSHOT','viewport','Expected named Glass viewport identity',v,match||viewport);
  if(s.inventoryOverflow)add('SNAPSHOT','inventory','Reader cap reached; partial inventories cannot pass',true,false);
  const valid=r=>r&&['left','top','right','bottom','width','height'].every(k=>Number.isFinite(r[k]))&&r.width>=0&&r.height>=0&&Math.abs(r.right-r.left-r.width)<.01&&Math.abs(r.bottom-r.top-r.height)<.01;
  const contained=(r,b)=>r.left>=b.left-1&&r.top>=b.top-1&&r.right<=b.right+1&&r.bottom<=b.bottom+1;
  const intersection=(a,b)=>({width:Math.min(a.right,b.right)-Math.max(a.left,b.left),height:Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top)});
  const overlap=(a,b)=>{const r=intersection(a,b);return r.width>1&&r.height>1};
  const near=(actual,expected)=>Number.isFinite(actual)&&Math.abs(actual-expected)<=1;
  const bounds={left:s.safe.left,top:s.safe.top,right:v.width-s.safe.right,bottom:v.height-s.safe.bottom};
  if(s.pageOverflow)add('VIEWPORT','document','Page overflows horizontally',v.width,'scrollWidth <= viewport width + 1');
  for(const [id,r] of Object.entries(s.roots))if(!r||!valid(r.rect))add('SNAPSHOT','#'+id,'Required shell root/rectangle is absent',r,'complete finite rectangle');
  if(findings.some(f=>f.code==='SNAPSHOT'))return{pass:false,findings,exclusions};
  const topbar=s.roots.topbar,dock=s.roots.dock;
  if(!topbar.visible||!near(s.published.topbar,topbar.rect.height))add('TOPBAR_SYNC','#topbar','Published height differs from rendered topbar',s.published.topbar,topbar.rect.height);
  if(!dock.visible||!near(s.published.dock,dock.rect.height))add('DOCK_GEOMETRY','#dock','Published dock height differs from rendered dock',s.published.dock,dock.rect.height);
  const expected=s.compact?['docksurvey','dockcodex','primechip','dockshipyard','dockatlas','dockrecords','docknotifications','dockguide','docksets']:['primechip','dockrecords','docknotifications','dockguide','docksets'];
  const relevant=s.dockButtons.filter(b=>s.compact||!['docksurvey','railcodex','dockcharts'].includes(b.id));
  if(JSON.stringify(relevant.map(b=>b.id))!==JSON.stringify(expected))add('DOCK_IDENTITY','#dock','Visible native launcher membership/order differs',relevant.map(b=>b.id),expected);
  const lane=s.compact&&s.panelOpen&&v.width>v.height?(v.width-s.safe.left-s.safe.right-36)/2:v.width-s.safe.left-s.safe.right-20;
  const width=s.compact?Math.min(320,lane):200,pitch=s.compact?width/5:52,boards=relevant.slice(0,s.compact?5:0),utilities=relevant.filter(b=>/^dock(records|notifications|guide|sets)$/.test(b.id));
  const rowHeight=s.compact?Math.max(44,...boards.map(b=>b.intrinsicHeight)):44,height=s.compact?rowHeight+48:44;
  if(!near(dock.rect.width,width)||!near(dock.rect.height,height))add('DOCK_GEOMETRY','#dock','Responsive dock dimensions differ',dock.rect,{width,height});
  for(const [i,b]of boards.entries())if(!near(b.rect.width,pitch-4)||!near(b.rect.height,rowHeight)||!near((b.rect.left+b.rect.right)/2,dock.rect.left+pitch*(i+.5))||!near(b.rect.top,dock.rect.top))
    add('DOCK_GEOMETRY',b.key,'Upper scene slot width/height/centre differs',b.rect,{width:pitch-4,height:rowHeight,centre:dock.rect.left+pitch*(i+.5),top:dock.rect.top});
  for(const[i,b]of utilities.entries())if(!near(b.rect.width,44)||!near(b.rect.height,44)||!near((b.rect.left+b.rect.right)/2,dock.rect.left+(s.compact?pitch*(i+1):22+pitch*i))
    ||!near(b.rect.top,dock.rect.top+(s.compact?rowHeight+4:0))||!b.face||!near(b.face.rect.width,36)||!near(b.face.rect.height,36))
    add('DOCK_GEOMETRY',b.key,'Utility target/face or centred lower slot differs',b,{target:44,face:36,pitch,top:dock.rect.top+(s.compact?rowHeight+4:0)});
  const active=s.controls.filter(c=>c.visible);
  if(!active.length)add('SNAPSHOT','controls','No rendered native controls were inventoried',0,'nonempty');
  for(const c of active){
    if(!valid(c.rect)||!valid(c.exposed)){add('SNAPSHOT',c.key,'Invalid control rectangle',c,'finite rectangle');continue;}
    if(c.rect.width<44||c.rect.height<44)add('TARGET_FLOOR',c.key,'Native touch target falls below 44px',c.rect,{minimumWidth:44,minimumHeight:44});
    if(c.touchOwner&&c.touchOwner!==c.key)exclusions.push({kind:'associated-label-touch-owner',target:c.key,owner:c.touchOwner});
    if(!c.enabled){exclusions.push({kind:'disabled-or-inert',target:c.key});continue;}
    const scrollReachable=(c.clips||[]).some(clip=>['auto','scroll'].includes(clip.modeX)||['auto','scroll'].includes(clip.modeY));
    if(!contained(c.rect,bounds)&&!scrollReachable)add('VIEWPORT',c.key,'Control leaves safe viewport without a scroll owner',c.rect,bounds);
    if(!c.fullExposure){exclusions.push({kind:'partly-or-wholly-outside-scrollport',target:c.key,rect:c.rect,exposed:c.exposed});continue;}

    if(!c.hit)add('TARGET_HIT',c.key,'Control centre is owned by another element',{rect:c.rect,hitOwner:c.hitOwner},c.nativeOwner);
  }
  const interactive=active.filter(c=>c.enabled&&c.exposed.width>1&&c.exposed.height>1);
  for(let i=0;i<interactive.length;i++)for(let j=i+1;j<interactive.length;j++){
    const a=interactive[i],b=interactive[j];if(!overlap(a.exposed,b.exposed))continue;
    if(a.nativeOwner===b.nativeOwner&&(a.ancestors.includes(b.key)||b.ancestors.includes(a.key))){exclusions.push({kind:'same-native-control-ancestry',targets:[a.key,b.key]});continue;}
    add('INTERACTIVE_OVERLAP',a.key+' + '+b.key,'Unrelated exposed interactive targets intersect',{a:a.exposed,b:b.exposed,intersection:intersection(a.exposed,b.exposed)},'no positive intersection above 1px');
  }
  const sheets=s.sheets.filter(r=>r.visible);
  if(requireActiveSheet&&!sheets.length)add('SHEET_POPULATION','active sheet','Required native panel state is absent',[],expectedSheets);
  for(const id of expectedSheets)if(!sheets.some(r=>r.key==='#'+id))add('SHEET_POPULATION','#'+id,'Expected sheet is not visibly open',sheets.map(r=>r.key),'visible populated sheet');
  for(const sheet of sheets){
    if(!valid(sheet.rect)||!contained(sheet.rect,bounds))add('VIEWPORT',sheet.key,'Active sheet leaves safe viewport',sheet.rect,bounds);
    if(!sheet.content.length)add('SHEET_POPULATION',sheet.key,'Close/header alone is not populated content',sheet.content,'rendered substantive content');
    if(sheet.key!=='#planetside'&&(!sheet.header?.visible||sheet.header.position!=='sticky'||!contained(sheet.header.rect,sheet.rect)))add('SHEET_HEADER',sheet.key,'Sheet header is absent, nonsticky or outside its surface',sheet.header,'contained sticky header');
    if(sheet.key!=='#planetside'&&(sheet.closeKeys.length!==1||!active.some(c=>c.key===sheet.closeKeys[0]&&c.enabled&&c.hit&&c.fullExposure)))add('SHEET_HEADER',sheet.key,'Sheet needs one actionable native Close',sheet.closeKeys,'one exposed Close');
    if(sheet.key!=='#planetside'&&sheet.scrollWidth>sheet.clientWidth+1)add('CONTENT_CLIP',sheet.key,'Sheet content requires unexpected horizontal scrolling',{scrollWidth:sheet.scrollWidth,clientWidth:sheet.clientWidth},'fit the sheet width');
    for(const piece of sheet.content)if(!contained(piece.rect,sheet.rect)&&!piece.clips.some(clip=>['auto','scroll'].includes(clip.modeX)||['auto','scroll'].includes(clip.modeY)))add('CONTENT_CLIP',piece.owner,'Content escapes its sheet without a reachable scroll owner',{rect:piece.rect,sheet:sheet.rect},'contained or scroll reachable');
    for(const piece of sheet.content)for(const clip of piece.clips){
      const outsideX=clip.x&&(piece.rect.left<clip.rect.left-1||piece.rect.right>clip.rect.right+1),outsideY=clip.y&&(piece.rect.top<clip.rect.top-1||piece.rect.bottom>clip.rect.bottom+1);
      const reachableX=['auto','scroll'].includes(clip.modeX)&&piece.rect.left>=clip.rect.left-clip.scrollLeft-1&&piece.rect.right<=clip.rect.left+clip.scrollWidth-clip.scrollLeft+1;
      const reachableY=['auto','scroll'].includes(clip.modeY)&&piece.rect.top>=clip.rect.top-clip.scrollTop-1&&piece.rect.bottom<=clip.rect.top+clip.scrollHeight-clip.scrollTop+1;
      const blockedX=outsideX&&!reachableX,blockedY=outsideY&&!reachableY;
      if(blockedX||blockedY)add('CONTENT_CLIP',piece.owner,'Rendered text is cut by a non-scrollable ancestor',{text:piece.text,rect:piece.rect,clip},'fully visible or reachable through its real scroller');
      else if(outsideX||outsideY)exclusions.push({kind:'scroll-reachable-content',target:piece.owner,clip:clip.key,rect:piece.rect});
    }
  }
  const lower=['hintpill','ctxbar','dock'].map(id=>s.roots[id]).filter(r=>r.visible),toast=s.roots.toast;
  const surfaces=[...sheets,...(toast.visible?[toast]:[])];
  for(const a of surfaces)for(const b of lower)if(overlap(a.rect,b.rect))add('LANE_OVERLAP',a.key+' + '+b.key,'Sheet/toast intersects caption or launcher lane',{a:a.rect,b:b.rect,intersection:intersection(a.rect,b.rect)},'disjoint lanes');
  if(toast.visible)for(const a of sheets)if(overlap(a.rect,toast.rect))add('LANE_OVERLAP',a.key+' + '+toast.key,'Toast covers active sheet/biosphere',{a:a.rect,b:toast.rect,intersection:intersection(a.rect,toast.rect)},'disjoint lanes');
  return{pass:findings.length===0,findings,exclusions,counts:{controls:active.length,sheets:sheets.length,content:sheets.reduce((n,sheet)=>n+sheet.content.length,0)}};
}

/** Browser-only fault owner. Family -> exact target/geometry receipt. No native input claim.
 * Caller retains first failure, waits existing frames, assesses red, restores, waits and assesses green. */
export function applyLayoutFault(family,snapshot,restore=false){
  if(restore){const saved=window.__cfLayoutFault;if(!saved)throw new Error('No layout fault to restore');
    for(const row of saved.rows){if(row.children)row.node.replaceChildren(...row.children);row.style===null?row.node.removeAttribute('style'):row.node.setAttribute('style',row.style);}
    saved.cover?.remove();delete window.__cfLayoutFault;return{family:saved.family,exact:saved.rows.every(row=>row.node.getAttribute('style')===row.style&&(!row.children||(row.node.childNodes.length===row.children.length&&row.children.every((child,i)=>row.node.childNodes[i]===child)))),coverRemoved:!saved.cover?.isConnected};}
  if(window.__cfLayoutFault)throw new Error('A layout fault is already owned');
  const saved={family,rows:[]};window.__cfLayoutFault=saved;
  const target=selector=>{const nodes=document.querySelectorAll(selector);if(nodes.length!==1)throw new Error('Fault needs exactly one '+selector);const node=nodes[0];saved.rows.push({node,style:node.getAttribute('style')});return node};
  const css=(node,values)=>{for(const[k,v]of Object.entries(values))node.style.setProperty(k,String(v),'important')};
  const controls=snapshot.controls.filter(c=>c.visible&&c.enabled&&c.fullExposure),first=controls[0],sheet=snapshot.sheets.find(s=>s.visible);
  if(family==='TOPBAR_SYNC')css(target('html'),{'--topbar-h':snapshot.roots.topbar.rect.height+12+'px'});
  else if(family==='DOCK_IDENTITY')css(target('#docksets'),{display:'none'});
  else if(family==='DOCK_GEOMETRY')css(target(snapshot.compact?'#dockcodex':'#docksets'),{transform:'translateX(7px)'});
  else if(family==='TARGET_FLOOR')css(target(first.key),{width:'43px','min-width':'0',padding:'0'});
  else if(family==='VIEWPORT')css(target(first.key),{transform:`translateX(${-first.rect.right-8}px)`});
  else if(family==='TARGET_HIT'){const cover=document.createElement('div');saved.cover=cover;cover.dataset.layoutFault='hit-cover';
    css(cover,{position:'fixed',left:first.rect.left+'px',top:first.rect.top+'px',width:first.rect.width+'px',height:first.rect.height+'px','z-index':'2147483647',background:'#000','pointer-events':'auto'});document.body.append(cover);}
  else if(family==='INTERACTIVE_OVERLAP'){const second=controls.find(c=>c.key!==first.key&&c.nativeOwner!==first.nativeOwner&&!c.ancestors.includes(first.key)&&!first.ancestors.includes(c.key));if(!second)throw new Error('Need two independent controls');
    const node=target(second.key),before=node.getBoundingClientRect();css(node,{translate:`${first.rect.left-before.left}px ${first.rect.top-before.top}px`});}
  else if(family==='LANE_OVERLAP'){if(!sheet||!snapshot.roots.toast.visible)throw new Error('Need a populated sheet and painted toast for lane fault');const node=target('#toast'),before=node.getBoundingClientRect();
    css(node,{opacity:'1',translate:`${sheet.rect.left-before.left}px ${sheet.rect.top-before.top}px`});}
  else if(family==='SHEET_POPULATION'){if(!sheet)throw new Error('Need active sheet');const node=target(sheet.key),row=saved.rows.at(-1);row.children=[...node.childNodes];
    node.replaceChildren(...[...node.children].filter(child=>child.matches('.sheet-header,.survey-head,[data-pnx],[data-survey-close]')));}
  else if(family==='SHEET_HEADER'){if(!sheet?.header)throw new Error('Need active header');css(target(sheet.header.key),{position:'static'});}
  else if(family==='CONTENT_CLIP'){const piece=sheet?.content.find(p=>p.owner!==sheet.key);if(!piece)throw new Error('Need substantive text owner');
    css(target(piece.owner),{width:'8px','max-width':'8px','min-width':'0',height:'8px','max-height':'8px','overflow':'hidden','white-space':'nowrap'});}
  else throw new Error('Unknown layout fault '+family);
  return{family,targets:saved.rows.map(row=>row.node.id||row.node.tagName),before: snapshot,scope:'CSS/DOM diagnostic only; inspect actual post-fault rectangles before crediting red'};
}
