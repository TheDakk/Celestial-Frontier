# Prepared U4 layout contract — not executed

Prepared only in `/private/tmp/cf-u4-layout-prepared-20260906` while U2 runs.
No checkout change, test job, build, browser run, screenshot claim, or gate PASS.

Files:
- `ui-layout-contract.mjs`: self-contained DOM reader, pure assessor, separately named reversible fault owner (under 300 lines).
- `ui-layout-contract.test.ts`: ten named synthetic viewport fixtures, every checker family's red/restored controls, the retained 22.5px geometry, nonempty-sheet guards, ancestry exclusions, clipping/scroll reachability, serialized reader, and exact fault restoration.
- `PREPARATION.json`: payload SHA-256 and exact existing-source anchors.
- `apply-at-u4.py`: root/branch/HEAD/clean tracked source and anchor checks; adds only the two absent destination files. It does not edit the U2 runner or run anything.

At U4, root first reviews the prepared source and applicable U3 changes, then runs from the owned root:

```sh
python3 /private/tmp/cf-u4-layout-prepared-20260906/apply-at-u4.py --u4-reviewed FULL_CURRENT_HEAD
```

Runner integration remains a small explicit U4 change. Import `readLayoutSnapshot`, `assessLayoutSnapshot`, `applyLayoutFault`, `LAYOUT_VIEWPORTS`, and `LAYOUT_FAMILIES`. Reuse the existing normal-game/native-input/evaluation/frame-settlement owner. After a native surface opens and frames settle, serialize `readLayoutSnapshot.toString()` and assess its result with the exact named viewport and expected sheet IDs, for example `{viewport, expectedSheets:['setpanel']}`. The default requires at least one visibly populated sheet. Only an explicitly named main/shell-only shot may use `{viewport,expectedSheets:[],requireActiveSheet:false}`. The caller retains source/build identity and the observed scope.

For each family, retain a green baseline, invoke the serialized fault owner, settle through the existing named frames, read fresh real geometry, and require a finding with that exact family before crediting a successful negative control. Then restore in cleanup, require `exact` and `coverRemoved`, settle, and independently re-read a green snapshot. Retain the primary exception and any separate cleanup exception; never retry unchanged source. Fault recipes may require a specific surface: lane controls require a painted toast and populated sheet; content controls require substantive text; header controls require a real header. Select these native/labelled presentation states intentionally rather than skipping an unavailable control. The same-family pure mutants are unit guards, not a replacement for this browser sequence.

Selection uses the first ten actual Glass viewports, from 320×568@2 through 1920×1080@1; ultrawide and 8K remain explicitly outside this proposed contract. The U4 caller must require the exact ten-view inventory and intended preference variants. The contract does not supply a screenshot collector or 28-screen comparison report.

Actual surface ambiguities to resolve against U3 before integration:
- Native Inventory currently lacks the old paperdoll/three-tab structure. This contract measures its actual instance list/detail dialog, not an invented legacy equivalent.
- The U2 diagnostic can have no native Survey after fresh Skip. U4's Survey/landing comparison must select a real populated route or explicitly retain a labelled geometry fixture; a missing native sheet fails whenever declared expected.
- `.panel` headers now use `.sheet-header`; Survey uses `.survey-head`. Inventory's true dialog header must be verified as sticky after U3, not assumed from its `h2` tag.
- Associated radio/checkbox labels are explicit native touch owners. Decorative children of the same native control are excluded only with retained ancestor identity; independent nested actions still intersect and fail.
- Scene canvases are excluded from interactive overlap. Active-sheet text clipping is read through actual client rectangles, ancestor overflow, and scroll extent; offscreen content is exempt only when its real scroll owner can reach it. Pure preparation has not proved live clipping/DOM support.

No workflow, check-profile admission, Runtime SDK, source gameplay owner, U2 tool, or evidence contract is changed by the apply script. Any addition to the develop gate remains a proposal under U4's handoff boundary.
