# U4 completion plan — bounded source review, not a gate

Prepared only; no source edit, generated-script execution, unit test, build or browser.
The existing five-file preparation stays unchanged. New JSON files are empty collection
plans, not observations. They contain zero screenshot/native/layout acceptance claims.

## What is missing

1. **Executable collector and terminal verifier.** The existing proposal supplies a DOM
   reader/assessor and synthetic tests, but no native surface driver, run inventory,
   screenshots, exact source→normal-build association or immutable report verifier.
   Its unit fixture is not a ten-view run. Reuse `ui-sheet-review.mjs`'s lock/browser/
   fresh-context/evaluator/font-two-frame/native-input owners; generalize its surface
   sequence explicitly at U4, not its current Settings-only scope. Preserve raw failing
   expressions, trace/screenshots and first-nonzero stop. Never normalize a changed route.
2. **Explicit coverage admission.** Use exact ten named current Glass/U2 viewports in
   `ten-view-coverage-template.json`, including DPR/mobile/safe-inset identity and default
   plus fs-xl/Mono state. Declare each required implemented surface and conditional real
   state before collection; missing opportunities remain unresolved, not omitted PASS.
   Geometry must also include current Survey+biosphere+notice pressure and live content
   scroll/reachability; 28 golden pictures do not replace those checks.
3. **Calibrate the proposed checker before native use.** Source inspection identifies:
   - Partly clipped controls are unconditionally exempted at contract line128 after the
     full-rectangle 44px floor. An icon-only 44px button clipped to a 22px exposed target
     can avoid TARGET_HIT if its glyph remains visible. Require legitimate per-axis native
     scroll reachability/reveal; hidden/clip with no reachable owner must fail.
   - LANE_OVERLAP checks sheet/toast against lower lanes, but not lower-lane pairs
     (caption↔hint↔dock) or independent sheet pairs (Survey↔Planetside). Add exact
     pairwise families with documented modal/ancestor ownership exclusions.
   - Snapshot identity checks width/height/DPR but not the declared safe insets or touch
     mode. Retain and validate those settings against the named viewport, with mutants.
   - Fault cleanup currently directly removes an originally absent style. Use the
     established native empty-before-remove restoration and prove exact attribute bytes,
     node identities, focus, painted restoration and cleanup failures independently.
   These are inspection findings, not executed red controls. Current 200px/52px wide
   utility-dock geometry and documentElement height publication are correct owners;
   unused 72/80px launcher tokens are not evidence they changed.
4. **Native negative controls.** The 11 existing families need applicable live baseline →
   measured fault → exact-family RED → exact restoration → fresh baseline proof, plus
   controls for new safe-area/clipping/lane checks. Synthetic object edits and a changed
   style declaration alone cannot count. Modal controls must preserve the true background
   inert/aria-hidden lifetime. Do not use display-only fixtures as native content proof.
5. **All 28 paired records.** `paired-screen-plan.json` binds every existing legitimate
   baseline by ID/hash/viewport/population and names a current owner or explicit mismatch.
   Capture native v2 screens at those exact golden dimensions independently of the ten
   geometry devices. Both tablet baseline IDs are 834×1112, whereas the ten-view matrix
   uses 768×1024/1024×768; do not silently relabel one as a golden match.
   Complete source/build/runtime/input/state/image carriers and a reviewed difference
   ledger for every ID. Preserve intended token/style differences, unintended geometry,
   and unresolved content/state separately. Image hashes establish integrity, not visual
   equality; no automated pixel threshold against these historical PNGs.
6. **Fail-closed completion.** Admit one unchanged committed source with all ten complete
   viewport inventories, all declared surface/preference outcomes, all required live
   negative/restored controls, exactly 28 reviewed pairs, zero unintended layout findings,
   zero unresolved owner/state gaps and no runtime/instrument failures. Bind the terminal
   verifier to the exact run and reject stale, missing, duplicate or foreign-source
   carriers. Keep check-profile admission as a handoff proposal; no workflow/Actions edit.

## Current owner/state blockers in the 28-pair inventory

- **Five Inventory goldens:** v1 populated Materials/Craftables/Gear tabs, paperdoll,
  equipped sockets and bag grid have no current equivalent v2 renderer. Current
  InventoryPanelController is an exact-instance list/detail surface. The paperdoll
  width cap cannot be proved on an absent element. This is not an intended token change.
- **One Earth Search golden:** v1 input immediately opens world search results. V2
  `search-travel.ts:327–370` only handles Enter and routes non-CF1 text to Compendium.
  Native CF1 Earth Survey is a real route but is not that search-results screen.
- **Two Shipyard goldens:** a renderer exists, but v1 uses its known populated save;
  fresh normal v2 default does not prove the equivalent populated construction state.
  Resolve legitimate state provenance or retain the mismatch; never synthesize a v1
  save into v2 or label an empty/default view identical-state proof.
- Twenty other baseline IDs have identifiable current owners; this is source mapping,
  not twenty ready/passed comparisons. Records/Guide/Charters inherit content differences
  that still need explicit review, and U3 must finish before U4 acceptance.

The Inventory nested title/shared-header boundary is already retained in its U3 temp
proposal. No new missing gameplay/model work is authorized by this mapping alone.
Old U1 navigation and viewport-restoration causes, physical UAT and U2 reds remain open.
Codex can use this plan after U3; Claude remains untouched and Nick need not open Claude
for this preparation. No hosted attempt, Inkscape or Phase 2 work is included.
