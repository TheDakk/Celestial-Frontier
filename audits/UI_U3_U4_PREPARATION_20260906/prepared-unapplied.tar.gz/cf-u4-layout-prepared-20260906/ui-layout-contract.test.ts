import { createRequire } from 'node:module';
import { describe, expect, it } from 'vitest';
// @ts-expect-error Browser evidence module intentionally ships executable JavaScript.
import { LAYOUT_VIEWPORTS, LAYOUT_FAMILIES, readLayoutSnapshot, assessLayoutSnapshot, applyLayoutFault } from '../tools/ui-layout-contract.mjs';
const require = createRequire(import.meta.url);
const { JSDOM } = require('jsdom');
const rect = (left: number, top: number, width: number, height: number) => ({ left, top, right: left + width, bottom: top + height, width, height });
const surface = (key: string, r: any, visible = true) => ({ key, rect: r, exposed: r, visible, clips: [], position: 'fixed', overflowX: 'visible', overflowY: 'visible', scrollWidth: r.width, clientWidth: r.width, scrollHeight: r.height, clientHeight: r.height });
function fixture(vp = LAYOUT_VIEWPORTS[0]): any {
  const { width: w, height: h } = vp, safe = { top: 0, right: 0, bottom: 0, left: 0, ...vp.safe };
  const compact = w <= 700 || (w <= 900 && w > h), landscape = compact && w > h;
  const dockWidth = compact ? Math.min(320, landscape ? (w - safe.left - safe.right - 36) / 2 : w - safe.left - safe.right - 20) : 200;
  const dockHeight = compact ? 92 : 44, dockLeft = landscape ? w - safe.right - 12 - dockWidth : compact ? (w - dockWidth) / 2 : w - safe.right - 16 - dockWidth;
  const dockTop = h - safe.bottom - 12 - dockHeight, pitch = compact ? dockWidth / 5 : 52;
  const roots: any = { topbar: surface('#topbar', rect(0, 0, w, 100)), dock: surface('#dock', rect(dockLeft, dockTop, dockWidth, dockHeight)),
    hintpill: surface('#hintpill', rect(12, h - safe.bottom - 144, w - 24, 20), !landscape),
    ctxbar: surface('#ctxbar', rect(12, h - safe.bottom - 184, w - 24, 20), !landscape) };
  const lowerTop = Math.min(dockTop, ...[roots.hintpill, roots.ctxbar].filter(r => r.visible).map(r => r.rect.top));
  roots.toast = surface('#toast', rect(landscape ? dockLeft : 12, lowerTop - 48, landscape ? dockWidth : Math.min(280, w - 24), 40));
  const sheetRect = rect(safe.left + 8, landscape ? 8 : 110, landscape ? dockWidth : Math.min(280, w - safe.left - safe.right - 16), landscape ? h - safe.bottom - 28 : lowerTop - 166);
  const header = { ...surface('#header', rect(sheetRect.left + 8, sheetRect.top + 8, sheetRect.width - 68, 44)), position: 'sticky' };
  const closeRect = rect(sheetRect.right - 48, sheetRect.top + 8, 44, 44);
  const sheets = [{ ...surface('#setpanel', sheetRect), header, closeKeys: ['#close'], content: [{ owner: '#text', text: 'Native populated Settings', rect: rect(sheetRect.left + 8, sheetRect.top + 60, 100, 16), clips: [] }] }];
  const boardIds = ['docksurvey', 'dockcodex', 'primechip', 'dockshipyard', 'dockatlas'];
  const utilityIds = ['dockrecords', 'docknotifications', 'dockguide', 'docksets'];
  const boards = compact ? boardIds.map((id, i) => ({ ...surface('#' + id, rect(dockLeft + pitch * i + 2, dockTop, pitch - 4, 44)), id, intrinsicHeight: 44, face: null }))
    : [{ ...surface('#primechip', rect(w / 2 - 35, 10, 70, 44)), id: 'primechip', intrinsicHeight: 44, face: null }];
  const utilities = utilityIds.map((id, i) => {
    const r = rect(dockLeft + (compact ? pitch * (i + 1) - 22 : pitch * i), dockTop + (compact ? 48 : 0), 44, 44);
    return { ...surface('#' + id, r), id, intrinsicHeight: 44, face: surface('#' + id + '-face', rect(r.left + 4, r.top + 4, 36, 36)) };
  });
  const dockButtons = [...boards, ...utilities];
  const controls = [...dockButtons, surface('#dockinventory', rect(safe.left + 12, 12, 128, 44)), surface('#close', closeRect)].map(c => ({ ...c, nativeOwner: c.key, touchOwner: c.key, ancestors: [], enabled: true, fullExposure: true, hit: true, hitOwner: c.key, name: c.key }));
  return { schema: 'cf-v2-layout-snapshot/v1', viewport: { ...rect(0, 0, w, h), dpr: vp.dpr }, bodyClass: 'panel-open', compact, panelOpen: true, safe,
    published: { topbar: 100, dock: dockHeight }, roots, controls, sheets, dockButtons, pageOverflow: false, inventoryOverflow: false, exclusions: [{ kind: 'scene-backdrop', selectors: ['#scene'] }] };
}
const assess = (s: any, vp = LAYOUT_VIEWPORTS[0]) => assessLayoutSnapshot(s, { viewport: vp, expectedSheets: ['setpanel'] });
const move = (r: any, dx: number, dy = 0) => rect(r.left + dx, r.top + dy, r.width, r.height);

describe('prepared U4 contract — synthetic unit geometry is not native browser evidence', () => {
  it.each(LAYOUT_VIEWPORTS)('accepts the exact named $label geometry', (vp: any) => {
    const result = assess(fixture(vp), vp); expect(result.findings).toEqual([]); expect(result.pass).toBe(true);
  });
  it('rejects one deliberate fault in every checker family, then accepts the untouched carrier again', () => {
    const mutants: Record<string, (s: any) => void> = {
      VIEWPORT: s => { s.controls[0].rect = move(s.controls[0].rect, -500); s.controls[0].exposed = rect(0, 0, 0, 0); s.controls[0].fullExposure = false; },
      TOPBAR_SYNC: s => { s.published.topbar += 12; },
      DOCK_IDENTITY: s => { s.dockButtons.pop(); },
      DOCK_GEOMETRY: s => { s.dockButtons[1].rect = move(s.dockButtons[1].rect, 7); },
      TARGET_FLOOR: s => { s.controls[0].rect.width = 43; s.controls[0].rect.right = s.controls[0].rect.left + 43; s.controls[0].exposed = s.controls[0].rect; },
      TARGET_HIT: s => { s.controls[0].hit = false; s.controls[0].hitOwner = '#cover'; },
      INTERACTIVE_OVERLAP: s => { s.controls[1].rect = { ...s.controls[0].rect }; s.controls[1].exposed = s.controls[1].rect; },
      LANE_OVERLAP: s => { s.roots.toast.rect = { ...s.sheets[0].rect }; },
      SHEET_POPULATION: s => { s.sheets[0].content = []; },
      SHEET_HEADER: s => { s.sheets[0].header.position = 'static'; },
      CONTENT_CLIP: s => { const p = s.sheets[0].content[0]; p.clips = [{ key: '#text', x: true, y: true, modeX: 'hidden', modeY: 'hidden', rect: rect(p.rect.left, p.rect.top, 8, 8), scrollLeft: 0, scrollTop: 0, scrollWidth: 100, scrollHeight: 16, clientWidth: 8, clientHeight: 8 }]; },
    };
    expect(Object.keys(mutants).sort()).toEqual([...LAYOUT_FAMILIES].sort());
    for (const [family, mutate] of Object.entries(mutants)) {
      const clean = fixture(), altered = structuredClone(clean); mutate(altered); const result = assess(altered);
      expect(result.pass, family).toBe(false); expect(result.findings.some((f: any) => f.code === family), family).toBe(true);
      expect(result.findings.find((f: any) => f.code === family).detail.length).toBeGreaterThan(10);
      expect(assess(clean).pass, family + ' restoration').toBe(true);
    }
  });
  it('retains the reported b457a7a 22.5px Planetside/hint intersection', () => {
    const s = fixture(); s.sheets[0].key = '#planetside'; s.sheets[0].rect = rect(12, 210, 296, 180);
    s.roots.hintpill.rect = rect(12, 367.5, 296, 76.5);
    const result = assessLayoutSnapshot(s, { viewport: LAYOUT_VIEWPORTS[0], expectedSheets: ['planetside'] });
    const finding = result.findings.find((f: any) => f.target === '#planetside + #hintpill');
    expect(finding.code).toBe('LANE_OVERLAP'); expect(finding.actual.intersection.height).toBe(22.5);
  });
  it('does not count an absent, header-only, wrong viewport or truncated inventory as PASS', () => {
    const s = fixture(); s.sheets = []; expect(assess(s).findings.some((f: any) => f.code === 'SHEET_POPULATION')).toBe(true);
    expect(assessLayoutSnapshot(s, { viewport: LAYOUT_VIEWPORTS[0], expectedSheets: [], requireActiveSheet: false }).pass).toBe(true);
    s.inventoryOverflow = true; expect(assess(s).findings.some((f: any) => f.code === 'SNAPSHOT')).toBe(true);
    expect(assess(fixture(), { label: 'invented' }).pass).toBe(false);
  });
  it('excludes only same-native-owner ancestry, not overlapping independent actions', () => {
    const s = fixture(), child = structuredClone(s.controls[0]); child.key = '#inner-label'; child.ancestors = [s.controls[0].key]; s.controls.push(child);
    expect(assess(s).exclusions.some((e: any) => e.kind === 'same-native-control-ancestry')).toBe(true);
    child.nativeOwner = '#different-button'; expect(assess(s).findings.some((f: any) => f.code === 'INTERACTIVE_OVERLAP')).toBe(true);
  });
  it('permits actual scroll-reachable content but rejects unreachable transformed or hidden clipping', () => {
    const s = fixture(), piece = s.sheets[0].content[0], top = s.sheets[0].rect.top;
    piece.rect = rect(24, top + 500, 100, 16); piece.clips = [{ key: '#setpanel', x: false, y: true, modeX: 'visible', modeY: 'auto', rect: s.sheets[0].rect, scrollLeft: 0, scrollTop: 0, scrollWidth: 280, scrollHeight: 900, clientWidth: 280, clientHeight: 222 }];
    expect(assess(s).findings.filter((f: any) => f.code === 'CONTENT_CLIP')).toEqual([]);
    piece.clips[0].scrollHeight = 200; expect(assess(s).findings.some((f: any) => f.code === 'CONTENT_CLIP')).toBe(true);
  });
  it('executes the serialized reader and retains own-element clipping without scene canvas targets', () => {
    const dom = new JSDOM('<!doctype html><style>*{opacity:1}</style><body><canvas id="scene" tabindex="0"></canvas><div id="topbar"></div><div id="dock"><button id="docksets">Settings</button></div><div id="hintpill"></div><div id="ctxbar"></div><div id="toast"></div><aside id="setpanel" class="panel"><h3 class="sheet-header">Header only</h3><button data-pnx="set">Close</button><p id="text" style="overflow-x:hidden;overflow-y:hidden">Real content</p></aside></body>', { runScripts: 'outside-only' });
    const w = dom.window; w.CSS = { escape: (v: string) => v }; w.document.elementFromPoint = () => w.document.getElementById('docksets');
    w.HTMLElement.prototype.getBoundingClientRect = () => rect(10, 10, 100, 44);
    w.HTMLElement.prototype.getClientRects = () => [rect(10, 10, 100, 44)];
    w.Range.prototype.getClientRects = () => [rect(10, 10, 100, 16)];
    const result = w.eval('(' + readLayoutSnapshot.toString() + ')()');
    expect(result.controls.some((c: any) => c.key === '#scene')).toBe(false);
    const sheet = result.sheets.find((p: any) => p.key === '#setpanel'); expect(sheet.content).toHaveLength(1);
    expect(sheet.content[0].clips.some((c: any) => c.key === '#text' && c.modeX === 'hidden')).toBe(true);
    w.close();
  });
  it('executes each CSS fault owner and restores absent/empty styles plus original child identities', () => {
    for (const family of LAYOUT_FAMILIES) {
      const s = fixture(), ids = new Set(s.controls.map((c: any) => c.key.slice(1))); ids.delete('close');
      const dom = new JSDOM('<!doctype html><body>' + [...ids].map(id => `<button id="${id}">Target</button>`).join('') + '<div id="toast" style=""></div><aside id="setpanel"><h3 id="header" class="sheet-header">Title</h3><button id="close" data-pnx="set">Close</button><p id="text">Native body</p></aside></body>', { runScripts: 'outside-only' });
      const w = dom.window; w.HTMLElement.prototype.getBoundingClientRect = () => rect(12, 240, 100, 44);
      const before = w.document.documentElement.outerHTML, bodyChild = w.document.getElementById('text');
      const apply = w.eval('(' + applyLayoutFault.toString() + ')'); apply(family, s);
      const receipt = apply('', s, true); expect(receipt.exact, family).toBe(true); expect(receipt.coverRemoved, family).toBe(true);
      expect(w.document.documentElement.outerHTML, family).toBe(before); expect(w.document.getElementById('text')).toBe(bodyChild); w.close();
    }
  });
});
