#!/usr/bin/env python3
"""Add only the two prepared contract files after root reviews U4 scope.
No tests, builds, browser, Git write, or runner integration is performed.
"""
import hashlib, json, os, pathlib, subprocess, sys, tempfile
ROOT = pathlib.Path('/Users/nick/Projects/celestial-frontier-openai-mac')
PREP = pathlib.Path(__file__).resolve().parent
assert len(sys.argv) == 3 and sys.argv[1] == '--u4-reviewed', 'usage: apply-at-u4.py --u4-reviewed FULL_CURRENT_HEAD'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
assert pathlib.Path.cwd().resolve() == ROOT
assert pathlib.Path(git('rev-parse', '--show-toplevel')).resolve() == ROOT
assert git('branch', '--show-current') == 'openai/mac'
assert git('rev-parse', 'HEAD') == sys.argv[2]
assert git('diff', '--name-only', 'HEAD') == '', 'Finish existing tracked work before applying U4'
manifest = json.loads((PREP / 'PREPARATION.json').read_text())
for check in manifest['sourceChecks']:
    text = (ROOT / check['file']).read_text()
    assert text.count(check['exact']) == check['count'], f"Changed source anchor: {check['file']} {check['exact']}"
prepared = []
for row in manifest['files']:
    payload = (PREP / row['source']).read_bytes()
    assert hashlib.sha256(payload).hexdigest() == row['sha256'], 'Prepared payload changed since manifest'
    destination = ROOT / row['destination']
    assert not destination.exists(), f'Refuse overwrite: {destination}'
    prepared.append((payload, destination))
temps = []
try:
    for payload, destination in prepared:
        descriptor, name = tempfile.mkstemp(prefix='.u4-contract-', suffix='.pending', dir=destination.parent)
        tmp = pathlib.Path(name); temps.append(tmp)
        with os.fdopen(descriptor, 'wb') as stream: stream.write(payload)
        assert tmp.read_bytes() == payload
    for (_, destination), tmp in zip(prepared, temps):
        os.link(tmp, destination)  # Atomic refusal if a destination appeared after preflight.
        assert destination.read_bytes() == tmp.read_bytes()
finally:
    for tmp in temps: tmp.unlink(missing_ok=True)
print(json.dumps({'applied': [str(destination) for _, destination in prepared], 'source': sys.argv[2],
                  'tests': 'NOT RUN', 'browser': 'NOT RUN', 'runnerIntegration': 'NOT APPLIED'}))
