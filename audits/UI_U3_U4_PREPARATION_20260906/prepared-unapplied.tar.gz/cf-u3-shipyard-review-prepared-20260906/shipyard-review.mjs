/* Prepared U3 Shipyard presentation review; not executed during preparation.
 * node shipyard-review.mjs CONFIG_JSON NEW_OUTPUT_DIRECTORY
 * CONFIG: {repository,before:{directory,sourceCommit,buildReceipt},current:{...}} */
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
const config=JSON.parse(fs.readFileSync(process.argv[2],'utf8')),repo=fs.realpathSync(config.repository),out=path.resolve(process.argv[3]);
assert.equal(repo,'/Users/nick/Projects/celestial-frontier-openai-mac');
const git=args=>execFileSync('git',args,{cwd:repo,encoding:'utf8'}).trim(),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
assert.equal(git(['rev-parse','--show-toplevel']),repo);assert.equal(git(['branch','--show-current']),'openai/mac');
const head=git(['rev-parse','HEAD']);assert.equal(git(['diff','--name-only','HEAD']),'');assert.equal(config.current.sourceCommit,head);
assert(!fs.existsSync(out),'Never overwrite prior evidence');fs.mkdirSync(out,{recursive:true});
const {openChromiumCdp}=await import(pathToFileURL(path.join(repo,'port/v2/tools/browsercdp.mjs')));
const {installNativeReviewTrace,assessNativeReviewDelivery}=await import(pathToFileURL(path.join(repo,'port/v2/tools/ui-shell-review.mjs')));
const {createReviewEvaluator,reviewFrameSettlement,readReviewFrameSettlements,assessReviewFrameSettlement}=await import(pathToFileURL(path.join(repo,'port/v2/tools/ui-review-evaluation.mjs')));
const carrier=file=>{const b=fs.readFileSync(file);return{path:file,bytes:b.length,sha256:sha(b)};};
const goldenRoot=path.join(repo,'port/baseline-v1.8.9/screens'),goldenFile=path.join(goldenRoot,'MANIFEST.json');
const golden=JSON.parse(fs.readFileSync(goldenFile,'utf8')).shots.filter(r=>/^shipyard-(phone|desktop)$/.test(r.id));
assert.equal(golden.length,2);for(const r of golden)assert.equal(carrier(path.join(goldenRoot,r.file)).sha256,r.sha256);
const report={schema:'cf-u3-shipyard-normal-review/v1',status:'RUNNING',certification:false,toolingSource:head,startedAt:new Date().toISOString(),
  config:carrier(path.resolve(process.argv[2])),driver:carrier(process.argv[1]),golden:{manifest:carrier(goldenFile),shots:golden},builds:[],rows:[],runtimeErrors:[],
  limitations:['Fresh normal-build default models only; native startup Skip and presentation controls only. No injected save, probe hooks or gameplay actions.',
    'v1 Shipyard goldens used populatedSave=true. They are associated human references, not identical-state raster targets; no pixel-difference acceptance threshold.',
    'Native taps/mouse clicks plus native wheel scrolling; no physical-device, touch-swipe, Safari, full U3 or gameplay-outcome claim.',
    'Source commits/build-receipt carriers are supplied by the runner; asset hashes establish exact served bytes, not independent reconstruction of a build.',
    'Both historical U1 causes remain OPEN. No navigation normalization, debugger, viewport restoration, automatic retry, Inkscape or hosted action.']};
const write=()=>fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
function targetState(selector){
  const n=document.querySelector(selector),box=e=>{const r=e.getBoundingClientRect();return{left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height};};
  const css=e=>{if(e.id)return'#'+CSS.escape(e.id);const parts=[];for(let x=e;x&&x!==document;x=x.parentElement){const tag=x.tagName.toLowerCase(),siblings=x.parentElement?[...x.parentElement.children].filter(q=>q.tagName===x.tagName):[x];parts.unshift(tag+':nth-of-type('+(siblings.indexOf(x)+1)+')');if(x.parentElement?.id){parts.unshift('#'+CSS.escape(x.parentElement.id));break;}}return parts.join('>');};
  if(!n)return{selector,exists:false,usable:false,reason:'absent'};
  const r=box(n),s=getComputedStyle(n),clip={left:0,top:0,right:innerWidth,bottom:innerHeight},owners=[];
  for(let a=n.parentElement;a;a=a.parentElement){const z=getComputedStyle(a),b=box(a),c={left:b.left+a.clientLeft,top:b.top+a.clientTop,right:b.left+a.clientLeft+a.clientWidth,bottom:b.top+a.clientTop+a.clientHeight};
    if(/auto|scroll|hidden|clip/.test(z.overflowX)){clip.left=Math.max(clip.left,c.left);clip.right=Math.min(clip.right,c.right);}
    if(/auto|scroll|hidden|clip/.test(z.overflowY)){clip.top=Math.max(clip.top,c.top);clip.bottom=Math.min(clip.bottom,c.bottom);}
    if(/auto|scroll/.test(z.overflowY)&&a.scrollHeight>a.clientHeight+1)owners.push({selector:css(a),rect:b,scrollTop:a.scrollTop,max:a.scrollHeight-a.clientHeight});
  }
  for(const o of owners){const node=document.querySelector(o.selector),b=o.rect,visible={left:Math.max(0,b.left+node.clientLeft),right:Math.min(innerWidth,b.left+node.clientLeft+node.clientWidth),top:Math.max(0,b.top+node.clientTop),bottom:Math.min(innerHeight,b.top+node.clientTop+node.clientHeight)};
    for(let a=node.parentElement;a;a=a.parentElement){const z=getComputedStyle(a),q=box(a);if(/auto|scroll|hidden|clip/.test(z.overflowY)){visible.top=Math.max(visible.top,q.top+a.clientTop);visible.bottom=Math.min(visible.bottom,q.top+a.clientTop+a.clientHeight);}if(/auto|scroll|hidden|clip/.test(z.overflowX)){visible.left=Math.max(visible.left,q.left+a.clientLeft);visible.right=Math.min(visible.right,q.left+a.clientLeft+a.clientWidth);}}
    o.visible=visible;o.point={x:(visible.left+visible.right)/2,y:(visible.top+visible.bottom)/2};const h=document.elementFromPoint(o.point.x,o.point.y);o.hit=!!h&&(node===h||node.contains(h));}
  const point={x:(r.left+r.right)/2,y:(r.top+r.bottom)/2},h=document.elementFromPoint(point.x,point.y),inside=point.x>=clip.left&&point.x<=clip.right&&point.y>=clip.top&&point.y<=clip.bottom,
    visible=s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity)>0&&r.width>0&&r.height>0,
    enabled=!n.disabled&&!n.closest('[inert],[aria-hidden="true"]'),hit=!!h&&(h===n||n.contains(h));
  return{selector,exists:true,tag:n.tagName,name:n.getAttribute('aria-label')||n.textContent?.trim(),rect:r,clip,point,inside,visible,enabled,hit,
    hitOwner:h?{tag:h.tagName,id:h.id,close:h.closest('[data-pnx]')?.getAttribute('data-pnx')??null}:null,
    active:document.activeElement===n,owners,usable:visible&&enabled&&inside&&hit};
}
function panelState(){
  const p=document.getElementById('shipyardpanel'),rect=n=>{const r=n.getBoundingClientRect();return{left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height};},close=p.querySelector('[data-pnx="shipyard"]'),c=close?rect(close):null,
    hit=c?document.elementFromPoint((c.left+c.right)/2,(c.top+c.bottom)/2):null,body=p.querySelector('[data-engineering-panel-body]'),b=rect(p);
  return{visible:getComputedStyle(p).display!=='none',rect:b,ariaHidden:p.getAttribute('aria-hidden'),text:p.textContent.trim(),html:p.innerHTML,
    close:{count:p.querySelectorAll('[data-pnx="shipyard"]').length,rect:c,hit:!!hit&&(hit===close||close.contains(hit)),focused:document.activeElement===close,position:close?getComputedStyle(close).position:null},
    bodyState:body?.querySelector('[data-engineering-state]')?.getAttribute('data-engineering-state')??null,unavailable:body?.querySelector('[data-engineering-unavailable]')?.textContent??null,
    overview:p.querySelectorAll('[data-engineering-ship="overview"]').length,previews:p.querySelectorAll('[data-cf-shipyard-preview="v1"]').length,
    sections:[...p.querySelectorAll('details[data-engineering-section]')].map(d=>({id:d.dataset.engineeringSection,open:d.open,summary:d.querySelector(':scope>summary')?.textContent,rows:d.querySelectorAll('.engineering-row').length})),
    jumps:[...p.querySelectorAll('button[data-engineering-jump]')].map(n=>({id:n.dataset.engineeringJump,disabled:n.disabled,controls:n.getAttribute('aria-controls')})),
    focus:{id:document.activeElement?.id??null,key:document.activeElement?.getAttribute('data-focus-key')??null},
    trail:[...document.querySelectorAll('#trail .seg')].map(n=>n.textContent),horizontalOverflow:document.documentElement.scrollWidth>innerWidth,
    scrollOwners:[p,...p.querySelectorAll('*')].filter(n=>/auto|scroll/.test(getComputedStyle(n).overflowY)&&n.scrollHeight>n.clientHeight+1).map(n=>({selector:n.id?'#'+CSS.escape(n.id):null,top:n.scrollTop,max:n.scrollHeight-n.clientHeight})).filter(n=>n.selector)};
}
function installScrollTrace(){
  const t=window.__cfU3ShipyardScroll={events:[],overflow:false,active:null};
  for(const type of ['wheel','scroll'])document.addEventListener(type,e=>{if(t.events.length>=1000){t.overflow=true;return;}const a=t.active;t.events.push({type,trusted:e.isTrusted,at:performance.now(),selector:a?.selector??null,
    ownerInPath:!!a&&e.composedPath().includes(a.node),targetId:e.target?.id??null,scrollTop:a?.node.scrollTop??null,deltaY:e.deltaY??null});},{capture:true,passive:true});return true;
}
const sizes=[[390,844],[1440,900],[320,568],[667,375]],types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.woff2':'font/woff2','.wav':'audio/wav'};
let browser;
try{
  browser=await openChromiumCdp({label:'U3 Shipyard scoped normal-build review',userDataPrefix:'cf-u3-shipyard',onEvent:e=>{if(e.method==='Runtime.exceptionThrown'){report.runtimeErrors.push({sessionId:e.sessionId,detail:e.params.exceptionDetails});write();}}});report.browser=browser.browser;
  for(const label of ['before','current']){
    const input=config[label],directory=fs.realpathSync(input.directory);assert(/^[a-f0-9]{40}$/.test(input.sourceCommit));git(['cat-file','-e',input.sourceCommit+'^{commit}']);
    const index=fs.readFileSync(path.join(directory,'index.html')),worker=fs.readFileSync(path.join(directory,'service-worker.js'));assert(/name="cf-build-mode" content="distributable"/.test(index.toString()));
    const match=/const ASSETS=Object\.freeze\((\[[^\n]+\])\);/u.exec(worker.toString());assert(match,'normal asset inventory missing');const assets=JSON.parse(match[1]);
    for(const a of assets){const file=path.resolve(directory,'.'+a.path);assert(file.startsWith(directory+path.sep));assert.equal(carrier(file).sha256,a.sha256);}
    report.builds.push({label,directory,sourceCommit:input.sourceCommit,buildReceipt:carrier(fs.realpathSync(input.buildReceipt)),index:carrier(path.join(directory,'index.html')),worker:carrier(path.join(directory,'service-worker.js')),assets});write();
    const server=http.createServer((req,res)=>{try{const request=decodeURIComponent(new URL(req.url,'http://localhost').pathname),file=path.resolve(directory,'.'+(request==='/'?'/index.html':request));assert(file.startsWith(directory+path.sep)&&fs.statSync(file).isFile());res.writeHead(200,{'Content-Type':types[path.extname(file)]??'application/octet-stream','Cache-Control':'no-store'});fs.createReadStream(file).pipe(res);}catch{res.writeHead(404);res.end();}});
    await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
    try{for(const [width,height]of sizes){
      const compact=width<=700||(width<=900&&width>height),row={label,width,height,status:'RUNNING',inputs:[],scrolls:[],sections:[],jumps:[],images:[],evaluations:{}};
      row.goldenAssociation={...golden.find(g=>g.id==='shipyard-'+(compact?'phone':'desktop')),exactViewport:width===390&&height===844||width===1440&&height===900,purpose:'human reference; populated v1 versus default v2'};report.rows.push(row);write();
      const {browserContextId}=await browser.send('Target.createBrowserContext');let evaluate,retain;
      try{
        const {targetId}=await browser.send('Target.createTarget',{url:'about:blank',browserContextId}),{sessionId}=await browser.send('Target.attachToTarget',{targetId,flatten:true});
        row.sessionId=sessionId;const send=(m,p={})=>browser.send(m,p,sessionId);
        evaluate=createReviewEvaluator({send,ready:async()=>{},evidence:row.evaluations,onRecord:write});
        const read=(fn,arg,label)=>evaluate('('+fn.toString()+')('+JSON.stringify(arg)+')',label),state=label=>read(panelState,undefined,label),target=s=>read(targetState,s,'target and clipping '+s);
        const wait=async(expression,label)=>{const end=performance.now()+10000;while(!await evaluate(expression,label)){assert(performance.now()<end,label+' expired');await new Promise(r=>setTimeout(r,25));}};
        const frames=async label=>{await read(reviewFrameSettlement,label,label);const all=await read(readReviewFrameSettlements,undefined,label+' receipt'),proof=assessReviewFrameSettlement(all.invocations.at(-1),{width,height});assert(proof.pass,JSON.stringify(proof));};
        retain=async()=>{row.trace=await evaluate('(()=>{const n=window.__cfU1ReviewNativeTrace,s=window.__cfU3ShipyardScroll;return{native:n?{events:n.events,changes:n.changes,overflow:n.overflow,final:n.snapshot()}:null,scroll:s?{events:s.events,overflow:s.overflow}:null};})()','retain raw native and scroll traces');write();};
        const shot=async name=>{const data=Buffer.from((await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false})).data,'base64'),file=label+'-v2-'+width+'x'+height+'-'+name+'.png';fs.writeFileSync(path.join(out,file),data);row.images.push({file,bytes:data.length,sha256:sha(data)});write();};
        const wheel=async(owner,delta,reason)=>{
          assert(owner.hit&&owner.visible.bottom>owner.visible.top&&owner.visible.right>owner.visible.left,'scroll owner unavailable '+JSON.stringify(owner));
          const proof={owner,delta,reason};row.scrolls.push(proof);write();
          proof.start=await evaluate('(()=>{const t=window.__cfU3ShipyardScroll;t.active={selector:'+JSON.stringify(owner.selector)+',node:document.querySelector('+JSON.stringify(owner.selector)+')};return t.events.length;})()','prepare native measured wheel');
          await send('Input.dispatchMouseEvent',{type:'mouseWheel',...owner.point,deltaX:0,deltaY:delta});
          await wait('document.querySelector('+JSON.stringify(owner.selector)+').scrollTop!=='+owner.scrollTop,'native owner scroll movement');
          await frames('native scroll fonts and frames');proof.after=await evaluate('(()=>{const t=window.__cfU3ShipyardScroll,n=t.active.node;t.active=null;return{top:n.scrollTop,events:t.events.slice('+proof.start+'),overflow:t.overflow};})()','retain native wheel receipt');
          assert(!proof.after.overflow&&proof.after.events.some(e=>e.type==='wheel'&&e.trusted&&e.ownerInPath)&&proof.after.top!==owner.scrollTop);write();
        };
        const reveal=async selector=>{
          for(let attempt=0;attempt<12;attempt++){
            const t=await target(selector);if(t.usable)return t;
            row.lastTargetFailure=t;write();assert(t.exists&&t.visible&&t.enabled,'native target absent/hidden/disabled '+JSON.stringify(t));
            const choice=t.owners.map(o=>({...o,delta:Math.max(-640,Math.min(640,t.point.y-o.point.y))})).find(o=>o.hit&&Math.abs(o.delta)>1&&(o.delta>0?o.scrollTop<o.max-1:o.scrollTop>1));
            assert(choice,'no measured scroll can reveal target '+JSON.stringify(t));await wheel(choice,choice.delta,'reveal '+selector);
          }throw Error('native reveal step cap '+selector);
        };
        const press=async selector=>{
          const t=await reveal(selector);assert(['BUTTON','SUMMARY'].includes(t.tag),'only presentation buttons or native summary may be pressed');
          const p=await evaluate('(()=>{const n=window.__cfU1ReviewNativeTrace,node=document.querySelector('+JSON.stringify(selector)+'),id=++n.nextId;n.active={id,selector:'+JSON.stringify(selector)+',node};return{id,selector:'+JSON.stringify(selector)+',eventStart:n.events.length,beforePress:n.snapshot()};})()','prepare native press '+selector);
          Object.assign(p,{point:t.point,target:t,inputMethod:compact?'touch':'mouse'});row.inputs.push(p);write();
          if(compact){await send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...p.point,id:1,radiusX:1,radiusY:1,force:1}]});await send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await wait('window.__cfU1ReviewNativeTrace.events.some(e=>e.pressId==='+p.id+'&&e.type==="click")','native tap click boundary');}
          else{await send('Input.dispatchMouseEvent',{type:'mousePressed',...p.point,button:'left',clickCount:1});await send('Input.dispatchMouseEvent',{type:'mouseReleased',...p.point,button:'left',clickCount:1});}
          Object.assign(p,await evaluate('(()=>{const n=window.__cfU1ReviewNativeTrace;n.active=null;return{events:n.events.slice('+p.eventStart+'),overflow:n.overflow,after:n.snapshot()};})()','retain native press '+selector));
          p.delivery=assessNativeReviewDelivery(p);write();assert(p.delivery.pass,JSON.stringify(p.delivery));await frames('after native '+selector);
        };
        const bounds=s=>{const c=s.close.rect;assert(s.visible&&s.ariaHidden==='false'&&s.close.count===1&&c&&c.width>=44&&c.height>=44&&s.close.hit,'Close unavailable '+JSON.stringify(s.close));assert(s.rect.left>=-1&&s.rect.right<=width+1&&s.rect.top>=-1&&s.rect.bottom<=height+1&&!s.horizontalOverflow,'panel outside viewport '+JSON.stringify(s.rect));};
        await send('Runtime.enable');await send('Page.enable');await send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:compact});await send('Emulation.setTouchEmulationEnabled',{enabled:compact,maxTouchPoints:5});
        await send('Page.navigate',{url:'http://127.0.0.1:'+server.address().port+'/'});await wait('!!document.querySelector("canvas")&&document.getElementById("primechip")?.textContent.includes("/9")','normal game ready');
        await read(installNativeReviewTrace,label+'-'+width+'x'+height,'install native owner');await read(installScrollTrace,undefined,'install passive scroll receipt');
        if(await evaluate('!!document.querySelector("[data-sel=tutskip]")','native startup Skip presence'))await press('[data-sel=tutskip]');
        await wait('!document.body.classList.contains("training")&&!document.querySelector("[data-sel=tutskip]")','Training closed');await frames('fresh default model ready');
        row.scene=await state('pre-open canonical state');const opener=compact?'#dockshipyard':'#railshipyard';row.opener=opener;await press(opener);
        await wait('getComputedStyle(document.getElementById("shipyardpanel")).display!=="none"&&!!document.querySelector("#shipyardpanel [data-engineering-ship=overview]")','real Shipyard overview');
        row.open=await state('real default Shipyard open');bounds(row.open);assert(row.open.close.focused&&row.open.overview===1&&row.open.previews===1&&row.open.bodyState!=='uninitialized');assert.deepEqual(row.open.trail,row.scene.trail);await shot('open');
        for(const section of row.open.sections){
          assert(/^[a-z-]+$/.test(section.id));const selector='#shipyardpanel details[data-engineering-section="'+section.id+'"]>summary';
          await press(selector);const changed=await state('section toggle '+section.id);bounds(changed);assert.equal(changed.sections.find(s=>s.id===section.id).open,!section.open);
          if(!row.stickyScroll){const contentTarget=await target(selector),owner=contentTarget.owners.find(o=>o.hit&&o.max-o.scrollTop>2);
            if(owner){await wheel(owner,Math.min(400,owner.max-owner.scrollTop),'prove sticky Close on actual content');const after=await state('scrolled Close outcome');bounds(after);assert(Math.abs(after.close.rect.top-row.open.close.rect.top)<=2,'Close did not remain sticky');row.stickyScroll={before:changed,after};await shot('scrolled');}}
          await press(selector);const restored=await state('section restored '+section.id);bounds(restored);assert.equal(restored.sections.find(s=>s.id===section.id).open,section.open);row.sections.push({id:section.id,changed,restored});write();
        }
        for(const id of ['fabricator','research']){
          const selector='#shipyardpanel button[data-engineering-jump="'+id+'"]',present=await evaluate('!!document.querySelector('+JSON.stringify(selector)+')','optional jump presence '+id);
          if(!present){row.jumps.push({id,status:'ABSENT_IN_ACTUAL_DEFAULT_MODEL_NOT_EXERCISED'});continue;}
          await press(selector);const after=await state('jump presentation outcome '+id),summary=await target('#shipyardpanel details[data-engineering-section="'+id+'"]>summary');bounds(after);
          assert(after.sections.find(s=>s.id===id)?.open&&after.focus.key==='section:'+id&&summary.usable,'jump failed to open/reveal/focus target '+JSON.stringify({after,summary}));row.jumps.push({id,status:'PASS',after,summary});write();
        }
        if(!row.stickyScroll)row.stickyScroll={status:'NO_ACTUAL_SCROLL_OPPORTUNITY_NOT_EXERCISED'};
        await press('#shipyardpanel [data-pnx="shipyard"]');await wait('getComputedStyle(document.getElementById("shipyardpanel")).display==="none"','Shipyard closed');
        row.closed=await state('native Close focus return');assert(!row.closed.visible&&row.closed.ariaHidden==='true'&&row.closed.focus.id===opener.slice(1));assert.deepEqual(row.closed.trail,row.scene.trail);
        await retain();assert(!row.trace.native.overflow&&!row.trace.scroll.overflow&&!row.evaluations.overflow);assert(!report.runtimeErrors.some(e=>e.sessionId===sessionId));row.status='PASS';write();
      }catch(error){row.status='FAIL';row.failure=String(error);write();if(retain)try{await retain();}catch(e){row.traceFailure=String(e);write();}throw error;}
      finally{await browser.send('Target.disposeBrowserContext',{browserContextId});}
    }}finally{await new Promise(resolve=>server.close(resolve));}
    for(const a of assets)assert.equal(carrier(path.resolve(directory,'.'+a.path)).sha256,a.sha256);
  }
  assert.equal(git(['rev-parse','HEAD']),head);assert.equal(git(['diff','--name-only','HEAD']),'');assert.equal(report.runtimeErrors.length,0);report.status='PASS';
}catch(error){report.status='FAIL';report.failure=String(error);throw error;}
finally{try{await browser?.close();}catch(error){report.status='FAIL';report.cleanupFailure=String(error);}report.endedAt=new Date().toISOString();write();}
assert.equal(report.status,'PASS',report.failure??report.cleanupFailure);console.log(JSON.stringify({status:report.status,rows:report.rows.length,output:out}));
