# Prepared U3 Shipyard review — NOT RUN

This directory contains a 155-line bounded driver and an exact apply proposal.
No checkout edits, build, test, browser, Inkscape, commit or hosted action occurred
during preparation. OpenAI/Codex on macOS verified the owned root
/Users/nick/Projects/celestial-frontier-openai-mac and branch openai/mac.

The driver consumes two already-built normal distributable directories and existing
build receipts. It creates fresh isolated browser contexts at 390×844, 1440×900,
320×568 and 667×375 for each build; no viewport restoration or imported save.

Each context starts with the real default model, uses native startup Skip, then opens
Shipyard through the visible registered control. Every native target is first measured:
effective ancestor clipping, actual scroll owners, enabled/inert state, center hit owner
and focus. A clipped target is revealed only by native wheel input to an observed scroll
owner, with trusted wheel/scroll receipts and measured movement. No driver scrollIntoView,
scrollTop assignment, page-side click, probe hook or navigation normalization is used.

Shipyard checks retain real overview/model text, public DOM and section inventory, native
summary toggle/restoration, sticky Close during actual content scrolling, viewport bounds,
and Close-to-opener focus return. Optional data-engineering-jump=fabricator/research buttons
are pressed only when present. Their outcomes require the real section to open, its summary
to gain focus and become hit-testable. Missing opportunities are explicitly NOT_EXERCISED,
not invented populated state or a gameplay PASS. No craft/research/mining/skimming action fires.

The shared browsercdp, named evaluation/frame receipt and native pointer-trace owners are
reused unchanged. Inputs, exact expressions/hashes, frame receipts, runtime errors, before-v2/
current-v2 screenshots and source/build carriers are retained. Any failure stops the chain
and preserves the first failure; cleanup cannot turn it green. No automatic retry.

v1 Shipyard phone/desktop golden images are hash-verified against screens/MANIFEST.json and
associated with each row. Both v1 shots have populatedSave=true; current default v2 is a
different state. These are human presentation references, never identical-state pixel gates.
Small/landscape rows explicitly record that their associated phone golden has another viewport.

Source commits and build-receipt paths are supplied by the runner. Hash-verified assets prove
the served bytes; the driver does not independently reconstruct or certify source-to-build
binding. The current supplied source must equal the unchanged clean owned checkout HEAD.

Parent owns applying/reviewing this proposal, selecting exact before/current artifacts after
U2, checking the driver, and one later browser run. On macOS its first browser-owning attempt
must use approved out-of-sandbox execution and the shared toolchain lock. No run is started by
this handoff. Both historical U1 causes and physical UAT remain OPEN.
