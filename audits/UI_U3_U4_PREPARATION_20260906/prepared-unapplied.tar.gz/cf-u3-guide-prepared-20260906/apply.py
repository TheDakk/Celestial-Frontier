#!/usr/bin/env python3
"""Guarded U3 Guide proposal. Default is read-only; --apply writes one HTML file."""
from pathlib import Path
import argparse, hashlib, json, os, platform, subprocess, tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apply', action='store_true')
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
manifest = {'status': 'PREPARED_ONLY_NOT_APPLIED_NOT_EXECUTED',
 'date': '2026-09-06',
 'agent': 'OpenAI/Codex',
 'os': 'macOS',
 'root': '/Users/nick/Projects/celestial-frontier-openai-mac',
 'branch': 'openai/mac',
 'sourceHead': '56648b27b9063132ef01c08ffa8a683d9f45dc25',
 'target': 'port/v2/apps/game/index.html',
 'anchor': '  </style>\n</head>\n<body>\n',
 'marker': 'U3 Guide: presentation of the existing catalogue,',
 'cssSha256': '76478d8682eacaddd52f0cd31c2aa621640672b47d58fc10a7adca42b794bc88',
 'beforeSha256': 'db71621fb31f059014402200cd4577f43d6d171d906482ab9d2068601fbb4f1f',
 'proposalSha256': 'e31c25e414d5c27c723c1f0c2985d1f6d238ad0262e4546f694f4a7597f7cbdf',
 'guards': [{'file': 'port/v2/apps/game/index.html',
             'start': '    .guide-tools { display: grid;',
             'end': '    @media (min-width: 901px) {\n'
                    '      #setpanel, #recpanel, #shipyardpanel, #inventorypanel, #combatpanel',
             'sha256': '2dbd48066702f8394e221428667044d2e9e306f3dfc13ca2474f27a852311825'},
            {'file': 'port/v2/apps/game/src/main.ts',
             'start': 'function guideBuildIdentity(): string {',
             'end': "const indexedDBPersistenceBackend = createIndexedDBBackend('cf-v2-slice');",
             'sha256': '762b1cc972125e1cc85a1c4fbedf78b7c07191988c19d62da5d6df6d3d5130de'},
            {'file': 'port/v2/apps/game/src/main.ts',
             'start': "type GuideContentModule = typeof import('./guide-content.js');",
             'end': "/* ---- COMPENDIUM (read-only over the save's codex",
             'sha256': 'a53765332ebad2ee732f0e2e15455b1e6c83e2558c623dc76aa42e370ce4f369'},
            {'file': 'port/v2/apps/game/src/guide-content.ts',
             'sha256': 'f83fb17a0f80e098f9413419657661d67d42cb98e53b06a1860ac4f9abe88e95'},
            {'file': 'port/v2/apps/game/src/release-content.ts',
             'sha256': 'ebb28cde0e40cce19c6dd49fc755e6080f6d712ea43a01195334d1432f6761fc'},
            {'file': 'port/v2/apps/game/src/release-identity.ts',
             'sha256': '98be69d11abbb746e0196770b2bb55b19adcea8d40ac377d25705ba62ac9c077'},
            {'file': 'port/v2/apps/game/src/ui-sheet-style.ts',
             'sha256': 'f688b6493cec963a3b312ce98438bfe7d20f54148c564bbb6c1b68ac9d0cf03c'},
            {'file': 'port/v2/apps/game/src/ui-presentation-tokens.ts',
             'sha256': '2a53bfe1510bfbf4d72aa0a29ba40c6f446bbc952bd961445e0eb2871c07b0c7'},
            {'file': 'port/v2/apps/game/src/panels.ts',
             'sha256': 'f911daebf7f344e335e4bb1777d386978c22a4cf41ff2b997e00c25fd9026e8d'}]}
root = Path(manifest['root'])

def require(condition, message):
    if not condition:
        raise SystemExit('REFUSED: ' + message)

def digest(value):
    return hashlib.sha256(value).hexdigest()

require(platform.system() == 'Darwin', 'this proposal is owned by OpenAI/Codex on macOS')
require(Path.cwd().resolve() == root == root.resolve(), 'run from the exact owned physical root')
require(subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], text=True).strip() == str(root), 'Git root mismatch')
require(subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip() == manifest['branch'], 'branch mismatch')
for guard in manifest['guards']:
    data = (root / guard['file']).read_bytes()
    if 'start' in guard:
        text = data.decode('utf-8')
        require(text.count(guard['start']) == text.count(guard['end']) == 1, 'non-unique authority anchor: ' + guard['file'])
        start, end = text.index(guard['start']), text.index(guard['end'])
        require(end > start, 'authority anchor order: ' + guard['file'])
        data = text[start:end].encode('utf-8')
    require(digest(data) == guard['sha256'], 're-review changed authority: ' + guard['file'])
css = (bundle / 'guide.css').read_bytes()
require(digest(css) == manifest['cssSha256'], 'proposal CSS changed')
target = root / manifest['target']
original = target.read_bytes()
text = original.decode('utf-8')
require(text.count(manifest['anchor']) == 1, 'last style anchor must be exact and unique')
require(manifest['marker'] not in text, 'proposal is already present')
require(text.count('<aside id="guidepanel" class="glass panel" aria-label="Guide"></aside>') == 1, 'Guide identity changed')
proposed = text.replace(manifest['anchor'], css.decode('utf-8') + manifest['anchor'], 1).encode('utf-8')
receipt = {'mode': 'APPLY' if args.apply else 'READ_ONLY_CHECK', 'target': str(target), 'beforeSha256': digest(original), 'afterSha256': digest(proposed), 'cssSha256': digest(css)}
if args.apply:
    descriptor, name = tempfile.mkstemp(prefix='.guide-u3-', suffix='.tmp', dir=target.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, 'wb') as file:
            file.write(proposed)
        os.chmod(temporary, target.stat().st_mode)
        require(target.read_bytes() == original, 'target changed while preparing its copy')
        os.replace(temporary, target)
        require(target.read_bytes() == proposed, 'applied read-back differs')
    finally:
        if temporary.exists():
            temporary.unlink()
print(json.dumps(receipt, indent=2))
