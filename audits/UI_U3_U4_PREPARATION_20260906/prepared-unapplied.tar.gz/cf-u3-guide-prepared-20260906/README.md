# U3 Guide — temporary presentation proposal

OpenAI/Codex on macOS, owned `openai/mac` workspace, 2026-09-06.
**Not applied, built, tested, rendered or checkpoint evidence.** Reserved for the
Guide step after Records/Chronicle passes. No checkout file changed.

`guide.css` adds scoped spacing/card treatment to existing catalogue and bulletin
rows, an emoji reading surface, fitted Back/related controls and article typography.
Every selector starts at `#guidepanel`. Existing minimum targets, phone toolbar stacking,
hover/focus/button states, status colors and full text remain. No tabs/content/controls,
IDs, ARIA, catalogue/history entries, capability labels, release bulletins, timing,
lazy publication, persistence, scroll owner or shared U2 header/Close change.

The patch keeps all authored copy and release identity untouched: v2.0 is development,
the production pointer is null and the draft cannot trigger a production bulletin.
Article padding changes the natural page length; it adds no nested scrollport, clamp,
fixed article height, truncation or scroll shortcut. Native long-history reachability
must be re-proven later through the existing adaptive-wheel owner.

## Files and guarded application

Only four temporary files: this README, `guide.css`, `guide.patch` and `apply.py`.
The apply script embeds the preparation source/hash guards. Its default is read-only;
`--apply` explicitly inserts the exact CSS at the unique final-style anchor using a
temporary copy, checks concurrent drift and atomically replaces only the HTML.

From the exact owned root, at the later ordered checkpoint:
`python3 /private/tmp/cf-u3-guide-prepared-20260906/apply.py`
checks the guards; adding `--apply` applies the reviewed proposal. Neither command ran.
Guards refuse changed Guide renderer/base CSS, catalogue/release content or shared
owners. Earlier U3 release-note edits will normally require a fresh content review and
guard refresh. Do not bypass a refusal or use this proposal as later-source proof.

## Golden association and scope differences

Both existing v1 images below were visually read, not generated; manifest authority is
`port/baseline-v1.8.9/screens/MANIFEST.json`. They use minimal veteran state. The v1
Guide is a centered modal with Advanced Briefings and a Continue control; current v2
has the U2 sheet, build identity, capability-labelled catalogue and Release history.
Those are existing differences, not features introduced or filled in by this proposal.
The same categories/emoji provide visual reference. No current-v2 before/after images
have been produced and no byte/pixel comparison acceptance is claimed.

- `ui-guide-desktop.png` — 1440x900, populatedSave=false; observed SHA256 `254605aa2a2b13d535bde87245151f174a63f91c902bd2c386206a75e2eb8db3` (manifest `254605aa2a2b13d535bde87245151f174a63f91c902bd2c386206a75e2eb8db3`).
- `ui-guide-phone.png` — 390x844, populatedSave=false; observed SHA256 `990dd0a702a6966b145c9a104e03fffc64cb391b2017f8d8f95c547100ed819f` (manifest `990dd0a702a6966b145c9a104e03fffc64cb391b2017f8d8f95c547100ed819f`).

## Later checkpoint

`port/UI_PARITY_PROGRAM_U1_U4.md:317–322` owns ordered reskins and per-panel evidence.
Renderer/handlers: `main.ts:3069–3267`; catalogue: `guide-content.ts`; release archive:
`release-content.ts`; shared header/Close: `panels.ts` / `ui-sheet-style.ts`.
Current source supersedes older reference bulletin counts. `UI_PRESENTATION.md:939`
records lazy-import failure/request fences and its later Guide section owns native
cross-links and exact draft-tail reachability.

Parent owns required validation, existing Guide/release/panel-focus and exact native-
wheel contract checks, plus normal native catalogue → category → topic/cross-link/search,
release list/article/Back and Close-focus evidence. Re-observe the exact draft's ordered
content and visible final bullet through the native scroll owner at phone/desktop,
small/landscape and large-text bounds, with meaningful fault/restoration controls for
new geometry checks. No gameplay result or native-layout PASS was created here.

U2 remains active; both older U1 causes remain open (unsolicited navigation and portrait-
restoration Runtime.evaluate timeout). No Inkscape, hosted action or Phase 2 work.
Codex holds this proposal until Records/Chronicle passes. Claude remains untouched;
Nick need not open Claude for this temporary preparation.
