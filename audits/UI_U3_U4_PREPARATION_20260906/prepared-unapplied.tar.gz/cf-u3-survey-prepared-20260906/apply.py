#!/usr/bin/env python3
"""Verify the prepared Survey CSS; --apply is only for the post-Settings checkpoint."""
import argparse,hashlib,json,os,platform,subprocess
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apply',action='store_true')
args=parser.parse_args()
prep=Path(__file__).resolve().parent
manifest=json.loads((prep/'manifest.json').read_text())
root=Path('/Users/nick/Projects/celestial-frontier-openai-mac')
assert manifest['root']==str(root) and root.resolve()==root and platform.system()=='Darwin','Wrong owned root/host'
def git(*args): return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
def sha(raw): return hashlib.sha256(raw).hexdigest()
assert git('rev-parse','--show-toplevel')==str(root) and git('branch','--show-current')=='openai/mac','Wrong branch/root'
assert git('rev-parse','--abbrev-ref','--symbolic-full-name','@{upstream}')=='origin/openai/mac','Wrong upstream'
assert not git('diff','--name-only','HEAD'),'Finish current tracked work before applying this later checkpoint'
assert len(manifest['files'])==1 and manifest['files'][0]['path']=='port/v2/apps/game/index.html','Unexpected file inventory'
for guard in manifest['guards']:
    raw=(root/guard['path']).read_bytes()
    if guard['kind']=='sha256': assert sha(raw)==guard['sha256'],'Measured lane owner changed; refresh proposal explicitly'
    else:
        assert guard['kind']=='exact-fragments'
        for fragment in guard['fragments']: assert raw.decode().count(fragment)==1,'U2 title/Close/message ownership changed; refresh explicitly'
entry=manifest['files'][0];path=root/entry['path'];original=path.read_bytes();result=original.decode()
assert not path.is_symlink() and sha((prep/entry['path']).read_bytes())==entry['preparedSha256'],'Prepared bytes changed'
assert len(entry['edits'])==3
for edit in entry['edits']:
    assert sha(edit['before'].encode())==edit['beforeSha256'] and sha(edit['after'].encode())==edit['afterSha256'],'Replacement carrier changed'
    assert result.count(edit['before'])==1,'Exact CSS region changed or already applied; no writes'
    result=result.replace(edit['before'],edit['after'],1)
if not args.apply:
    print('VERIFIED three Survey CSS replacements only; checkout unchanged. No tests/build/browser executed.')
    raise SystemExit(0)
copy=path.with_name(path.name+'.cf-u3-survey-prepared.tmp')
created=False
try:
    with copy.open('xb') as out:
        created=True
        out.write(result.encode())
    os.chmod(copy,path.stat().st_mode & 0o777)
    assert path.read_bytes()==original,'Intervening index change; no apply'
    os.replace(copy,path)
finally:
    if created and copy.exists(): copy.unlink()
print('APPLIED prepared Survey CSS only. Run its ordered native/checkpoint verification; no PASS is implied.')
