# U3 Survey / landing / biosphere — prepared, not run

Prepared from signed source `56648b27b9063132ef01c08ffa8a683d9f45dc25` while U2 remains active.
Apply only after **U2 and every preceding U3 panel through Settings** passes its checkpoint.
No owned-source changes, tests, builds, browser, generated-runner execution, or commit occurred.

The proposal changes only three exact CSS regions in `port/v2/apps/game/index.html`:

- Survey metadata rows become small token-colored cards with a clear muted label and wrapping value.
- The existing landing disclosure gains a modest card treatment; the mounted capture section becomes
  one bounded card around its unchanged summary, rows, feedback and native actions.
- The existing biosphere heading uses the gold title role. Species chips gain an inset border and
  surface fill without changing their boxes, 64px image geometry, native roster order or text labels.

No markup, element IDs, selectors, model, copy, rarity/status colors, emoji, listeners, thumbnail
binding/cache, viewport limits, focus, Escape, Land/Atlas/share actions, capture/combat/audio behavior,
virtualized content or AT declarations change. U2’s sticky title+Close, scrolling sub/badge,
compact full-message accessibility, measured lanes and scroller owners remain untouched.
There is no guessed populated model and no new gameplay control.

## Apply proposal

`proposal.diff`, `survey.css` and the mirrored full index are review artifacts.
`python3 apply.py` would verify only; `python3 apply.py --apply` would apply once by exact matching
three current CSS regions, writing a copy and atomically replacing the index. **Neither command has run.**
The script rejects wrong ownership/upstream, existing tracked work, changed U2 header/message/lane
owners, changed proposal hashes and stale/already-applied regions. It retains unrelated preceding
panel edits in the current index. The historical full-file hash is provenance, not a demand to undo
prior U3 panels. The program-order PASS condition belongs to the parent checkpoint runner; this
small apply script does not invent a Settings evidence schema or certify prerequisite completion.
If U2 changes the guarded measured owner, refresh this proposal rather than bypassing its guard.

## Verification still required

The sealed 28-screen manifest contains **no Survey, landing or biosphere screen**. Inspected
`ui-tray-phone.png` is Notifications; `ui-search-earth-desktop.png` is Search. Neither may be labelled
an equivalent Survey baseline. Record this missing comparison explicitly; do not invent a match.
Obtain actual unchanged-v2 predecessor and later-v2 native presentation captures at the ordered
checkpoint, with the real encountered route/model named. Landed ecology may be empty or unavailable;
those states must stay honestly identified. A populated roster is not assumed from a default save.

Relevant existing owners include `landing-card-main-wiring.test.ts`, `survey-land-handoff.test.ts`,
`arc4-capture-card.test.ts`, `arc4-main-wiring.test.ts`, `arc7-noncombat-audio-main-wiring.test.ts`,
`sheet-layout.test.ts` and the native Glass Survey/Close/lane controls. Parent selects the checkpoint
profile once; this preparation adds no duplicate test owner and makes no PASS claim.

Native review must inspect normal and larger text, 320px phone and short landscape, sticky Close,
actual internal scrolling and native action reachability. Added card padding increases content height;
44px capture controls must fit after that padding, and the heading’s 2px spacing increase needs lane
verification. Existing `[data-landing-disclosure]` inline font/max-width and user preference precedence
remain authoritative. No pixel equality, device UAT, all-state roster coverage or full U3 is claimed.
Both historical U1 unknown causes remain OPEN; this proposal makes no causal closure.
