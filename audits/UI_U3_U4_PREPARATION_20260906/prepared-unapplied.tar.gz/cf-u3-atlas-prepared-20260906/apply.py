#!/usr/bin/env python3
"""Verify/apply only the prepared Atlas presentation after U2 and Shipyard pass."""
import argparse, hashlib, json, os, platform, subprocess
from pathlib import Path
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apply', action='store_true', help='Write verified prepared files; default is read-only.')
args = parser.parse_args()
prep = Path(__file__).resolve().parent
manifest = json.loads((prep / 'manifest.json').read_text())
root = Path(manifest['root'])
if platform.system() != 'Darwin' or root.resolve() != root:
    raise SystemExit('Expected the owned physical macOS checkout.')
def git(*words):
    return subprocess.check_output(['git', '-C', str(root), *words], text=True).strip()
if git('rev-parse', '--show-toplevel') != str(root) or git('branch', '--show-current') != 'openai/mac':
    raise SystemExit('Owned root/branch mismatch; no writes.')
if git('rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{upstream}') != 'origin/openai/mac':
    raise SystemExit('Owned upstream mismatch; no writes.')
expected = {'port/v2/apps/game/src/star-atlas-panel.ts', 'port/v2/apps/game/index.html', 'port/v2/tests/star-atlas-panel.test.ts'}
if {f['path'] for f in manifest['files']} != expected or len(manifest['files']) != 3:
    raise SystemExit('Unexpected or duplicate file inventory.')
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
plans = []
for entry in manifest['files']:
    path = root / entry['path']
    original = path.read_bytes()
    if path.is_symlink():
        raise SystemExit(f'Symlink source refused: {path}')
    prepared = (prep / entry['path']).read_bytes()
    if sha(prepared) != entry['preparedSha256']:
        raise SystemExit(f'Prepared file changed: {path}')
    if entry['scope'] == 'whole-file':
        if sha(original) != entry['sourceSha256AtPreparation']:
            raise SystemExit(f'Source changed: {path}; refresh preparation explicitly.')
    elif entry['scope'] != 'exact-atlas-css-region' or entry['path'] != 'port/v2/apps/game/index.html':
        raise SystemExit('Unexpected replacement scope.')
    result = original.decode('utf-8')
    for edit in entry['edits']:
        if sha(edit['before'].encode()) != edit['beforeSha256'] or sha(edit['after'].encode()) != edit['afterSha256']:
            raise SystemExit('Manifest replacement hash mismatch.')
        if result.count(edit['before']) != 1:
            raise SystemExit(f'Exact source region changed or already applied: {path}; no writes.')
        if prepared.decode('utf-8').count(edit['after']) != 1:
            raise SystemExit(f'Prepared replacement is not unique: {path}')
        result = result.replace(edit['before'], edit['after'], 1)
    replacement = result.encode('utf-8')
    if entry['scope'] == 'whole-file' and replacement != prepared:
        raise SystemExit(f'Reconstructed prepared bytes differ: {path}')
    plans.append((path, original, replacement))
if not args.apply:
    print('VERIFIED three exact Atlas changes; checkout unchanged. No tests/browser have run.')
    raise SystemExit(0)
staged = []
try:
    for path, original, replacement in plans:
        temporary = path.with_name(path.name + '.cf-u3-atlas-prepared.tmp')
        with temporary.open('xb') as output:
            output.write(replacement)
        os.chmod(temporary, path.stat().st_mode & 0o777)
        staged.append((temporary, path))
    for path, original, _ in plans:
        if path.read_bytes() != original:
            raise SystemExit(f'Intervening change: {path}; no prepared files applied.')
    for temporary, path in staged:
        os.replace(temporary, path)
    print('APPLIED three prepared Atlas changes; complete the admitted U3 validation. No PASS is implied.')
finally:
    for temporary, _ in staged:
        if temporary.exists():
            temporary.unlink()
