# U3 Atlas preparation — 2026-09-06

TEMP ONLY. No checkout edit, build, test, browser, Inkscape, commit, or checkpoint PASS.
Apply only after U2 and the earlier Shipyard checkpoint pass.

```sh
python3 /private/tmp/cf-u3-atlas-prepared-20260906/apply.py
python3 /private/tmp/cf-u3-atlas-prepared-20260906/apply.py --apply
```

`proposal.diff` is the proposed three-file diff. `atlas.css` is the complete scoped CSS extract.
The prepared files mirror repository paths. `manifest.json` binds preparation file hashes and every exact
before/after replacement. The renderer and test require unchanged whole-file SHA256s. index.html deliberately
requires the exact complete Atlas CSS region and its hash, preserving unrelated accepted Shipyard/U2 changes.
All sources are preflighted before writing copies and atomic replacements; repeat application fails closed.

Change: mark the existing ready/protected Atlas h3 with the shared sheet-header/data-sheet-kind owner, which
already supplies the retained globe emoji. Keep the native Close outside the renderer. Fit the live total into a
small count badge; present native List/Chart as a two-column segment, existing five filters as wrapping chips,
and existing destination rows as cards with a two-column action grid. Distinguish Home, Remove and Undo by
appearance. Preserve every button label/attribute, 44px floor, state, filter/count, row ordering and all existing
chart coordinates, cluster targets, current-position marker, disabled policies and reduced-motion controls.
Main dispatch, WeakMap routes, exact Home/Remove/one-level eight-second Undo and Batch 4 ownership are untouched.

Two parameterized DOM cases are prepared in star-atlas-panel.test.ts. They execute the actual renderer for
List and Chart, verify one shared title/count, unchanged native view/filter/Home/Undo controls, disabled row
mutations, emoji Home, protected-mode refusal and source-state immutability. Existing CSS, projection, cluster,
main-wiring, row-action and favorite-owner tests stay intact and should run after application under the shared
lock. No new instrumentation/helper or dependency is added. Typechecks, release/producer pins and root validation
remain parent-owned.

Native checkpoint remains required: v1 ui-atlas-phone/desktop vs v2 before/after; empty/populated List; Chart
clusters and Return; every filter; Travel Home; Remove/Undo; semantic focus through refills; sticky Close;
44px targets; large text and high contrast. Do not weaken the existing Chart 220px minimum extent: its 44px
cluster separation relies on it. Check short landscape explicitly because the U2 half-screen sheet width less
its 72px horizontal padding can leave less than 220px of content. This pre-existing geometry interaction has
not been browser-measured by this preparation and is not a new PASS or product finding.
