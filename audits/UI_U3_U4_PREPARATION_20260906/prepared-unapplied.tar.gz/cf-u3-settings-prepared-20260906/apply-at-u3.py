#!/usr/bin/env python3
"""PREPARED ONLY: apply after U2 and the ordered U3 Guide checkpoint pass."""
from pathlib import Path
import hashlib
import os
import subprocess
import tempfile

ROOT = Path('/Users/nick/Projects/celestial-frontier-openai-mac')
PACKAGE = Path(__file__).resolve().parent
ANCHOR = '    #setpanel { z-index: 24; }   /* preferences must remain operable over a populated phone survey card */\n'
SETTINGS_START = 'function fillSettings(): void {'
SETTINGS_END = '/* ---- GUIDE + RELEASE HISTORY'
SETTINGS_SHA = 'b1f26dbea2e2d06bb41b136479ba85f95393562208e4bde794cffe9a5ba42597'
SHEET_SHA = 'f688b6493cec963a3b312ce98438bfe7d20f54148c564bbb6c1b68ac9d0cf03c'

def require(ok, message):
    if not ok:
        raise SystemExit(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

require(Path(git('rev-parse', '--show-toplevel')).resolve() == ROOT.resolve(), 'Wrong owned repository')
require(git('branch', '--show-current') == 'openai/mac', 'Wrong owned branch')
main = (ROOT / 'port/v2/apps/game/src/main.ts').read_text()
require(main.count(SETTINGS_START) == 1 and main.count(SETTINGS_END) == 1, 'Settings owner boundaries are not unique')
settings = main[main.index(SETTINGS_START):main.index(SETTINGS_END)]
require(sha(settings.encode()) == SETTINGS_SHA, 'Settings owner changed; review this preparation again')
require(sha((ROOT / 'port/v2/apps/game/src/ui-sheet-style.ts').read_bytes()) == SHEET_SHA,
        'U2 sheet owner changed; review this preparation again')
target = ROOT / 'port/v2/apps/game/index.html'
original = target.read_bytes()
anchor = ANCHOR.encode()
proposal = (PACKAGE / 'settings-proposal.css').read_bytes()
require(sha(proposal) == '323230da4fa4c14bbb102b5dc87d004bb456eb9f254ee90eaf4c0ca305186a78',
        'Prepared CSS changed; review the proposal and guard together')
require(original.count(anchor) == 1, 'Settings CSS anchor must match exactly once')
require(original.count(proposal) == 0, 'Settings proposal already applied')
require(proposal.startswith(b'    /* U3 Settings spacing:') and proposal.endswith(b' }\n'), 'Unexpected proposal boundaries')
replacement = anchor + proposal
updated = original.replace(anchor, replacement, 1)
require(updated.count(replacement) == 1 and updated.replace(replacement, anchor, 1) == original,
        'Replacement scope did not round-trip')
with tempfile.NamedTemporaryFile(prefix='.cf-settings-', suffix='.tmp', dir=target.parent, delete=False) as stream:
    temporary = Path(stream.name)
    stream.write(updated)
try:
    require(temporary.read_bytes() == updated, 'Temporary copy differs')
    require(target.read_bytes() == original, 'Source changed during copy preparation')
    os.chmod(temporary, target.stat().st_mode & 0o777)
    os.replace(temporary, target)
finally:
    if temporary.exists():
        temporary.unlink()
print('Applied only the prepared Settings CSS. No validation or visual acceptance is implied.')
