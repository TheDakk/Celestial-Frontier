# U3 Settings spacing preparation — 2026-09-06

PREPARED, NOT APPLIED OR TESTED. U2 is still active. Apply this only after the preceding U3 Guide checkpoint passes. Product context is `56648b2` with compact notifications and Survey's scrolling subtitle. Only this temporary directory was written; no owned source, tests, build, browser, generated apply script or commit was run.

## Proposed change

`settings-proposal.css` adds 12 lines after the existing exact Settings CSS anchor in `port/v2/apps/game/index.html`:

- Keep the six existing Sound, Creature voices, Star charts, Visual effects, Screen shake and Field Training button rows inline. Buttons fit their labels and retain the existing 44px minimums; adjacent labels can wrap. This avoids a full-width On/Off pill beneath each phone label.
- Add 12px separation and a token border before the existing identity, text preferences, graphics and Training groups. No labels, category tabs, wrappers or preferences are added or reordered.
- Keep the existing three-column phone preference segments, range controls, name editor and nameplate selector. All IDs, data selectors, roles, selected states, event handlers and copy stay untouched. Native shared header/Close, its reserved gutter, Settings-above-Training, scroll/focus/Escape behavior and text preferences retain their owners.

Only spacing and layout of these existing rows change. The proposal does not set panel anchors, maximum heights, typography, colors of controls, announcement behavior or target minimums. Existing markup and `fillSettings()` remain byte-identical. Added group spacing increases total scroll length slightly; compact inline phone toggles recover more space. Rendering has not been verified.

## References actually inspected

- `port/baseline-v1.8.9/screens/ui-settings-phone.png`, 390×844, SHA-256 `5946f7a76f50bcd121b17d9a5e473190342291f03968cc2833bc22b60abc6218`.
- `port/baseline-v1.8.9/screens/ui-settings-desktop.png`, 1440×900, SHA-256 `7f029f5c424d33a625f751cf9e51900ac8eb4285679ba1185edce56c5d227155`.
- Retained v2 `594ece6` small-phone/default and desktop/default Training-with-Settings PNGs from `/private/tmp/cf-u2-checkpoint-594ece6-20260906/sheet-review/`. These are prior-source visual context, not `56648b2` proof or new acceptance. Earlier default/A++ landscape images were also reviewed during U2.
- Current `main.ts#fillSettings`, Settings CSS, `explorer-name-settings.ts`, `nameplate-settings.ts`, and U2 presentation tokens/header styles.

The v1 screenshots have Display/Graphics/Audio/Gameplay category tabs and a different preference inventory. Those tabs do not exist in current v2 and are outside this grouping-only preparation. The comparison supports compact inline controls, existing three-choice preference rows and measured spacing; it is not a claim of full legacy parity. Current v2 Settings intentionally remains above Training. Background dimming/blocked controls are not spacing defects.

## Guarded application, not executed

After the authorized preceding checkpoint passes, inspect the CSS, then run:

```sh
python3 /private/tmp/cf-u3-settings-prepared-20260906/apply-at-u3.py
```

The script requires the exact owned root and `openai/mac`, unique Settings source boundaries, unchanged Settings markup/handler block and U2 sheet CSS, and exactly one original CSS anchor. It writes a verified temporary copy, checks for concurrent changes, and replaces only that CSS block. It permits unrelated earlier U3 changes. If U2 or a prior panel changes a guarded owner, prepare a fresh reviewed guard; do not weaken a mismatch. The script itself has not been executed or tested.

CSS/index changes still alter a pinned producer input: re-derive the final evidence build graph and update only existing live producer pins. Preserve draft count81, measurement authority, numeric ceilings and history; use `/private/tmp/cf-u3-checkpoint-docs-20260906.md` for existing owners. Root owns release copy, current references, audit and commit.

## Existing verification owners to reuse at the Settings checkpoint

No new tests or test changes are proposed. Existing `audio-settings-wiring.test.ts`, `read-only-settings-main-wiring.test.ts`, Arc9 explorer-name/nameplate Settings and Main-wiring tests, `training-main-wiring.test.ts` and `ui-sheet-review.test.ts` retain meaningful behavior coverage. The actual browser must still verify small-phone and A++/mono wrapping, selected segments, editor open/save/cancel, ranges, native Close/Escape/focus return, and Settings above Training at the measured short-landscape dimensions. Record v2 before/after against the two v1 references and follow the existing ordered checkpoint battery once on clean signed source; stop at any RED. No new generic gate or icon study is proposed.
