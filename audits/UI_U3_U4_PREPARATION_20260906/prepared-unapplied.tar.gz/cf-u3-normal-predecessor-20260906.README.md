# U3 normal predecessor runner — prepared, not run

Run only after the exact U2 canonical `execution.json` is terminal PASS, before applying U3.
Inside the caller’s existing whole-job toolchain lock:

```sh
node /private/tmp/cf-u3-normal-predecessor-20260906.mjs FULL_U2_SHA /private/tmp/cf-u2-checkpoint-SHORT-20260906/execution.json
```

Use the actual full admitted SHA and its matching seven-character directory suffix.
The runner verifies caller-lock ancestry, signed clean candidate source and every required
terminal U2 stage. It performs one normal distributable build in that same isolated candidate,
uses the shipped build-mode validator and PWA inventory, and immediately snapshots every
file under `normal-predecessor/dist`. Source tree, original U2 receipt, runner, lock, build log
and complete file hashes are retained in `normal-predecessor/build-receipt.json`.
A terminal failure retains the output and refuses reuse. No browser, test, install, network,
evidence build or U3 edit occurs. The original ambient owned-worktree file is never touched.

Copy `normal-predecessor/shipyard-before.json`’s `before` object into the prepared Shipyard
review config alongside its later `current` build. Only do so when the build receipt says PASS.
This records a build and exact served bytes; it does not repeat or widen U2 certification.
No execution or syntax/test command was run during preparation.
