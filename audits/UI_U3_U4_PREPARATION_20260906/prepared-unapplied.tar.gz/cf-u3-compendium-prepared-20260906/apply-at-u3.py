#!/usr/bin/env python3
"""Apply the one prepared CSS replacement only after the ordered U3 handoff."""
from pathlib import Path
import hashlib, json, os, subprocess, tempfile
PACKAGE = Path(__file__).resolve().parent
META = json.loads((PACKAGE / 'PREPARATION.json').read_text())
ROOT = Path(META['expectedRoot'])
def require(ok, message):
    if not ok:
        raise SystemExit(message)
def digest(data):
    return hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
require(Path(git('rev-parse', '--show-toplevel')).resolve() == ROOT.resolve(), 'Wrong repository root')
require(git('branch', '--show-current') == META['expectedBranch'], 'Wrong branch')
for relative, expected in META['protectedFiles'].items():
    require(digest((ROOT / relative).read_bytes()) == expected, f'Protected owner changed: {relative}; review the preparation again')
for guard in META['protectedSourceBlocks']:
    content = (ROOT / guard['path']).read_text()
    require(content.count(guard['start']) == 1 and content.count(guard['end']) == 1, 'Compendium boundary is not unique')
    segment = content[content.index(guard['start']):content.index(guard['end'])]
    require(digest(segment.encode()) == guard['sha256'], 'Compendium markup/action owner changed; review the preparation again')
before = (PACKAGE / 'replacement-before.css').read_bytes()
after = (PACKAGE / 'replacement-after.css').read_bytes()
require(digest(before) == META['replacement']['beforeSha256'], 'Prepared source replacement changed')
require(digest(after) == META['replacement']['afterSha256'], 'Prepared destination replacement changed')
target = ROOT / META['target']
original = target.read_bytes()
require(original.count(before) == 1, 'CSS replacement must match exactly once')
require(original.count(after) == 0, 'CSS preparation already applied')
updated = original.replace(before, after, 1)
require(updated.count(after) == 1 and updated.replace(after, before, 1) == original, 'Replacement scope check failed')
with tempfile.NamedTemporaryFile(prefix='.cf-compendium-', suffix='.tmp', dir=target.parent, delete=False) as stream:
    temporary = Path(stream.name)
    stream.write(updated)
try:
    require(temporary.read_bytes() == updated, 'Copy verification failed')
    os.chmod(temporary, target.stat().st_mode & 0o777)
    require(target.read_bytes() == original, 'Target changed during copy preparation')
    os.replace(temporary, target)
finally:
    if temporary.exists():
        temporary.unlink()
print('Applied only the guarded Compendium CSS block. Validation and browser comparison are still required.')
