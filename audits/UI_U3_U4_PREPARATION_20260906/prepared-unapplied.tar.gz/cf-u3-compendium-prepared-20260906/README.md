# U3 Compendium preparation — 2026-09-06

Status: PREPARED, NOT APPLIED OR TESTED. Root applies only after U2, Shipyard and Star Atlas checkpoints. This package changes one CSS block in `port/v2/apps/game/index.html`; the owned checkout was not edited.

## Smallest proposed presentation change

- Give existing native species-row buttons an 8px inset, 1px token border, small rounded corners and elevated token surface. Existing 44px thumbnails, names, rarity badges, origins and action targets stay in place. Rows retain zero margins: all changed height is inside the border box already measured by `CompendiumVirtualList`.
- Apply the same quiet card treatment to existing direct detail `.centry` fields, with 8px spacing. Portrait, description, stat bars and separately owned action sections retain their markup and behavior.
- Center and inset the existing empty-state copy. Do not alter the copy or invent populated examples.
- Keep the U2 gold heading, emoji and single native Close. Compendium has no existing segmented controls, so this preparation adds none.

The current list uses flat bottom separators and 6px vertical padding. This is deliberately a small card/spacing change, not a new panel structure. The patch introduces no new font/color values; presentation tokens provide them. Default rows may become slightly taller and long names may wrap earlier because of the horizontal inset; measured offsets and viewport bounds must be checked in the real browser before acceptance.

## Golden evidence and its limit

Viewed `port/baseline-v1.8.9/screens/ui-compendium-phone.png` (390×844) and `ui-compendium-desktop.png` (1440×900). Both show an EMPTY Compendium with a gold heading/divider and centered guidance. They do not demonstrate populated-list or detail-card parity. The phone reference also contains legacy Close duplication; U2's single Close remains authoritative. Golden PNG hashes are recorded in PREPARATION.json as integrity receipts, not pixel acceptance thresholds.

## Guarded application

Inspect `presentation.patch`, then run `python3 /private/tmp/cf-u3-compendium-prepared-20260906/apply-at-u3.py` from the authorized ordered checkpoint. It verifies the owned repository/branch, unchanged Compendium markup/action block, virtualization owner and U2 sheet CSS; requires exactly one original CSS match; writes and verifies a copy before replacement; and refuses any intervening owner drift. It allows unrelated preceding Shipyard/Atlas CSS edits. If a guarded owner changed during U2 or earlier U3, review and prepare a new guard rather than weakening the checks.

No `main.ts` change is proposed, so this patch alone does not change the Compendium producer authority. Root owns the same-batch release note/current references and checkpoint identity.

## Focused coverage retained

No test updates proposed for this CSS-only change: a source-string test would mirror the implementation and jsdom does not paint these rules. Existing meaningful owners remain:

- `port/v2/tests/compendium-ui.test.ts`: variable-height offsets, resize correction above the anchor, bounded rows, logical identity, focus pinning and list-return state.
- `port/v2/tests/compendium-creature-progression-main-wiring.test.ts` and `compendium-feed-main-wiring.test.ts`: unchanged authoritative detail/action wiring.
- Existing Compendium/Slice browser outcomes: native row activation, detail Back/Escape and focus/scroll restoration, real portrait and bounded virtual scrolling.

All validation is pending. At this ordered checkpoint, capture v2 BEFORE and AFTER images paired with the two v1 goldens; separately exercise real populated list/detail content at phone default/A++mono and desktop. Check rows at the viewport edge and after long-name wrapping, no adjacent-row overlap, unchanged logical focus/scroll after detail return, fully visible focus treatment, one reachable 44px Close, and sheet/lower-lane separation. These are proposed checks, not executed evidence. Run the existing required checkpoint owners once on the committed clean source; stop at any RED. No browser/build/test/Inkscape job was started by this preparation.
