import { createRequire } from 'node:module';
import { describe, expect, it } from 'vitest';
// @ts-expect-error Browser evidence module intentionally ships executable JavaScript.
import { LAYOUT_VIEWPORTS, LAYOUT_FAMILIES, LAYOUT_ADMISSION_FAMILIES, assessLayoutViewportIdentity, assessLayoutViewportInventory, readLayoutSnapshot, assessLayoutSnapshot, applyLayoutFault } from '../tools/ui-layout-contract.mjs';
const require = createRequire(import.meta.url);
const { JSDOM } = require('jsdom');
const rect = (left: number, top: number, width: number, height: number) => ({ left, top, right: left + width, bottom: top + height, width, height });
const surface = (key: string, r: any, visible = true) => ({ key, rect: r, exposed: r, visible, clips: [], position: 'fixed', overflowX: 'visible', overflowY: 'visible', clipPath: 'none', ancestors: [], modal: false, inert: false, ariaHidden: false, scrollWidth: r.width, clientWidth: r.width, scrollHeight: r.height, clientHeight: r.height });
function fixture(vp = LAYOUT_VIEWPORTS[0]): any {
  const { width: w, height: h } = vp, safe = { top: 0, right: 0, bottom: 0, left: 0, ...vp.safe };
  const compact = w <= 700 || (w <= 900 && w > h), landscape = compact && w > h;
  const dockWidth = compact ? Math.min(320, landscape ? (w - safe.left - safe.right - 36) / 2 : w - safe.left - safe.right - 20) : 200;
  const dockHeight = compact ? 92 : 44, dockLeft = landscape ? w - safe.right - 12 - dockWidth : compact ? (w - dockWidth) / 2 : w - safe.right - 16 - dockWidth;
  const dockTop = h - safe.bottom - 12 - dockHeight, pitch = compact ? dockWidth / 5 : 52;
  const roots: any = { topbar: surface('#topbar', rect(0, 0, w, 100)), dock: surface('#dock', rect(dockLeft, dockTop, dockWidth, dockHeight)),
    hintpill: surface('#hintpill', landscape ? rect(dockLeft, dockTop - 28, dockWidth, 20) : rect(12, h - safe.bottom - 144, w - 24, 20)),
    ctxbar: surface('#ctxbar', landscape ? rect(dockLeft, dockTop - 56, dockWidth, 20) : rect(12, h - safe.bottom - 184, w - 24, 20)) };
  const lowerTop = Math.min(dockTop, ...[roots.hintpill, roots.ctxbar].filter(r => r.visible).map(r => r.rect.top));
  roots.toast = surface('#toast', rect(landscape ? dockLeft : 12, lowerTop - 48, landscape ? dockWidth : Math.min(280, w - 24), 40));
  const sheetRect = rect(safe.left + 8, landscape ? 8 : 110, landscape ? dockWidth : Math.min(280, w - safe.left - safe.right - 16), landscape ? h - safe.bottom - 28 : lowerTop - 166);
  const header = { ...surface('#header', rect(sheetRect.left + 8, sheetRect.top + 8, sheetRect.width - 68, 44)), position: 'sticky' };
  const closeRect = rect(sheetRect.right - 48, sheetRect.top + 8, 44, 44);
  const sheets = [{ ...surface('#setpanel', sheetRect), header, closeKeys: ['#close'], content: [{ owner: '#text', text: 'Native populated Settings', rect: rect(sheetRect.left + 8, sheetRect.top + 60, 100, 16), clips: [] }] }];
  const boardIds = ['docksurvey', 'dockcodex', 'primechip', 'dockshipyard', 'dockatlas'];
  const utilityIds = ['dockrecords', 'docknotifications', 'dockguide', 'docksets'];
  const boards = compact ? boardIds.map((id, i) => ({ ...surface('#' + id, rect(dockLeft + pitch * i + 2, dockTop, pitch - 4, 44)), id, intrinsicHeight: 44, face: null }))
    : [{ ...surface('#primechip', rect(w / 2 - 35, 10, 70, 44)), id: 'primechip', intrinsicHeight: 44, face: null }];
  const utilities = utilityIds.map((id, i) => {
    const r = rect(dockLeft + (compact ? pitch * (i + 1) - 22 : pitch * i), dockTop + (compact ? 48 : 0), 44, 44);
    return { ...surface('#' + id, r), id, intrinsicHeight: 44, face: surface('#' + id + '-face', rect(r.left + 4, r.top + 4, 36, 36)) };
  });
  const dockButtons = [...boards, ...utilities];
  const controls = [...dockButtons, surface('#dockinventory', rect(safe.left + 12, 12, 128, 44)), surface('#close', closeRect)].map(c => ({ ...c, nativeOwner: c.key, touchOwner: c.key, ancestors: [], enabled: true, fullExposure: true, hit: true, hitOwner: c.key, name: c.key }));
  return { schema: 'cf-v2-layout-snapshot/v1', viewport: { ...rect(0, 0, w, h), dpr: vp.dpr, maxTouchPoints: vp.mobile ? 5 : 0 }, bodyClass: 'panel-open',
    presentation: { guidance: { marked: false, retained: true }, notice: { compact: false, message: null, messageRetained: false, title: null, titleRetained: false } }, compact, panelOpen: true, safe,
    published: { topbar: 100, dock: dockHeight }, roots, controls, sheets, dockButtons, pageOverflow: false, inventoryOverflow: false, exclusions: [{ kind: 'scene-backdrop', selectors: ['#scene'] }] };
}
const assess = (s: any, vp = LAYOUT_VIEWPORTS[0]) => assessLayoutSnapshot(s, { viewport: vp, expectedSheets: ['setpanel'] });
const move = (r: any, dx: number, dy = 0) => rect(r.left + dx, r.top + dy, r.width, r.height);
const clip = (r: any, modeX = 'visible', modeY = 'auto') => ({ key: '#scroller', rect: r, x: modeX !== 'visible', y: modeY !== 'visible', modeX, modeY, scrollLeft: 0, scrollTop: 0, scrollWidth: r.width, scrollHeight: 200, clientWidth: r.width, clientHeight: r.height });
const finding = (s: any, code: string, vp = LAYOUT_VIEWPORTS[0]) => assess(s, vp).findings.some((f: any) => f.code === code);
const extraTarget = (s: any, r = rect(180, 12, 44, 44)) => { const c = { ...structuredClone(s.controls[0]), ...surface('#probe', r), nativeOwner: '#probe', touchOwner: '#probe', hitOwner: '#probe', name: 'Icon-only probe' }; s.controls.push(c); return c; };
const pixel = (key: string, left = 12, top = 420) => ({ ...surface(key, rect(left, top, 1, 1)), overflowX: 'hidden', overflowY: 'hidden', clipPath: 'inset(50%)' });

describe('prepared U4 contract — synthetic unit geometry is not native browser evidence', () => {
  it.each(LAYOUT_VIEWPORTS)('accepts the exact named $label geometry', (vp: any) => {
    const result = assess(fixture(vp), vp); expect(result.findings).toEqual([]); expect(result.pass).toBe(true); expect(result.complete).toBe(true);
  });
  it('rejects one deliberate fault in every checker family, then accepts the untouched carrier again', () => {
    const mutants: Record<string, (s: any) => void> = {
      VIEWPORT: s => { s.controls[0].rect = move(s.controls[0].rect, -500); s.controls[0].exposed = rect(0, 0, 0, 0); s.controls[0].fullExposure = false; },
      TOPBAR_SYNC: s => { s.published.topbar += 12; },
      DOCK_IDENTITY: s => { s.dockButtons.pop(); },
      DOCK_GEOMETRY: s => { s.dockButtons[1].rect = move(s.dockButtons[1].rect, 7); },
      TARGET_FLOOR: s => { s.controls[0].rect.width = 43; s.controls[0].rect.right = s.controls[0].rect.left + 43; s.controls[0].exposed = s.controls[0].rect; },
      TARGET_HIT: s => { s.controls[0].hit = false; s.controls[0].hitOwner = '#cover'; },
      INTERACTIVE_OVERLAP: s => { s.controls[1].rect = { ...s.controls[0].rect }; s.controls[1].exposed = s.controls[1].rect; },
      LANE_OVERLAP: s => { s.roots.toast.rect = { ...s.sheets[0].rect }; },
      SHEET_POPULATION: s => { s.sheets[0].content = []; },
      SHEET_HEADER: s => { s.sheets[0].header.position = 'static'; },
      TARGET_CLIP: s => { const c = s.controls[0]; c.exposed = rect(c.rect.left, c.rect.top, 22, 22); c.clips = [clip(c.exposed, 'hidden', 'hidden')]; },
      LOWER_LANE_OVERLAP: s => { s.roots.ctxbar.rect = { ...s.roots.hintpill.rect }; },
      SHEET_OVERLAP: s => { s.sheets.push({ ...structuredClone(s.sheets[0]), key: '#survey' }); },
      PRESENTATION_STATE: s => { s.roots.hintpill.visible = false; },
      CONTENT_CLIP: s => { const p = s.sheets[0].content[0]; p.clips = [{ key: '#text', x: true, y: true, modeX: 'hidden', modeY: 'hidden', rect: rect(p.rect.left, p.rect.top, 8, 8), scrollLeft: 0, scrollTop: 0, scrollWidth: 100, scrollHeight: 16, clientWidth: 8, clientHeight: 8 }]; },
    };
    expect(Object.keys(mutants).sort()).toEqual([...LAYOUT_FAMILIES].sort());
    for (const [family, mutate] of Object.entries(mutants)) {
      const clean = fixture(), altered = structuredClone(clean); mutate(altered); const result = assess(altered);
      expect(result.pass, family).toBe(false); expect(result.findings.some((f: any) => f.code === family), family).toBe(true);
      expect(result.findings.find((f: any) => f.code === family).detail.length).toBeGreaterThan(10);
      expect(assess(clean).pass, family + ' restoration').toBe(true);
    }
  });
  it('retains the reported b457a7a 22.5px Planetside/hint intersection', () => {
    const s = fixture(); s.sheets[0].key = '#planetside'; s.sheets[0].rect = rect(12, 210, 296, 180);
    s.roots.hintpill.rect = rect(12, 367.5, 296, 76.5);
    const result = assessLayoutSnapshot(s, { viewport: LAYOUT_VIEWPORTS[0], expectedSheets: ['planetside'] });
    const finding = result.findings.find((f: any) => f.target === '#planetside + #hintpill');
    expect(finding.code).toBe('LANE_OVERLAP'); expect(finding.actual.intersection.height).toBe(22.5);
  });
  it('does not count an absent, header-only, wrong viewport or truncated inventory as PASS', () => {
    const s = fixture(); s.sheets = []; expect(assess(s).findings.some((f: any) => f.code === 'SHEET_POPULATION')).toBe(true);
    expect(assessLayoutSnapshot(s, { viewport: LAYOUT_VIEWPORTS[0], expectedSheets: [], requireActiveSheet: false }).pass).toBe(true);
    s.inventoryOverflow = true; expect(assess(s).findings.some((f: any) => f.code === 'SNAPSHOT')).toBe(true);
    expect(assess(fixture(), { label: 'invented' }).pass).toBe(false);
  });
  it('excludes only same-native-owner ancestry, not overlapping independent actions', () => {
    const s = fixture(), child = structuredClone(s.controls[0]); child.key = '#inner-label'; child.ancestors = [s.controls[0].key]; s.controls.push(child);
    expect(assess(s).exclusions.some((e: any) => e.kind === 'same-native-control-ancestry')).toBe(true);
    child.nativeOwner = '#different-button'; expect(assess(s).findings.some((f: any) => f.code === 'INTERACTIVE_OVERLAP')).toBe(true);
  });
  it('permits actual scroll-reachable content but rejects unreachable transformed or hidden clipping', () => {
    const s = fixture(), piece = s.sheets[0].content[0], top = s.sheets[0].rect.top;
    piece.rect = rect(24, top + 500, 100, 16); piece.clips = [{ key: '#setpanel', x: false, y: true, modeX: 'visible', modeY: 'auto', rect: s.sheets[0].rect, scrollLeft: 0, scrollTop: 0, scrollWidth: 280, scrollHeight: 900, clientWidth: 280, clientHeight: 222 }];
    expect(assess(s).findings.filter((f: any) => f.code === 'CONTENT_CLIP')).toEqual([]);
    piece.clips[0].scrollHeight = 200; expect(assess(s).findings.some((f: any) => f.code === 'CONTENT_CLIP')).toBe(true);
  });
  it('requires the exact ten viewport names, dimensions, DPR, four safe insets and observed touch mode', () => {
    const rows = LAYOUT_VIEWPORTS.map((viewport: any) => ({ viewport, snapshot: fixture(viewport) }));
    expect(assessLayoutViewportInventory(rows).pass).toBe(true);
    const badInventories = [rows.slice(1), [...rows, rows[0]], [rows[0], ...rows.slice(0, 9)],
      [...rows.slice(0, 9), { viewport: { ...rows[9].viewport, label: 'ultrawide' }, snapshot: rows[9].snapshot }]];
    for (const bad of badInventories) expect(assessLayoutViewportInventory(bad).findings.some((f: any) => f.code === 'VIEWPORT_INVENTORY')).toBe(true);
    const mutations: Record<string, (row: any) => void> = {
      width: row => { row.viewport.width++; }, height: row => { row.snapshot.viewport.height++; }, dpr: row => { row.snapshot.viewport.dpr++; },
      mobile: row => { row.viewport.mobile = false; }, touch: row => { row.snapshot.viewport.maxTouchPoints = 0; },
      missingTouch: row => { delete row.snapshot.viewport.maxTouchPoints; },
    };
    for (const [name, mutate] of Object.entries(mutations)) { const row = structuredClone(rows[0]); mutate(row); expect(assessLayoutViewportIdentity(row.viewport, row.snapshot).pass, name).toBe(false); }
    for (const i of [0, 4]) for (const edge of ['top', 'right', 'bottom', 'left']) for (const carrier of ['configured', 'observed']) {
      const row = structuredClone(rows[i]);
      if (carrier === 'configured') row.viewport.safe = { top: 0, right: 0, bottom: 0, left: 0, ...row.viewport.safe, [edge]: row.snapshot.safe[edge] + 1 };
      else row.snapshot.safe[edge]++;
      expect(assessLayoutViewportIdentity(row.viewport, row.snapshot).findings.some((f: any) => f.code === 'SAFE_AREA'), `${i}/${edge}/${carrier}`).toBe(true);
    }
    const desktop = structuredClone(rows[8]); desktop.snapshot.viewport.maxTouchPoints = 5;
    expect(assessLayoutViewportIdentity(desktop.viewport, desktop.snapshot).findings.some((f: any) => f.code === 'TOUCH_MODE')).toBe(true);
    expect(LAYOUT_ADMISSION_FAMILIES).toEqual(['VIEWPORT_INVENTORY', 'VIEWPORT_IDENTITY', 'SAFE_AREA', 'TOUCH_MODE']);
    expect(assessLayoutViewportInventory(rows).pass).toBe(true);
  });
  it('rejects a partially clipped 44px icon, including cross-axis or undersized-scroller excuses', () => {
    const s = fixture(), c = extraTarget(s); c.fullExposure = true; // A stale claimed boolean cannot hide clipping.
    c.exposed = rect(c.rect.left, c.rect.top, 22, 22); c.clips = [clip(c.exposed, 'hidden', 'hidden')];
    expect(finding(s, 'TARGET_CLIP')).toBe(true);
    c.clips.push(clip(rect(160, 0, 80, 100), 'visible', 'auto')); expect(finding(s, 'TARGET_CLIP')).toBe(true);
    c.clips = [clip(rect(180, 12, 22, 22), 'auto', 'auto')]; expect(finding(s, 'TARGET_CLIP')).toBe(true);
    c.clips = []; expect(finding(s, 'TARGET_CLIP')).toBe(true);
    c.rect = rect(-10, 12, 44, 44); c.exposed = rect(0, 12, 34, 44); c.clips = [clip(rect(0, 0, 80, 100))];
    expect(finding(s, 'VIEWPORT')).toBe(true);
    const large = fixture(), wide = extraTarget(large, rect(170, 12, 100, 44));
    wide.exposed = rect(170, 12, 60, 44); wide.clips = [clip(rect(170, 0, 60, 100), 'hidden', 'visible')];
    expect(finding(large, 'TARGET_CLIP')).toBe(true); // Even a remaining 60px area cannot excuse a cut control.
  });
  it('defers actual same-axis scroll-reachable targets without hit credit, then re-proves the revealed native target', () => {
    const s = fixture(), c = extraTarget(s, rect(180, 40, 44, 44));
    c.exposed = rect(180, 40, 44, 16); c.clips = [clip(rect(160, 0, 80, 56))]; c.hit = false;
    let result = assess(s); expect(result.pass).toBe(true); expect(result.complete).toBe(false);
    expect(result.deferredTargets.map((d: any) => d.key)).toEqual(['#probe']);
    expect(result.exclusions.some((e: any) => e.kind === 'native-reveal-required-no-hit-credit')).toBe(true);
    c.clips[0].scrollHeight = 56; expect(finding(s, 'TARGET_CLIP')).toBe(true);
    c.clips[0].scrollHeight = 200; c.rect = rect(180, 12, 44, 44); c.exposed = c.rect;
    expect(finding(s, 'TARGET_HIT')).toBe(true); c.hit = true; result = assess(s);
    expect(result.pass).toBe(true); expect(result.complete).toBe(true); expect(result.deferredTargets).toEqual([]);
    const wide = extraTarget(fixture(), rect(180, 12, 100, 44));
    const partial = fixture(); partial.controls.push(wide); wide.exposed = rect(180, 12, 60, 44); wide.clips = [clip(rect(170, 0, 70, 100), 'auto', 'visible')]; wide.clips[0].scrollWidth = 200;
    expect(assess(partial).complete).toBe(false); expect(assess(partial).deferredTargets).toHaveLength(1);
  });
  it('checks lower lanes and independent sheets pairwise, exempting only actual DOM ancestry or protected modal background', () => {
    const s = fixture(); s.roots.ctxbar.rect = { ...s.roots.hintpill.rect }; expect(finding(s, 'LOWER_LANE_OVERLAP')).toBe(true);
    s.roots.ctxbar = fixture().roots.ctxbar;
    const second = { ...structuredClone(s.sheets[0]), key: '#planetside' }; s.sheets.push(second);
    expect(finding(s, 'SHEET_OVERLAP')).toBe(true); second.ancestors = ['#setpanel'];
    expect(finding(s, 'SHEET_OVERLAP')).toBe(false); expect(assess(s).exclusions.some((e: any) => e.kind === 'same-sheet-dom-ancestry')).toBe(true);
    second.ancestors = []; second.key = '#inventorysheet'; second.modal = true; s.sheets[0].inert = true; s.sheets[0].ariaHidden = true;
    let result = assessLayoutSnapshot(s, { viewport: LAYOUT_VIEWPORTS[0], expectedSheets: ['inventorysheet'] });
    expect(result.findings.some((f: any) => f.code === 'SHEET_OVERLAP')).toBe(false);
    expect(result.exclusions.some((e: any) => e.kind === 'modal-protected-background')).toBe(true);
    s.sheets[0].ariaHidden = false; expect(finding(s, 'SHEET_OVERLAP')).toBe(true);
    s.sheets[0].ariaHidden = true; second.modal = false; expect(finding(s, 'SHEET_OVERLAP')).toBe(true);
    s.sheets = [fixture().sheets[0]]; expect(assess(s).pass).toBe(true);
  });
  it('admits only the retained owned portrait Surface+Survey one-pixel guidance yield', () => {
    const clean = fixture(), s = structuredClone(clean); s.bodyClass = 'surface-mode card-open';
    s.sheets[0].key = '#survey'; s.sheets[0].rect = rect(8, 110, 280, 140);
    s.sheets.push({ ...structuredClone(s.sheets[0]), key: '#planetside', rect: rect(8, 258, 280, 72), content: [{ owner: '#roster', text: 'Native biosphere roster', rect: rect(16, 270, 100, 16), clips: [] }] });
    s.roots.hintpill = pixel('#hintpill'); s.presentation.guidance.marked = true;
    const check = (v: any) => assessLayoutSnapshot(v, { viewport: LAYOUT_VIEWPORTS[0], expectedSheets: ['survey', 'planetside'] });
    expect(check(s).findings).toEqual([]); expect(check(s).complete).toBe(false);
    expect(check(s).pendingProofs.map((p: any) => p.kind)).toEqual(['owned-guidance-capacity-and-restoration']);
    expect(check(s).exclusions.some((e: any) => e.kind === 'owned-guidance-yield-no-painted-lane')).toBe(true);
    const mutations = [(v: any) => { v.presentation.guidance.marked = false; }, (v: any) => { v.presentation.guidance.retained = false; },
      (v: any) => { v.roots.hintpill.visible = false; }, (v: any) => { v.roots.hintpill.ariaHidden = true; }, (v: any) => { v.roots.hintpill.clipPath = 'none'; },
      (v: any) => { v.bodyClass = 'panel-open'; }, (v: any) => { v.sheets.pop(); }];
    for (const mutate of mutations) { const v = structuredClone(s); mutate(v); expect(check(v).findings.some((f: any) => f.code === 'PRESENTATION_STATE')).toBe(true); }
    expect(assess(clean).pass).toBe(true); expect(assess(clean).exclusions.some((e: any) => e.kind === 'owned-guidance-yield-no-painted-lane')).toBe(false);
    clean.roots.hintpill = { ...pixel('#hintpill'), clipPath: 'none' }; expect(finding(clean, 'PRESENTATION_STATE')).toBe(true);
  });
  it('keeps a painted toast headline while retaining its compact detail, with no blanket hidden-copy exemption', () => {
    const s = fixture(), n = s.presentation.notice; n.compact = true; n.message = pixel('#message'); n.messageRetained = true;
    n.title = surface('#title', rect(s.roots.toast.rect.left + 4, s.roots.toast.rect.top + 4, 120, 20)); n.titleRetained = true;
    expect(finding(s, 'PRESENTATION_STATE')).toBe(false); expect(assess(s).exclusions.some((e: any) => e.kind === 'owned-compact-notice-detail-not-painted')).toBe(true);
    for (const property of ['messageRetained', 'titleRetained']) { n[property] = false; expect(finding(s, 'PRESENTATION_STATE')).toBe(true); n[property] = true; }
    n.title.visible = false; expect(finding(s, 'PRESENTATION_STATE')).toBe(true); n.title.visible = true;
    n.message.ariaHidden = true; expect(finding(s, 'PRESENTATION_STATE')).toBe(true); n.message.ariaHidden = false;
    n.title.exposed = rect(n.title.rect.left, n.title.rect.top, 0, 0); expect(finding(s, 'PRESENTATION_STATE')).toBe(true); n.title.exposed = n.title.rect;
    n.message.clipPath = 'none'; expect(finding(s, 'PRESENTATION_STATE')).toBe(true); n.message.clipPath = 'inset(50%)';
    const landscape = fixture(LAYOUT_VIEWPORTS[4]); landscape.presentation.notice = structuredClone(n);
    expect(finding(landscape, 'PRESENTATION_STATE', LAYOUT_VIEWPORTS[4])).toBe(true);
    expect(finding(s, 'PRESENTATION_STATE')).toBe(false);
  });
  it('source-executes exact absent-style cleanup against the observed CSSOM failure model; direct removal remains red', () => {
    for (const directRemoveMutant of [false, true]) {
      const dom = new JSDOM('<!doctype html><html><body></body></html>', { runScripts: 'outside-only' }), w = dom.window;
      const nativeRemove = w.Element.prototype.removeAttribute;
      w.Element.prototype.removeAttribute = function (this: any, name: string) {
        if (name === 'style' && this.getAttribute('style')) { this.setAttribute('style', ''); return; }
        nativeRemove.call(this, name);
      };
      const exact = "row.node.setAttribute('style','');row.node.removeAttribute('style');", source = applyLayoutFault.toString();
      expect(source.split(exact)).toHaveLength(2);
      const apply = w.eval('(' + (directRemoveMutant ? source.replace(exact, "row.node.removeAttribute('style');") : source) + ')');
      apply('TOPBAR_SYNC', fixture()); const receipt = apply('', fixture(), true);
      expect(receipt.exact).toBe(!directRemoveMutant); expect(w.document.documentElement.hasAttribute('style')).toBe(directRemoveMutant); w.close();
    }
  });
  it('executes the serialized reader and retains own-element clipping without scene canvas targets', () => {
    const dom = new JSDOM('<!doctype html><style>*{opacity:1}</style><body><canvas id="scene" tabindex="0"></canvas><div id="topbar"></div><div id="dock"><button id="docksets">Settings</button></div><div id="hintpill"></div><div id="ctxbar"></div><div id="toast"></div><aside id="setpanel" class="panel"><h3 class="sheet-header">Header only</h3><button data-pnx="set">Close</button><p id="text" style="overflow-x:hidden;overflow-y:hidden">Real content</p></aside></body>', { runScripts: 'outside-only' });
    const w = dom.window; w.CSS = { escape: (v: string) => v }; w.document.elementFromPoint = () => w.document.getElementById('docksets');
    w.HTMLElement.prototype.getBoundingClientRect = () => rect(10, 10, 100, 44);
    w.HTMLElement.prototype.getClientRects = () => [rect(10, 10, 100, 44)];
    w.Range.prototype.getClientRects = () => [rect(10, 10, 100, 16)];
    Object.defineProperty(w.navigator, 'maxTouchPoints', { value: 5 });
    const result = w.eval('(' + readLayoutSnapshot.toString() + ')()');
    expect(result.viewport.maxTouchPoints).toBe(5); expect(result.presentation.guidance.marked).toBe(false);
    expect(result.presentation.guidance.retained).toBe(false); expect(result.sheets[0].modal).toBe(false);
    expect(result.controls.some((c: any) => c.key === '#scene')).toBe(false);
    const sheet = result.sheets.find((p: any) => p.key === '#setpanel'); expect(sheet.content).toHaveLength(1);
    expect(sheet.content[0].clips.some((c: any) => c.key === '#text' && c.modeX === 'hidden')).toBe(true);
    w.close();
  });
  it('executes each CSS fault owner and restores absent/empty styles plus original child identities', () => {
    for (const family of LAYOUT_FAMILIES) {
      const s = fixture(); s.sheets.push({ ...structuredClone(s.sheets[0]), key: '#survey' });
      const ids = new Set(s.controls.map((c: any) => c.key.slice(1))); ids.delete('close');
      const dom = new JSDOM('<!doctype html><body>' + [...ids].map(id => `<button id="${id}">Target</button>`).join('') + '<div id="toast" style=""></div><div id="hintpill">Guidance</div><div id="ctxbar">Caption</div><aside id="survey">Second sheet</aside><aside id="setpanel"><h3 id="header" class="sheet-header">Title</h3><button id="close" data-pnx="set">Close</button><p id="text">Native body</p></aside></body>', { runScripts: 'outside-only' });
      const w = dom.window; w.HTMLElement.prototype.getBoundingClientRect = () => rect(12, 240, 100, 44);
      const before = w.document.documentElement.outerHTML, bodyChild = w.document.getElementById('text');
      const apply = w.eval('(' + applyLayoutFault.toString() + ')'); apply(family, s);
      const receipt = apply('', s, true); expect(receipt.exact, family).toBe(true); expect(receipt.coverRemoved, family).toBe(true); expect(receipt.wrapperRemoved, family).toBe(true);
      expect(w.document.documentElement.outerHTML, family).toBe(before); expect(w.document.getElementById('text')).toBe(bodyChild); w.close();
    }
  });
});
