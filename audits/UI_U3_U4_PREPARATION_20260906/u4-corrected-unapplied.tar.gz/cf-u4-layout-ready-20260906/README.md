# U4 corrected preparation — not executed

Prepared by OpenAI/Codex on macOS for the owned root `/Users/nick/Projects/celestial-frontier-openai-mac`, branch `openai/mac`, source observed at `781b79cf75538b711bb770a42c189c6dc70eeb16`.

This new directory leaves `/private/tmp/cf-u4-layout-prepared-20260906` immutable. No checkout edits, installer execution, test, build, browser, screenshot, commit, hosted action or gate PASS. Apply only after the ordered U3 steps and root review.

- `ui-layout-contract.mjs`: self-contained DOM reader, pure geometry/ten-viewport assessors, reversible diagnostic fault owner.
- `ui-layout-contract.test.ts`: source-executing synthetic fixtures and negative controls, prepared but **NOT RUN**.
- `PREPARATION.json`: exact payload hashes and unique current-source anchors.
- `apply-at-u4.py`: reviewed HEAD/root/branch/clean tracked source and exact-anchor checks; atomically adds only the two absent instrument/test destinations. It neither integrates a runner nor runs a check.
- `INTEGRATION.md`: concrete collector API and remaining evidence obligations.

Corrections cover every partially clipped native target, including icon-only controls and a target whose surviving area still exceeds 44px. A native same-axis scroller with sufficient actual extent can defer a target; it cannot earn a hit PASS before native reveal. Hidden clipping, an unrelated scroller, inadequate extent or a sub-44px clip owner fail. Pairwise lower-lane intersections and independent sheet intersections now fail separately; only explicit DOM ancestry and the actual Inventory modal's inert plus ARIA-hidden background have named exclusions.

Admission uses the ten explicit existing Glass labels, from small-phone through desktop-1080p, with exact dimensions/DPR/mobile configuration, all four safe inset values and observed `navigator.maxTouchPoints` (5 for touch, 0 otherwise). Duplicates, omissions and substitutions fail. The current compact dock has five scene buttons plus four utilities, a 320px cap and content-derived upper-row height; wide utility dock is 200px with 52px pitch. Published chrome heights are read from the actual document-element owner. No unused historical launcher-size token supplies an expectation.

`#hintpill.sheet-guidance-yield` earns no painted lane only with its retained text/ARIA, exact 1px clipping and portrait Surface+Survey stack. That snapshot **remains incomplete**: `pendingProofs` requires independent native tight-capacity measurement plus exact reveal/restore and natural guidance after Close or room returns. Product `--cf-*` spacing variables and the class/route alone cannot satisfy it. A compact toast requires its retained 1px detail and a visibly painted headline; arbitrary hidden content receives no exemption.

Fault cleanup preserves original DOM child identities, wrapper placement, and exact style-attribute absence/bytes. Absent styles use `setAttribute('style','')` before removal. The prepared source-executing regression includes the observed CSSOM failure model and a direct-removal mutant; this is a synthetic guard, not proof of actual browser restoration.

At the U4 boundary, after reviewing the current U3 source:

```sh
python3 /private/tmp/cf-u4-layout-ready-20260906/apply-at-u4.py --u4-reviewed FULL_CURRENT_HEAD
```

The installer is intentionally add-only and will reject stale source anchors or existing destinations. Do not weaken its guards to apply this preparation. Root owns the subsequent focused checks, actual local collector/terminal verifier, normal-build native runs, 28 paired comparisons, checkpoint documentation and local commit.

The earlier collection inventory remains at `/private/tmp/cf-u4-layout-prepared-20260906/collection-plan/`. Its 28 existing v1 images remain legitimate source baselines, but owner/state matches require revalidation after U3. Native v2 paperdoll/legacy inventory tabs and immediate Earth search-results equivalents were absent at preparation; Shipyard population differed from the v1 seeded state. This checker cannot close those differences or claim a completed 28-screen gate. Inventory's actual dialog header still needs independent sticky/Close review; it is not exempted by tag name.

Both earlier U1 unknown causes remain OPEN. U2's retained REDs and source identities are not overwritten by this preparation. No change-profile/workflow or Actions-policy edit is proposed here; adding the eventual U4 gate to develop remains a handoff proposal only.
