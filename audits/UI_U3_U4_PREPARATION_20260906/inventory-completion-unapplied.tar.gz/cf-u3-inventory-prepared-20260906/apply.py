#!/usr/bin/env python3
"""Guarded U3 Inventory content proposal; paperdoll parity remains unimplemented. Default is read-only; --apply writes one HTML file."""
from pathlib import Path
import argparse, hashlib, json, os, platform, subprocess, tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apply', action='store_true')
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
manifest = {'status': 'PREPARED_ONLY_PARTIAL_PARITY_NOT_APPLIED_NOT_EXECUTED',
 'date': '2026-09-06',
 'agent': 'OpenAI/Codex',
 'os': 'macOS',
 'root': '/Users/nick/Projects/celestial-frontier-openai-mac',
 'branch': 'openai/mac',
 'sourceHead': '56648b27b9063132ef01c08ffa8a683d9f45dc25',
 'target': 'port/v2/apps/game/index.html',
 'anchor': '  </style>\n</head>\n<body>\n',
 'marker': 'U3 Inventory: existing exact-item projections',
 'cssSha256': 'f3eec96ac82d2a10d012e883d7bfd8c62acd0485ab0651a738af3afc41d6ee7f',
 'beforeSha256': 'db71621fb31f059014402200cd4577f43d6d171d906482ab9d2068601fbb4f1f',
 'proposalSha256': '34d7e3035a4d4663d5fbae2298438ca6f95216066aeb3679d307d81b30d60d51',
 'unimplementedRequirement': 'Phone paperdoll width min(62vw,240px): no live v2 paperdoll DOM/renderer '
                             'exists. Not applied to the Inventory sheet.',
 'guards': [{'file': 'port/v2/apps/game/index.html',
             'start': '    #inventorypanel { overflow: auto; }',
             'end': '    /* The Compendium owns a bounded inner scroll extent',
             'sha256': 'b9bab8746999d3510304a66f29c45f596bf2cedb65a9a29eb410e2ea145101c0'},
            {'file': 'port/v2/apps/game/index.html',
             'start': '  <aside id="inventorypanel" class="glass panel"',
             'end': '  <script type="module" src="/src/main.ts"></script>',
             'sha256': '38daeba9bb52e9dbb7c7fae856f14b72eed41e34a6a2d2dcfe85d5c523cc2c50'},
            {'file': 'port/v2/apps/game/src/main.ts',
             'start': 'const inventoryPanelController =',
             'end': 'const engineeringPanelController =',
             'sha256': '7a801c064e56c20c1d732358f3a14ddfaf35ce96b3a87c5d6f4d84802cebcf6d'},
            {'file': 'port/v2/apps/game/src/inventory-panel.ts',
             'sha256': '5f38b4ef9ea86741d076e0d8374d7c828716e061197ed2eb6e7c85c70aef4585'},
            {'file': 'port/v2/apps/game/src/inventory-actions.ts',
             'sha256': '1cf802ee279cc26a869ace847a6efc07d83f576597e7807597a53ea85a2a9878'},
            {'file': 'port/v2/apps/game/src/ui-sheet-style.ts',
             'sha256': 'f688b6493cec963a3b312ce98438bfe7d20f54148c564bbb6c1b68ac9d0cf03c'},
            {'file': 'port/v2/apps/game/src/ui-presentation-tokens.ts',
             'sha256': '2a53bfe1510bfbf4d72aa0a29ba40c6f446bbc952bd961445e0eb2871c07b0c7'},
            {'file': 'port/v2/apps/game/src/panels.ts',
             'sha256': 'f911daebf7f344e335e4bb1777d386978c22a4cf41ff2b997e00c25fd9026e8d'}]}
root = Path(manifest['root'])

def require(condition, message):
    if not condition:
        raise SystemExit('REFUSED: ' + message)

def digest(value):
    return hashlib.sha256(value).hexdigest()

require(platform.system() == 'Darwin', 'this proposal is owned by OpenAI/Codex on macOS')
require(Path.cwd().resolve() == root == root.resolve(), 'run from the exact owned physical root')
require(subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], text=True).strip() == str(root), 'Git root mismatch')
require(subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip() == manifest['branch'], 'branch mismatch')
for guard in manifest['guards']:
    data = (root / guard['file']).read_bytes()
    if 'start' in guard:
        text = data.decode('utf-8')
        require(text.count(guard['start']) == text.count(guard['end']) == 1, 'non-unique authority anchor: ' + guard['file'])
        start, end = text.index(guard['start']), text.index(guard['end'])
        require(end > start, 'authority anchor order: ' + guard['file'])
        data = text[start:end].encode('utf-8')
    require(digest(data) == guard['sha256'], 're-review changed authority: ' + guard['file'])
css = (bundle / 'inventory.css').read_bytes()
require(digest(css) == manifest['cssSha256'], 'proposal CSS changed')
target = root / manifest['target']
original = target.read_bytes()
text = original.decode('utf-8')
require(text.count(manifest['anchor']) == 1, 'last style anchor must be exact and unique')
require(manifest['marker'] not in text, 'proposal is already present')
require(text.count('<aside id="inventorypanel" class="glass panel" aria-label="Inventory" aria-hidden="true" style="display:none">') == 1, 'Inventory identity changed')
proposed = text.replace(manifest['anchor'], css.decode('utf-8') + manifest['anchor'], 1).encode('utf-8')
receipt = {'mode': 'APPLY' if args.apply else 'READ_ONLY_CHECK', 'target': str(target), 'beforeSha256': digest(original), 'afterSha256': digest(proposed), 'cssSha256': digest(css)}
if args.apply:
    descriptor, name = tempfile.mkstemp(prefix='.inventory-u3-', suffix='.tmp', dir=target.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, 'wb') as file:
            file.write(proposed)
        os.chmod(temporary, target.stat().st_mode)
        require(target.read_bytes() == original, 'target changed while preparing its copy')
        os.replace(temporary, target)
        require(target.read_bytes() == proposed, 'applied read-back differs')
    finally:
        if temporary.exists():
            temporary.unlink()
print(json.dumps(receipt, indent=2))
