#!/usr/bin/env python3
"""Prepared U3 Inventory completion. Default checks only; --apply writes two guarded copies."""
from pathlib import Path
import argparse, hashlib, json, os, platform, subprocess, tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apply', action='store_true')
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
manifest = json.loads((bundle / 'manifest.json').read_text())
root = Path(manifest['root'])

def require(condition, message):
    if not condition:
        raise SystemExit('REFUSED: ' + message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

require(platform.system() == 'Darwin', 'this proposal belongs to the macOS owned checkout')
require(Path.cwd().resolve() == root == root.resolve(), 'run from the exact physical owned root')
require(subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], text=True).strip() == str(root), 'Git root mismatch')
require(subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip() == manifest['branch'], 'branch mismatch')

authorities = {}
for guard in manifest['guards']:
    path = root / guard['file']
    raw = path.read_bytes()
    authorities[path] = raw
    data = raw
    if 'start' in guard:
        value = raw.decode('utf-8')
        require(value.count(guard['start']) == value.count(guard['end']) == 1,
                'authority anchors must be unique: ' + guard['file'])
        start, end = value.index(guard['start']), value.index(guard['end'])
        require(end > start, 'authority anchor order: ' + guard['file'])
        data = value[start:end].encode('utf-8')
    require(digest(data) == guard['sha256'], 'review changed authority before refreshing guard: ' + guard['file'])

css = (bundle / 'inventory.css').read_bytes()
controller = (bundle / 'inventory-panel.ts').read_bytes()
require(digest(css) == manifest['cssSha256'], 'prepared CSS changed')
require(digest(controller) == manifest['controllerAfterSha256'], 'prepared controller changed')
html_path, controller_path = root / manifest['htmlTarget'], root / manifest['controllerTarget']
before_html, before_controller = html_path.read_bytes(), controller_path.read_bytes()
require(digest(before_controller) == manifest['controllerBeforeSha256'], 'controller source changed')
value = before_controller.decode('utf-8')
for replacement in manifest['controllerReplacements']:
    require(value.count(replacement['before']) == 1, 'controller replacement is not exact and unique')
    value = value.replace(replacement['before'], replacement['after'], 1)
require(value.encode('utf-8') == controller, 'replacement replay differs from prepared controller')
html = before_html.decode('utf-8')
require(html.count(manifest['anchor']) == 1, 'last style anchor must be exact and unique')
require('U3 Inventory: existing exact-item projections' not in html, 'partial or complete Inventory proposal already present')
require(html.count('<aside id="inventorypanel" class="glass panel" aria-label="Inventory" aria-hidden="true" style="display:none">') == 1,
        'Inventory panel shell changed')
after_html = html.replace(manifest['anchor'], css.decode('utf-8') + manifest['anchor'], 1).encode('utf-8')
changes = [(controller_path, before_controller, controller), (html_path, before_html, after_html)]
receipt = {'mode': 'APPLY' if args.apply else 'READ_ONLY_CHECK',
           'preparedSourceHead': manifest['sourceHead'],
           'currentHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
           'files': [{'path': str(path), 'beforeSha256': digest(before), 'afterSha256': digest(after)}
                     for path, before, after in changes],
           'verification': 'NOT RUN; this script does not build, test, or open a browser'}

if args.apply:
    copies = []
    try:
        for path, before, after in changes:
            descriptor, name = tempfile.mkstemp(prefix='.inventory-u3-', suffix='.tmp', dir=path.parent)
            temporary = Path(name)
            copies.append((path, before, after, temporary))
            with os.fdopen(descriptor, 'wb') as file:
                file.write(after)
                file.flush()
                os.fsync(file.fileno())
            os.chmod(temporary, path.stat().st_mode)
            require(temporary.read_bytes() == after, 'prepared copy read-back differs: ' + str(path))
        for path, raw in authorities.items():
            require(path.read_bytes() == raw, 'authority changed during copy preparation: ' + str(path))
        for path, before, after, temporary in copies:
            require(path.read_bytes() == before, 'target changed during copy preparation: ' + str(path))
        # Each replacement is atomic; filesystem APIs cannot transact both files together.
        # A write error is terminal and must be reviewed, never automatically rolled back.
        for path, before, after, temporary in copies:
            os.replace(temporary, path)
            require(path.read_bytes() == after, 'applied read-back differs: ' + str(path))
    finally:
        for path, before, after, temporary in copies:
            if temporary.exists():
                temporary.unlink()
print(json.dumps(receipt, indent=2))
