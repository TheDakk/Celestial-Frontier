# U3 Inventory completion — prepared only

Prepared from `781b79cf75538b711bb770a42c189c6dc70eeb16` on `openai/mac`, 2026-09-06. Nothing here has been applied or executed. No typecheck, tests, build, browser capture, or visual acceptance is claimed. The owned checkout was read only.

This completion contains the earlier partial proposal's 40 CSS lines plus the missing equipment layout and shared-heading work. Use this package **instead of** the parent directory's partial `apply.py`; never apply both. The earlier package remains unchanged for provenance.

## Bounded implementation

- Move the existing Inventory title out of the replaced content body into one persistent direct `h3.sheet-header`, alongside the retained native Close. Existing panel and dialog focus/Escape owners remain responsible for navigation.
- Add a nine-slot equipment layout from the real `GEAR_SLOTS`: helmet, ears, necklace, suit, gloves, legs, boots, tool, module. Its anatomical grid uses the current exact equipped bindings. Names come from `inspectGear`; no portrait or equipment state is invented.
- A populated slot is a native button that opens the existing `showDetail` dialog for that exact currently bound instance. The click handler rechecks the live slot binding. Empty slots are noninteractive and say “Empty”; an unresolved binding says “Unavailable.” Null and protected inventory retain their current notices and facts, without claiming exact equipment state.
- Keep slot selectors separate from existing `data-inventory-row` and `data-instance-id` selectors. Existing item-row counts, filters, action routing, and list focus fallback remain unchanged. Close/Escape before an action can return to the real slot opener; settled actions retain the controller's existing row/fallback focus behavior.
- Cap phone layout width at `min(62vw,240px)`, with 44px minimum slot targets, wrapping item names, existing spacing/color tokens, and forced-colors support. Add panel scroll padding for the shared title; do not change panel anchors, target floors, or sheet allocation.

## Application after preceding U3 panels pass

Review `proposal.diff`, then run from the exact owned root only after the active immutable check has ended. The script defaults to a read-only preflight. Its `--apply` option writes prepared copies of only `port/v2/apps/game/src/inventory-panel.ts` and `port/v2/apps/game/index.html`.

```sh
python3 /private/tmp/cf-u3-inventory-prepared-20260906/completion/apply.py
python3 /private/tmp/cf-u3-inventory-prepared-20260906/completion/apply.py --apply
```

The manifest pins affected Inventory source, exact Main wiring, shared sheet/header/tokens, and slot catalogue. The HTML append permits unrelated preceding U3 CSS additions; the original Inventory region, unique final-style anchor, and shell identity must still match. If an authority changed, review that change before refreshing a guard. The script prepares both files before mutation and atomically replaces each; it cannot provide a cross-file filesystem transaction. Any write failure is terminal for review.

## Verification to add or extend at implementation time

Use the existing `inventory-panel.test.ts`, `inventory-actions.test.ts`, `inventory-narrow-reflow.test.ts`, and relevant Main wiring contracts. Meaningful new cases are nine ordered slots; exact bound names/IDs; honest empty/protected/null output; stale or wrong-slot activation refusal; one persistent direct title; unchanged exact-list row counts; native button activation into the real detail owner and Close/Escape focus return; and existing pending/committed action outcomes and background isolation. Browser verification must cover populated slots, real detail navigation, all text preferences, 44px hit targets, width cap, and sticky header visibility while scrolling. CSS presence alone is not proof of effective layout. The existing producer and draft pins must be refreshed by their established owners because both source and index CSS change.

## Comparison and read-model limits

The original partial preparation records populated v1 gear goldens at `port/baseline-v1.8.9/screens/ui-inv-gear-phone.png` (390×844, SHA-256 `a8b10f83faad2a2024235d2bd1b0c6fc729702ce928429952dadcf73e263004d`) and `ui-inv-gear-desktop.png` (1440×900, `3bb25fe46956feecaa369b75e5492686651bce265008616cc9027680d4aee3f8`). Those prior visual observations informed the existing partial proposal; this completion does not claim a fresh current-v2 comparison.

The current Inventory controller exposes exact held items and equipped slot bindings. It does not supply an avatar portrait model for this layout. This proposal supplies the missing real slot projection; it does not reproduce v1 portrait art, bag grid, or Materials/Craftables/Gear tabs. Existing exact-item comparison remains in the native detail dialog; no new summary stats or synthetic comparison data are introduced. Full v1 Inventory parity must not be inferred from this bounded presentation completion. No user clarification is necessary to implement this scope.
