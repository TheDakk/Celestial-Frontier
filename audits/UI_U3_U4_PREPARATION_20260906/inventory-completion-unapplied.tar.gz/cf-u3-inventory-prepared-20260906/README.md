# U3 Inventory / paperdoll — partial temporary proposal

OpenAI/Codex on macOS, owned `openai/mac` workspace, 2026-09-06.
**Not applied, built, tested, rendered or checkpoint evidence.** Reserved for the final
U3 panel step after Survey/landing card and biosphere pass. No checkout file changed.

## Unimplemented paperdoll requirement

The program requires the phone paperdoll width cap `min(62vw,240px)`.
`UI_PRESENTATION.md:2814` identifies this as the character-sheet paperdoll cap on
<=700px phones, preserving native 44px sockets. Current v2 `inventory-panel.ts` and
`index.html` have no paperdoll renderer, avatar, socket UI or compatible DOM/CSS hook.
Current v2 presents exact inventory instances, real equipped bindings, filters, stacks,
pending rewards, protected legacy counts and one exact item-inspection modal.

This proposal therefore leaves **paperdoll parity and its cap UNIMPLEMENTED**. It does
not add an inert selector, apply the cap to the whole Inventory panel/modal, import v1
state, invent slots/actions/art or remove promised copy. Passing later checks on this
CSS alone cannot close the program's full Inventory/paperdoll requirement.

## Existing-content styling proposal

`inventory.css` styles existing item rows, full state badges, filters, stack/legacy
cards, pager, fact blocks and detail section headings/actions. Existing <=360px row
stacking and <=480px tools/facts layout stay in place; long badges wrap fully rather
than losing words. No renderer/model/content/field/ID/action/ARIA/writer change.

Native panel and modal dimensions, Close controls, header owners, internal scrolling,
modal backdrop, hidden/inert/aria-hidden isolation and exact focus return remain
unchanged. All equipped comparison numbers, source/condition metadata, pending claims,
protection/refusal text, salvage confirmation and live status remain present. The
proposal does not collapse disclosure content, clamp text or change comparison columns.

Source caveat retained for the later native review: the Inventory h3 is generated
inside `.inventory-panel-body`; `panels.ts:56` assigns `.sheet-header` only to direct
panel headings. This proposal does not move/copy the title or claim its existing
nested title has passed the shared U2 sticky-header criterion.

## Guarded application and files

Only four temporary files: this README, `inventory.css`, `inventory.patch`, `apply.py`.
The apply script embeds exact source/hash guards. From the owned repository, at the
later ordered checkpoint, `python3 /private/tmp/cf-u3-inventory-prepared-20260906/apply.py`
checks guards. Explicit `--apply` inserts the reviewed CSS at the unique final-style
anchor through a temporary copy, concurrent-drift check and atomic replacement of only
the HTML. Neither command ran. Changed Inventory renderer/actions/markup, base styles,
shared sheet/panel owner or tokens require re-review and guard refresh; do not bypass.
Applying this partial styling does not mark the missing paperdoll requirement complete.

## Golden association

Both existing v1 gear goldens were visually read, not regenerated; source manifest is
`port/baseline-v1.8.9/screens/MANIFEST.json`. Their populated loadout includes a full
explorer paperdoll with equipped sockets, effects, Materials/Craftables/Gear tabs and a
bag grid. Current-v2's exact-instance sheet is a different current surface. Preserve
that mismatch in later visual comparison. No populated save was copied or fabricated,
no current-v2 before/after image was made, and there is no pixel/byte acceptance claim.

- `ui-inv-gear-desktop.png` — 1440x900, populatedSave=true; observed SHA256 `3bb25fe46956feecaa369b75e5492686651bce265008616cc9027680d4aee3f8` (manifest `3bb25fe46956feecaa369b75e5492686651bce265008616cc9027680d4aee3f8`).
- `ui-inv-gear-phone.png` — 390x844, populatedSave=true; observed SHA256 `a8b10f83faad2a2024235d2bd1b0c6fc729702ce928429952dadcf73e263004d` (manifest `a8b10f83faad2a2024235d2bd1b0c6fc729702ce928429952dadcf73e263004d`).

## Later checkpoint ownership

`port/UI_PARITY_PROGRAM_U1_U4.md:317–322` owns order, paperdoll cap and before/after proof.
Renderer/detail/action owners: `inventory-panel.ts:345`, `:437`, `:703`, `:847`;
modal lifetime isolation remains in its `#lockBackground`/`#unlockBackground` owner.
Current modal-lifetime reference is `UI_PRESENTATION.md:389` onward.

Parent owns required validation and existing Inventory/model/actions/panel/narrow-reflow
checks, normal native open/item inspection/Close-focus/full protected-background
outcomes, small/phone/desktop/landscape/large-text bounds, complete comparison/copy and
real reachable pending/equipped/protected states as applicable. New geometry checks need
meaningful failure/restoration controls. No native-layout, gameplay or cap PASS exists.

U2 remains active. Both earlier U1 causes stay open (unsolicited navigation and portrait-
restoration Runtime.evaluate timeout). No Inkscape, hosted action or Phase 2 work.
Codex holds this final-step proposal until Survey/biosphere passes; Claude is untouched
and Nick need not open Claude for this temporary preparation.
