/* Prepared serialized browser readers. No app probe bindings or save fabrication. */
export function readNativeTarget(selector) {
  const matches=document.querySelectorAll(selector),node=matches[0];
  if(matches.length!==1)return{selector,usable:false,issues:['target-count:'+matches.length],owners:[]};
  const box=e=>{const r=e.getBoundingClientRect();return{left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height};};
  const key=e=>{if(e.id)return'#'+CSS.escape(e.id);const parts=[];for(let n=e;n&&n!==document.documentElement;n=n.parentElement){if(n.id){parts.unshift('#'+CSS.escape(n.id));break;}parts.unshift(n.tagName.toLowerCase()+':nth-of-type('+([...n.parentElement.children].filter(x=>x.tagName===n.tagName).indexOf(n)+1)+')');}return parts.join('>');};
  const pixels=s=>parseFloat(s)||0,rs=getComputedStyle(document.documentElement),r=box(node),issues=[],clips=[],owners=[];
  const bounds={left:pixels(rs.getPropertyValue('--safe-left')),top:pixels(rs.getPropertyValue('--safe-top')),right:innerWidth-pixels(rs.getPropertyValue('--safe-right')),bottom:innerHeight-pixels(rs.getPropertyValue('--safe-bottom'))};
  const exposed={...bounds};let visible=true;
  for(let n=node;n;n=n.parentElement){const s=getComputedStyle(n),b=box(n);
    if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0||n.hidden)visible=false;
    if(n===node)continue;
    const port={left:b.left+n.clientLeft,top:b.top+n.clientTop,right:b.left+n.clientLeft+n.clientWidth,bottom:b.top+n.clientTop+n.clientHeight};
    const x=/^(auto|scroll|hidden|clip)$/.test(s.overflowX),y=/^(auto|scroll|hidden|clip)$/.test(s.overflowY);
    if(x){exposed.left=Math.max(exposed.left,port.left);exposed.right=Math.min(exposed.right,port.right);}
    if(y){exposed.top=Math.max(exposed.top,port.top);exposed.bottom=Math.min(exposed.bottom,port.bottom);}
    if(x||y)clips.push({selector:key(n),port,x,y,modeX:s.overflowX,modeY:s.overflowY,scrollLeft:n.scrollLeft,scrollTop:n.scrollTop,scrollWidth:n.scrollWidth,scrollHeight:n.scrollHeight,clientWidth:n.clientWidth,clientHeight:n.clientHeight});
    if(/^(auto|scroll)$/.test(s.overflowX)&&n.scrollWidth>n.clientWidth+1||/^(auto|scroll)$/.test(s.overflowY)&&n.scrollHeight>n.clientHeight+1){
      const available={left:Math.max(bounds.left,port.left),right:Math.min(bounds.right,port.right),top:Math.max(bounds.top,port.top),bottom:Math.min(bounds.bottom,port.bottom)};
      for(let parent=n.parentElement;parent;parent=parent.parentElement){const ps=getComputedStyle(parent),q=box(parent);
        if(/^(auto|scroll|hidden|clip)$/.test(ps.overflowX)){available.left=Math.max(available.left,q.left+parent.clientLeft);available.right=Math.min(available.right,q.left+parent.clientLeft+parent.clientWidth);}
        if(/^(auto|scroll|hidden|clip)$/.test(ps.overflowY)){available.top=Math.max(available.top,q.top+parent.clientTop);available.bottom=Math.min(available.bottom,q.top+parent.clientTop+parent.clientHeight);}}
      const header=n.querySelector('.sheet-header,.survey-head');
      if(header&&!header.contains(node)&&!node.matches('[data-pnx],[data-survey-close]')&&getComputedStyle(header).position==='sticky')available.top=Math.max(available.top,box(header).bottom+8);
      available.top+=8;available.bottom-=8;available.left+=2;available.right-=2;
      const point={x:(available.left+available.right)/2,y:(available.top+available.bottom)/2},hit=document.elementFromPoint(point.x,point.y);
      const deltaX=(r.left+r.right-available.left-available.right)/2,deltaY=(r.top+r.bottom-available.top-available.bottom)/2;
      const axis=/^(auto|scroll)$/.test(s.overflowY)&&(r.top<available.top-1||r.bottom>available.bottom+1)?'Y':/^(auto|scroll)$/.test(s.overflowX)&&(r.left<available.left-1||r.right>available.right+1)?'X':null;
      owners.push({selector:key(n),axis,available,point,hit:!!hit&&(n===hit||n.contains(hit)),before:{x:n.scrollLeft,y:n.scrollTop},max:{x:n.scrollWidth-n.clientWidth,y:n.scrollHeight-n.clientHeight},deltaX:axis==='X'?deltaX:0,deltaY:axis==='Y'?deltaY:0,canFit:r.width<=available.right-available.left&&r.height<=available.bottom-available.top});
    }
  }
  const point={x:(r.left+r.right)/2,y:(r.top+r.bottom)/2},hit=document.elementFromPoint(point.x,point.y);
  const full=r.left>=exposed.left-1&&r.right<=exposed.right+1&&r.top>=exposed.top-1&&r.bottom<=exposed.bottom+1;
  const enabled=!node.disabled&&!node.closest('[inert],[aria-hidden="true"]');
  if(!visible)issues.push('hidden');if(!enabled)issues.push('disabled-or-inert');if(r.width<44||r.height<44)issues.push('below-44px');if(!full)issues.push('clipped');if(!(hit===node||node.contains(hit)))issues.push('centre-owned-by-other');
  return{selector,tag:node.tagName,name:node.getAttribute('aria-label')||node.textContent.trim(),rect:r,point,bounds,exposed,clips,owners,visible,enabled,full,hit:hit===node||node.contains(hit),hitOwner:hit?key(hit):null,issues,usable:issues.length===0};
}
export function installAuxiliaryTrace() {
  const t=window.__cfU4NativeAux={events:[],active:null,nextId:0,overflow:false};
  for(const type of ['wheel','scroll','pointermove','mousemove','input'])document.addEventListener(type,e=>{
    if(!t.active)return;if(t.events.length>=2000){t.overflow=true;return;}
    const a=t.active;t.events.push({id:a.id,kind:a.kind,type,trusted:e.isTrusted,at:performance.now(),eventTime:e.timeStamp,selector:a.selector,ownerInPath:e.composedPath().includes(a.node),x:e.clientX??null,y:e.clientY??null,deltaX:e.deltaX??null,deltaY:e.deltaY??null,scrollLeft:a.node.scrollLeft,scrollTop:a.node.scrollTop});
  },{capture:true,passive:true});return true;
}
export function readGuidanceCapacity() {
  const hint=document.getElementById('hintpill'),survey=document.getElementById('survey'),side=document.getElementById('planetside');
  const visible=n=>{if(!n)return false;const r=n.getBoundingClientRect();for(let a=n;a;a=a.parentElement){const c=getComputedStyle(a);if(c.display==='none'||c.visibility==='hidden'||Number(c.opacity)<=0)return false;}return r.width>0&&r.height>0;};
  const accessible=n=>!!n&&n.textContent.trim().length>0&&!n.closest('[hidden],[inert],[aria-hidden="true"]')&&!n.querySelector('[hidden],[inert],[aria-hidden="true"]');
  const snapshot=()=>{const r=hint.getBoundingClientRect(),s=getComputedStyle(hint);return{attributes:hint.getAttributeNames().sort().map(k=>[k,hint.getAttribute(k)]),html:hint.innerHTML,text:hint.textContent,bodyClass:document.body.getAttribute('class'),rect:[r.left,r.top,r.right,r.bottom,r.width,r.height],style:[s.display,s.visibility,s.opacity,s.clipPath,s.overflow,s.fontSize,s.fontFamily,s.color]};};
  if(!hint)return{ok:false,reason:'missing-guidance'};
  const before=snapshot(),yielded=hint.classList.contains('sheet-guidance-yield');
  if(!yielded)return{ok:accessible(hint)&&visible(hint)&&before.rect[4]>1&&before.rect[5]>1,yielded:false,before,restored:true};
  const a=survey?.getBoundingClientRect(),b=side?.getBoundingClientRect(),css=getComputedStyle(hint);
  const scoped=innerWidth<=900&&innerHeight>=innerWidth&&document.body.classList.contains('surface-mode')&&document.body.classList.contains('card-open')
    &&visible(survey)&&visible(side)&&Math.min(a.right,b.right)>Math.max(a.left,b.left)&&accessible(hint)&&visible(hint)&&before.rect[4]===1&&before.rect[5]===1&&css.clipPath==='inset(50%)'&&css.overflow==='hidden';
  if(!scoped)return{ok:false,yielded:true,scoped,before,reason:'unowned-guidance-state'};
  const priorClass=hint.getAttribute('class');let native=null,error=null,cleanupError=null,justified=false;
  try{hint.classList.remove('sheet-guidance-yield');native=snapshot();
    const pixels=v=>parseFloat(v||'')||0,safeBottom=pixels(getComputedStyle(document.documentElement).getPropertyValue('--safe-bottom'));
    const lower=Math.min(innerHeight-safeBottom-12,...['hintpill','ctxbar','dock'].map(id=>{const e=document.getElementById(id);return visible(e)?e.getBoundingClientRect().top:innerHeight;}));
    const toast=document.getElementById('toast'),tr=toast?.getBoundingClientRect(),ts=toast?getComputedStyle(toast):null;
    const toastHeight=toast&&ts.display!=='none'&&ts.visibility!=='hidden'&&tr.width>0&&tr.height>0&&(toast.style.opacity==='1'||Number(ts.opacity)>0)?tr.height:0;
    const header=survey.querySelector('.survey-head'),hs=header?getComputedStyle(header):null,ss=getComputedStyle(survey);
    const headerHeight=header?Math.max(44,header.getBoundingClientRect().height)+pixels(hs.marginTop)+pixels(hs.marginBottom):NaN;
    const edges=pixels(ss.paddingTop)+pixels(ss.paddingBottom)+pixels(ss.borderTopWidth)+pixels(ss.borderBottomWidth),minimum=headerHeight+edges+44,start=survey.getBoundingClientRect().top;
    const available=lower-8-(toastHeight>0?toastHeight+8:0)-start,required=minimum+72+8;
    native.capacity={lower,toastHeight,headerHeight,edges,minimum,start,available,required};
    justified=[lower,toastHeight,minimum,start].every(Number.isFinite)&&available<required&&accessible(hint)&&visible(hint)&&native.rect[4]>1&&native.rect[5]>1;
  }catch(e){error=String(e);}finally{try{if(priorClass===null){hint.setAttribute('class','');hint.removeAttribute('class');}else hint.setAttribute('class',priorClass);}catch(e){cleanupError=String(e);}}
  const after=snapshot(),restored=document.getElementById('hintpill')===hint&&JSON.stringify(before)===JSON.stringify(after);
  return{ok:scoped&&justified&&restored&&!error&&!cleanupError,yielded:true,scoped,justified,before,native,after,restored,error,cleanupError,scope:'independent actual DOM capacity; no product --cf-* spacing variables or app state hook'};
}
export function readGuidanceAfterClose() {
  const h=document.getElementById('hintpill'),s=document.getElementById('survey'),r=h?.getBoundingClientRect(),c=h?getComputedStyle(h):null;
  const text=h?.textContent??'',accessible=!!h&&!!text.trim()&&!h.closest('[hidden],[inert],[aria-hidden="true"]')&&!h.querySelector('[hidden],[inert],[aria-hidden="true"]');
  const cardClosed=!document.body.classList.contains('card-open')&&(!s||getComputedStyle(s).display==='none');
  return{ok:accessible&&cardClosed&&!h.classList.contains('sheet-guidance-yield')&&c.display!=='none'&&c.visibility!=='hidden'&&Number(c.opacity)>0&&r.width>1&&r.height>1,accessible,cardClosed,text,attributes:h?.getAttributeNames().sort().map(k=>[k,h.getAttribute(k)]),rect:r?{left:r.left,top:r.top,width:r.width,height:r.height}:null};
}

export function readScrollOwners(selectors=null) {
  const key=n=>{if(n.id)return'#'+CSS.escape(n.id);const parts=[];for(let e=n;e&&e!==document.documentElement;e=e.parentElement){if(e.id){parts.unshift('#'+CSS.escape(e.id));break;}parts.unshift(e.tagName.toLowerCase()+':nth-of-type('+([...e.parentElement.children].filter(x=>x.tagName===e.tagName).indexOf(e)+1)+')');}return parts.join('>');};
  const nodes=selectors?selectors.map(s=>document.querySelector(s)):[...document.querySelectorAll('.panel,#survey,#planetside,#tutcard,.panel *,#survey *,#planetside *')];
  return nodes.filter(Boolean).filter((n,i,a)=>a.indexOf(n)===i).flatMap(n=>{const s=getComputedStyle(n),r=n.getBoundingClientRect();
    if(!selectors&&(!(r.width>0&&r.height>0)||s.display==='none'||!(/auto|scroll/.test(s.overflowX+s.overflowY))||n.scrollWidth<=n.clientWidth+1&&n.scrollHeight<=n.clientHeight+1))return[];
    const point={x:Math.max(0,r.left)+(Math.min(innerWidth,r.right)-Math.max(0,r.left))/2,y:Math.max(0,r.top)+(Math.min(innerHeight,r.bottom)-Math.max(0,r.top))/2},hit=document.elementFromPoint(point.x,point.y);
    return[{selector:key(n),x:n.scrollLeft,y:n.scrollTop,point,hit:!!hit&&(n===hit||n.contains(hit)),style:n.getAttribute('style')}];});
}
