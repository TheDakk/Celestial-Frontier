# Prepared native U4 collector — runtime not executed

`collect.mjs` and `browser-readers.mjs` are new temporary files only. Both final `node --check` commands returned exit0 with empty output; `syntax-review.json` binds those parser checks to their exact hashes. No imports, contract fixture tests, browser, build, canonical run, checkout edit, commit, workflow or hosted action was executed. The older six-file checker bundle and earlier preparation stay unchanged.

The collector requires an admitted **final U3 Inventory checkpoint**, clean `openai/mac` at the exact source, an inherited whole-job toolchain lock, and a fresh output directory. It accepts the actual `cf-u3-normal-build/v1` receipt and verifies its `sourceCommit`, tree, distributable mode, complete recursive file hashes, service-worker assets, successful normal-build stage and terminal checkpoint association. It recognizes the earlier normal-predecessor shape but refuses to substitute it for final U3 admission. Neither qualifying receipt currently exists; example paths are intentionally unfilled.

After root review and final U3 admission, supply the real paths in a new config based on `config.example.json`. Launch the following only as a child of the existing whole-job toolchain-lock wrapper, using approved first-attempt macOS browser execution:

```sh
node /private/tmp/cf-u4-layout-ready-20260906/collector/collect.mjs CONFIG_JSON NEW_OUTPUT_DIRECTORY
```

The driver acquires the additional existing workspace lock. Everything inside the job is sequential. No viewport filtering, parallel browser contexts, renderer retry, resize-restoration loop, navigation normalization or fixture-save path is provided.

## Collected scope

- Exactly the ten current checker viewports, each in default and **native Settings A++/Mono** preferences:20 fresh isolated contexts. All four safe-area values and observed touch points feed the corrected checker's actual input schema. Exact observed inventories and red/restored admission-carrier mutations are retained for each preference.
- Native Training Skip, then Shipyard, Atlas, Compendium, Charters through Objective, Records, Guide, Settings, Inventory, Prime Codex and Notifications. Every panel must contain real rendered body content, open through its actual button, close through its native Close, return focus to its opener and retain the original route. No row is populated by a synthetic model.
- Public Search receives the canonical Earth share code through native input, then trusted Enter selects its Survey. A native Land action opens the actual Surface/Survey/Planetside stack. These explicit route operations affect only the isolated context. No capture, bioscan, share, reward, crafting, equipment or purchase action is invoked.
- The corrected checker reads complete current geometry/44px floors/clipping. Every visible enabled control is then revealed through its measured real scroller as necessary and receives a trusted pointer-move delivery at its full target centre. The actual touch owner is retained for labelled controls. This establishes native pointer reachability, **not gameplay activation**. Open/Close, preferences, Search and Land have separate native click/key/action outcomes. Touch presses use CDP touch; wheels/pointer probes use native mouse events in that same touch-emulated viewport, with no physical swipe claim.
- Fault families are spread across the default viewport rows, with separate compact/wide dock coverage, to keep each context bounded. Every credited fault requires current green geometry, any deferred targets' native reveal, its actual requested red finding, exact styles/DOM restoration, native restoration of original scroll offsets, and successful Close/reopen afterward. Survey/Planetside and painted-toast faults require their actual native states. Missing fault preconditions remain missing; an omitted family prevents scoped collection completion.
- Owned clipped guidance gets independent actual native-capacity arithmetic, including temporary exact class reveal/restore. The proof does not read product `--cf-*` spacing variables or app state hooks. It also requires natural retained guidance after native Close. Class/route alone never discharges a pending proof. Compact toast details retain the checker's headline/detail requirements.
- Per-context JSON, screenshots, raw click/key/pointer/wheel/scroll traces, named evaluation/frame receipts, source/build/tool hashes and the first failure are retained. The global native traces must match delivered press/key inventories exactly. Navigation drift, runtime errors, evidence cap overflow or cleanup failure stop the job; original failures survive cleanup.

The runtime import bridge verifies the old preparation manifest and rewrites only the checker's single relative Glass-contract import to its exact owned source URL. It writes no source file. The add-only checker installer does not install or integrate this collector.

## Still unfilled or unqualified

This driver has been parsed only. Neither its runtime/import wiring nor its live fault recipes have been executed. In particular, the current native CSSOM restoration blocker is still OPEN: the old checker uses its prepared clear-empty/remove strategy and requires exact restoration; this collector does not silently normalize an empty attribute or add a fallback to turn it green. The first real execution may identify a new instrument issue, which must be retained and corrected on new source.

There is no fabricated populated Inventory detail/paperdoll or legacy tab equivalent. Collapsed sub-sections, earned/locked states, populated Shipyard/Compendium/Records models, Combat Chronicle, and other v1 prerequisite states remain separate native-state work. Native transient toast availability is not forced or prolonged; absence leaves its fault incomplete. A run that observes no tight guidance yield cannot claim that yield condition was exercised, even though ordinary guidance was measured.

No 28-screen parity report or terminal gate verifier is supplied. Existing v1 baseline hashes remain authoritative; no image is relabelled as an equivalent to close an unmatched state. `SCOPED_COLLECTION_COMPLETE` means only this declared collection passed its own checks; `u4Gate` always remains `NOT_CLAIMED`. Full U4 additionally needs independently verified complete required state/fault coverage and all28 reviewed pairs with zero unintended differences. Develop-profile integration remains a proposal; no Actions policy or workflow change is included.

Both historical U1 unknown causes remain OPEN. U2 retained REDs remain immutable. This preparation cannot advance U3/U4 ahead of the current U2 checkpoint.
