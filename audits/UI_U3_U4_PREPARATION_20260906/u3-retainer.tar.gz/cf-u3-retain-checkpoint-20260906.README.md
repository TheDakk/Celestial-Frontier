# U3 checkpoint retention helper — prepared, not executed

Helper: `/private/tmp/cf-u3-retain-checkpoint-20260906.py`.

Run only after the selected U3 runner has ended. From the owned repository root:

```sh
python3 /private/tmp/cf-u3-retain-checkpoint-20260906.py PANEL FULL_TESTED_SHA
python3 /private/tmp/cf-u3-retain-checkpoint-20260906.py PANEL FULL_TESTED_SHA --retain
```

The first command inspects terminal receipts and prints the proposed inventory without writing. The second creates exactly one new directory: `audits/UI_U3_PANEL_CHECKPOINT_FULL_TESTED_SHA_20260906`. Existing output is refused. Preparation has not executed either command, run syntax/tests/builds, or opened a browser.

The helper uses the existing U3 runner's one-use `/private/tmp/cf-u3-PANEL-checkpoint-SHORT-20260906` directory and exact `cf-u3-panel-validation-execution/v1` stage order. It retains copied controller/config, hash-bound reviewer, execution and every started stage log, predecessor admission/build receipts, current normal-build receipt and PASS-only next-before, review config/report and PNGs, and exact named phone/Slice reports and Slice log/PNGs. Current normal-review evaluator and native-input traces are embedded in `rows[].evaluations` / `rows[].trace`; preserving the original report preserves those traces. Glass currently writes no PNGs or separate immutable log, so its exact stage log is the log carrier. There is no invented screenshot or extra browser run.

Every non-PNG is gzip-compressed with deterministic mtime; PNG bytes remain raw. Manifest entries carry raw byte count/SHA-256 and stored byte count/SHA-256. Recorded hashes are checked before retention, copied bytes are read back, and original inputs are reread before output is published. An incomplete write leaves its explicitly named `.preparing-PID` directory for review rather than deleting potential evidence. Inputs and ancestors must not be symlinks; unsafe paths, unexpected stages, wrong full source/run IDs, duplicate destinations, changed bindings and partial PASS are refused.

Terminal failure stays RED, with the original failure and per-report verdict. Unstarted stages remain `NOT_RUN`. A started failed stage can lack a named report, retained explicitly as `FAILED_WITHOUT_NAMED_REPORT` / `MISSING_AFTER_TERMINAL_FAILURE`; it is never relabelled unstarted or passing. A normal-review child terminated while its incremental report still says `RUNNING` is retained with that partial status only when the containing execution/stage is terminal failed. Any available unreferenced PNG in a failed dedicated review or exact Slice run is marked as partial evidence without a report hash binding. Passing stages require their named receipts, and passing execution requires the complete ordered chain and next-before identity.

This is retention, not an independent replay of the full Glass/Slice assessors or a new certification. The existing exact named Slice verification log remains evidence of that stage. No Chrome-only verifier is invoked, and RED evidence is not filtered. The helper never follows build inventories to archive dist, normal-dist, dependencies, Git, saves, lock contents, or arbitrary private paths. It retains normal snapshot **receipts**, not a recoverable build archive. Only explicit config-bound reviewer and predecessor receipt paths outside the checkpoint are read.

Review before the first actual U3 run: this package targets the runner and Shipyard review schemas inspected during preparation. A future driver with a changed artifact schema needs an explicit bounded update. If a hash-bound temporary reviewer is edited or removed after its run, retention refuses it; recover the exact original bytes rather than attaching the replacement. Early initialization failures before config/runner bindings can be retained as partial RED, but cannot support a PASS. No physical UAT, U3 completion, hosted action, or release claim follows from retention.
