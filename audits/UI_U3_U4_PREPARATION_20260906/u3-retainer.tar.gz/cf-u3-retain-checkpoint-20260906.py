#!/usr/bin/env python3
"""Prepare/retain one terminal U3 checkpoint. No browser, build, test, or report reclassification."""
from pathlib import Path
import argparse, gzip, hashlib, json, os, re, stat, subprocess

ROOT = Path('/Users/nick/Projects/celestial-frontier-openai-mac')
TEMP = Path('/private/tmp')
PANELS = ['shipyard', 'atlas', 'compendium', 'charters', 'records', 'guide', 'settings', 'survey', 'inventory']
STAGES = ['signature', 'clone', 'root-install', 'v2-install', 'normal-build', 'panel-review',
          'static-develop', 'small-phone', 'large-phone', 'slice', 'slice-verify']
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('panel', choices=PANELS)
parser.add_argument('source', help='full 40-character tested commit')
parser.add_argument('--retain', action='store_true', help='write a new immutable audit directory; default only inspects')
args = parser.parse_args()

def require(ok, message):
    if not ok:
        raise SystemExit('REFUSED: ' + message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def regular(path, boundary):
    path, boundary = Path(path), Path(boundary)
    require(path.is_absolute() and '..' not in path.parts, 'unsafe absolute input path')
    require(path.is_relative_to(boundary), 'input escaped its explicit owner: ' + str(path))
    for part in [path, *path.parents]:
        require(not part.is_symlink(), 'symlink refused: ' + str(part))
    require(path.is_file(), 'missing regular input: ' + str(path))
    return path

def read(path, boundary):
    path = regular(path, boundary)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        require(stat.S_ISREG(os.fstat(fd).st_mode), 'nonregular input changed: ' + str(path))
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            return stream.read()
    finally:
        os.close(fd)

def relative(value):
    require(isinstance(value, str) and value and not Path(value).is_absolute()
            and '..' not in Path(value).parts, 'unsafe relative artifact name')
    return value

require(re.fullmatch('[a-f0-9]{40}', args.source), 'a full lowercase commit is required')
require(Path.cwd().resolve() == ROOT == ROOT.resolve(), 'run from the exact owned physical checkout')
def git(*argv):
    return subprocess.check_output(['git', *argv], cwd=ROOT, text=True).strip()
require(git('rev-parse', '--show-toplevel') == str(ROOT), 'Git root mismatch')
require(git('branch', '--show-current') == 'openai/mac', 'branch mismatch')
require(git('cat-file', '-t', args.source) == 'commit', 'source is not a local commit')
base = TEMP / f'cf-u3-{args.panel}-checkpoint-{args.source[:7]}-20260906'
candidate = base / 'candidate'
output = ROOT / 'audits' / f'UI_U3_{args.panel.upper()}_CHECKPOINT_{args.source}_20260906'
require(not output.exists() and not output.is_symlink(), 'immutable output already exists')
regular(ROOT / 'audits' / 'README.md', ROOT)
inputs, missing, products = {}, [], []

def take(path, name, boundary=base, binding=None, required=True, role='original', missing_status='MISSING_AFTER_TERMINAL_FAILURE'):
    name = relative(name)
    require(name not in inputs, 'duplicate retention destination: ' + name)
    path = Path(path)
    if not path.exists() and not path.is_symlink():
        require(not required, 'required carrier missing: ' + name)
        missing.append({'file': name, 'status': missing_status})
        return None
    raw = read(path, boundary)
    if binding is not None:
        require(binding.get('bytes') == len(raw) and binding.get('sha256') == sha(raw), 'recorded byte/hash mismatch: ' + name)
    if path.suffix.lower() == '.png':
        require(raw.startswith(b'\x89PNG\r\n\x1a\n'), 'invalid PNG carrier: ' + name)
    inputs[name] = {'path': path, 'boundary': boundary, 'raw': raw, 'role': role}
    return raw

execution_raw = take(base / 'execution.json', 'execution/execution.json')
execution = json.loads(execution_raw)
require(execution.get('schema') == 'cf-u3-panel-validation-execution/v1', 'unknown runner schema')
require(execution.get('source') == args.source and execution.get('panel') == args.panel, 'source/panel mismatch')
require(execution.get('ownedWorkspace') == str(ROOT) and execution.get('testArtifact') == str(candidate), 'workspace provenance mismatch')
require(execution.get('status') in ['pass', 'fail'] and execution.get('endedAt'), 'checkpoint is not terminal; do not retain a running attempt')
require(execution.get('hostedActions') == 0, 'unexpected hosted scope')
passed = execution['status'] == 'pass'
require(passed or isinstance(execution.get('failure'), str), 'failed execution lacks its failure')
if execution.get('sourceTree'):
    require(execution['sourceTree'] == git('rev-parse', args.source + '^{tree}'), 'source tree mismatch')
stages = execution.get('stages', [])
require([s.get('name') for s in stages] == STAGES[:len(stages)], 'unknown, duplicate, or out-of-order stages')
require(all(s.get('status') == 'pass' for s in stages[:-1]), 'execution continued after a failed stage')
for stage in stages:
    require(stage.get('status') in ['pass', 'fail'] and stage.get('endedAt'), 'nonterminal stage')
    require(stage.get('log') == stage['name'] + '.log', 'stage log identity mismatch')
    if stage['status'] == 'pass':
        require(stage.get('exitCode') == 0 and not stage.get('signal') and not stage.get('error'), 'inconsistent passing stage')
    take(base / stage['log'], 'execution/' + stage['log'], binding=stage.get('carrier'))
by_stage = {s['name']: s for s in stages}
for name in STAGES[len(stages):]:
    require(not (base / (name + '.log')).exists(), 'unstarted stage has a log: ' + name)
if passed:
    require(len(stages) == len(STAGES) and all(s['status'] == 'pass' for s in stages), 'partial execution cannot pass')

for field, filename in [('runner', 'controller.cjs'), ('config', 'input-config.json')]:
    binding = execution.get(field)
    if binding:
        take(base / filename, 'input/' + filename, binding=binding)
    else:
        require(not stages, 'started execution missing ' + field + ' binding')
        take(base / filename, 'input/' + filename, required=False)
config_raw = inputs.get('input/input-config.json', {}).get('raw')
config = json.loads(config_raw) if config_raw else None
if config:
    require(config.get('panel') == args.panel and config.get('sourceCommit') == args.source, 'config identity mismatch')
    require(config.get('reviewSchema') == f'cf-u3-{args.panel}-normal-review/v1', 'review schema mismatch')
    reviewer_binding = execution.get('reviewer')
    if reviewer_binding:
        reviewer = Path(config['reviewer'])
        require(str(reviewer) == reviewer_binding.get('path') and reviewer.suffix in ['.mjs', '.cjs', '.js'], 'reviewer identity mismatch')
        take(reviewer, 'input/reviewer' + reviewer.suffix, ROOT if reviewer.is_relative_to(ROOT) else TEMP, reviewer_binding)
    else:
        require('panel-review' not in by_stage, 'started review lacks reviewer binding')
    for field, config_key, label in [('beforeBuild', 'buildReceipt', 'build-receipt'), ('beforeAdmission', 'admissionReceipt', 'admission-receipt')]:
        binding = execution.get(field)
        if binding:
            receipt_path = Path(config['before'][config_key])
            require(str(receipt_path) == binding.get('path'), 'predecessor receipt path mismatch')
            raw = take(receipt_path, 'predecessor/' + label + '.json', TEMP, binding)
            receipt = json.loads(raw)
            require(receipt.get('sourceCommit', receipt.get('source')) == config['before']['sourceCommit'], 'predecessor source mismatch')

build_raw = take(base / 'normal-build-receipt.json', 'normal-build/build-receipt.json',
                 binding=execution.get('currentBuild'), required=passed or bool(execution.get('currentBuild')),
                 missing_status='NOT_RUN' if 'normal-build' not in by_stage else 'MISSING_AFTER_TERMINAL_FAILURE')
if build_raw:
    build = json.loads(build_raw)
    require(build.get('schema') == 'cf-u3-normal-build/v1' and build.get('status') == 'pass', 'invalid current build receipt')
    require(build.get('sourceCommit') == args.source and build.get('mode') == 'distributable', 'current build source/mode mismatch')
    require(build.get('directory') == str(base / 'normal-dist'), 'snapshot directory mismatch')
    files = build.get('files', [])
    require(files and len({f['path'] for f in files}) == len(files), 'empty/duplicate snapshot inventory')
    for entry in files:
        relative(entry['path'])
        require(isinstance(entry.get('bytes'), int) and re.fullmatch('[a-f0-9]{64}', entry.get('sha256', '')), 'invalid snapshot byte/hash entry')
next_path = base / 'next-before.json'
require(passed or not next_path.exists(), 'failed attempt published next-before admission')
if passed:
    next_before = json.loads(take(next_path, 'normal-build/next-before.json'))['before']
    require(next_before == {'directory': str(base / 'normal-dist'), 'sourceCommit': args.source,
                           'buildReceipt': str(base / 'normal-build-receipt.json'), 'admissionReceipt': str(base / 'execution.json')}, 'next-before identity mismatch')
if (base / 'review-config.json').exists():
    review_config = json.loads(take(base / 'review-config.json', 'input/review-config.json'))
    require(review_config.get('repository') == str(ROOT) and review_config.get('current', {}).get('sourceCommit') == args.source, 'review config source mismatch')

review = None
if 'panel-review' in by_stage:
    raw = take(base / 'panel-review/report.json', 'normal-review/report.json', binding=execution.get('review'),
               required=by_stage['panel-review']['status'] == 'pass')
    if raw:
        review = json.loads(raw)
        require(review.get('schema') == config['reviewSchema'] and review.get('toolingSource') == args.source, 'normal-review source/schema mismatch')
        require(review.get('status') in ['PASS', 'FAIL', 'RUNNING'], 'unknown normal-review status')
        if review['status'] == 'RUNNING':
            require(not passed and by_stage['panel-review']['status'] == 'fail', 'unfinished review contradicts execution')
        if by_stage['panel-review']['status'] == 'pass':
            require(review['status'] == 'PASS' and len(review.get('rows', [])) == config['expectedReviewRows'], 'review PASS inventory mismatch')
            require(all(r.get('status') == 'PASS' for r in review['rows']) and review.get('runtimeErrors') == [], 'review rows/runtime contradict PASS')
        for row in review.get('rows', []):
            for image in row.get('images', []):
                name = relative(image['file'])
                require(Path(name).name == name and name.endswith('.png'), 'review image must be one PNG leaf')
                take(base / 'panel-review' / name, 'normal-review/' + name, binding=image)
        # Keep any interrupted screenshot write visible, without inventing a report hash binding.
        for path in sorted((base / 'panel-review').glob('*.png')):
            name = 'normal-review/' + path.name
            if name not in inputs:
                require(not passed, 'PASS review has an unreferenced PNG')
                take(path, name, role='unreferenced terminal-failure PNG; no report hash binding')
elif (base / 'panel-review').exists():
    require(False, 'unstarted normal-review has output')

run_ids = execution.get('runIds', {})
prefix = f'local-u3-{args.panel}-{args.source[:7]}-20260906'
expected_ids = {'small': prefix + '-small-phone', 'large': prefix + '-large-phone', 'slice': prefix + '-slice'}
require(not run_ids or run_ids == expected_ids, 'run-ID inventory mismatch')
smoke = candidate / 'port/v2/apps/game/smoke'
for key, stage_name in [('small', 'small-phone'), ('large', 'large-phone'), ('slice', 'slice')]:
    run_id = expected_ids[key]
    filename = ('slice-smoke-' if key == 'slice' else 'glassmatrix-') + run_id + '.json'
    report_path = smoke / filename
    if stage_name not in by_stage:
        require(not report_path.exists(), 'unstarted stage has named report: ' + stage_name)
        products.append({'stage': stage_name, 'status': 'NOT_RUN', 'runId': run_id})
        continue
    require(run_ids == expected_ids, 'started native stage missing exact run IDs')
    stage_pass = by_stage[stage_name]['status'] == 'pass'
    raw = take(report_path, stage_name + '/' + filename, required=stage_pass)
    report = json.loads(raw) if raw else None
    if report:
        schema = 'cf-v2-slice-smoke-ci/v2' if key == 'slice' else 'cf-v2-glassmatrix/v2'
        require(report.get('schema') == schema and report.get('run', {}).get('id') == run_id, 'named report schema/run mismatch')
        require(report['run'].get('artifactPath') == 'apps/game/smoke/' + filename, 'named report path mismatch')
        require(report.get('source', {}).get('commit') == args.source and report['source'].get('branch') == 'openai/mac', 'named report source mismatch')
        require(report.get('terminal') is True and report.get('status') in ['pass', 'fail', 'instrument-fail'], 'named report not terminal')
        if stage_pass:
            require(report['status'] == 'pass' and report.get('sourceEnd') == report['source'] and not report.get('sourceChange', {}).get('detected'), 'report contradicts passing stage')
        products.append({'stage': stage_name, 'status': report['status'], 'runId': run_id,
                         'findings': len(report.get('findings', [])), 'instrumentFailures': len(report.get('instrumentFailures', []))})
    else:
        products.append({'stage': stage_name, 'status': 'FAILED_WITHOUT_NAMED_REPORT', 'runId': run_id})
    if key == 'slice':
        binding = report.get('rawLog') if report else None
        log_name = 'slice-smoke-' + run_id + '.log'
        if binding:
            require(binding.get('path') == 'apps/game/smoke/' + log_name, 'Slice log path mismatch')
        take(smoke / log_name, stage_name + '/' + log_name, binding=binding, required=stage_pass or bool(binding))
        listed = set()
        for image in report.get('screenshots', []) if report else []:
            name = relative(image['name'])
            require(Path(name).name == name and name.startswith('slice-' + run_id + '-') and name.endswith('.png'), 'Slice PNG run identity mismatch')
            require(image.get('path') == 'apps/game/smoke/' + name and name not in listed, 'Slice PNG path/duplicate mismatch')
            listed.add(name)
            take(smoke / name, stage_name + '/' + name, binding=image)
        for path in sorted(smoke.glob('slice-' + run_id + '-*.png')):
            if path.name not in listed:
                require(not stage_pass, 'passing Slice has an unreferenced PNG')
                take(path, stage_name + '/' + path.name, role='unreferenced terminal-failure PNG; no report hash binding')

manifest = {'schema': 'cf-u3-checkpoint-evidence/v1', 'panel': args.panel, 'source': args.source,
            'sourceTree': execution.get('sourceTree'), 'status': 'PASS' if passed else 'RED',
            'executionStatus': execution['status'], 'failure': execution.get('failure'), 'certification': False,
            'stages': [{'name': name, 'status': by_stage[name]['status'] if name in by_stage else 'NOT_RUN'} for name in STAGES],
            'reports': products, 'missingAfterFailure': missing, 'files': [],
            'scope': 'Retention and byte/source/run-ID guards only; original report verdicts remain authority.',
            'traceLocation': 'normal-review/report.json.gz rows[].evaluations and rows[].trace retain original evaluator/native traces.',
            'normalReviewStatus': review.get('status') if review else 'NOT_RUN' if 'panel-review' not in by_stage else 'MISSING_AFTER_TERMINAL_FAILURE',
            'excluded': ['built dist and normal-dist bytes', 'node_modules', '.git', 'saves', 'lock contents', 'unlisted private paths'],
            'glassImages': 'Glass produces no screenshots; exact native stage logs and named JSON reports are retained.'}
carriers = {}
for name, item in sorted(inputs.items()):
    raw = item['raw']; png = name.endswith('.png'); stored_name = name if png else name + '.gz'
    data = raw if png else gzip.compress(raw, mtime=0)
    carriers[stored_name] = data
    manifest['files'].append({'file': stored_name, 'role': item['role'], 'rawBytes': len(raw), 'rawSha256': sha(raw),
                              'bytes': len(data), 'sha256': sha(data), 'encoding': 'raw-png' if png else 'gzip'})
for item in inputs.values():
    require(read(item['path'], item['boundary']) == item['raw'], 'input changed during retention preparation')
if args.retain:
    staging = output.with_name(output.name + '.preparing-' + str(os.getpid()))
    require(not staging.exists() and not staging.is_symlink(), 'staging output already exists')
    staging.mkdir()
    for name, data in carriers.items():
        path = staging / name; path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(data)
        require(path.read_bytes() == data, 'retained carrier read-back mismatch')
    manifest_data = (json.dumps(manifest, indent=2) + '\n').encode()
    with (staging / 'manifest.json').open('xb') as stream:
        stream.write(manifest_data)
    require((staging / 'manifest.json').read_bytes() == manifest_data, 'manifest read-back mismatch')
    for item in inputs.values():
        require(read(item['path'], item['boundary']) == item['raw'], 'input changed before immutable publication')
    require(not output.exists(), 'immutable output appeared during retention')
    staging.rename(output)
print(json.dumps({'mode': 'RETAINED' if args.retain else 'READ_ONLY_INSPECTION', 'output': str(output),
                  'status': manifest['status'], 'carriers': len(carriers), 'missingAfterFailure': missing,
                  'stages': manifest['stages']}, indent=2))
