# Exact apply proposal — parent-owned, not applied

Add one new audit driver only. No product module, shared helper, test or reference
change is proposed by this preparation. Parent owns the U3 source batch and its docs.

- Prepared source: `/private/tmp/cf-u3-shipyard-ready-20260906/review/shipyard-review.mjs`
- Proposed destination: `audits/UI_U3_SHIPYARD_REVIEW_20260906.mjs`
- Required SHA-256: `bbea616df0b7fec9b098406a3d42726ca1065b4e7f2ef7d02c2572709974f140`
- Existing destination: must be absent; never overwrite an earlier driver or evidence.

Copy from the owned checkout only after reviewing this proposal:

```python
from pathlib import Path
from tempfile import NamedTemporaryFile
import hashlib, os
src = Path('/private/tmp/cf-u3-shipyard-ready-20260906/review/shipyard-review.mjs')
dst = Path('/Users/nick/Projects/celestial-frontier-openai-mac/audits/UI_U3_SHIPYARD_REVIEW_20260906.mjs')
data = src.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'bbea616df0b7fec9b098406a3d42726ca1065b4e7f2ef7d02c2572709974f140'
assert not dst.exists()
with NamedTemporaryFile('wb', dir=dst.parent, delete=False) as f:
    f.write(data)
    temporary = f.name
os.replace(temporary, dst)
```

Parent then reviews/checks and commits the adopted driver with the bounded U3 source.
Do not substitute this preparation for a successful check or run.

Fill `config.example.json` with existing exact before/current normal builds and their
existing build receipts. Keep the completed config and a NEW output directory outside
tracked source. After U2 completes, source is clean and committed, and no other toolchain
job holds the lock, the later macOS first-attempt escalation command is:

```text
node tools/with-toolchain-lock.mjs --label U3-shipyard-normal-review -- node audits/UI_U3_SHIPYARD_REVIEW_20260906.mjs /absolute/review-config.json /absolute/NEW-review-output
```

This command is a proposed future action, not executed or authorized to bypass a stop.
Stop on the first nonzero/red/instrument result, retain it, and do not retry unchanged
source. Preserve Inkscape stop, both historical U1 causes and all prior evidence.
