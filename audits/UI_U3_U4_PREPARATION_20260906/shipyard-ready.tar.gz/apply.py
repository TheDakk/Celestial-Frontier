#!/usr/bin/env python3
"""Verify the exact U3 preparation; apply only after the parent admits U2."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--apply', action='store_true', help='Apply all three verified files; default only verifies.')
args = parser.parse_args()
prep = Path(__file__).resolve().parent
manifest = json.loads((prep / 'manifest.json').read_text())
root = Path(manifest['root'])
expected = {
    'port/v2/apps/game/src/engineering-panel.ts',
    'port/v2/apps/game/index.html',
    'port/v2/tests/engineering-panel.test.ts',
}
if platform.system() != 'Darwin' or root.resolve() != root:
    raise SystemExit('Expected the owned physical macOS checkout.')
def git(*words):
    return subprocess.check_output(['git', '-C', str(root), *words], text=True).strip()
if git('rev-parse', '--show-toplevel') != str(root) or git('branch', '--show-current') != manifest['branch']:
    raise SystemExit('Owned root/branch identity mismatch; no files written.')
if git('rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{upstream}') != 'origin/openai/mac':
    raise SystemExit('Owned upstream mismatch; no files written.')
if {entry['path'] for entry in manifest['files']} != expected or len(manifest['files']) != len(expected):
    raise SystemExit('Unexpected or duplicate preparation file inventory.')
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
plans = []
for entry in manifest['files']:
    path = root / entry['path']
    original = path.read_bytes()
    if path.is_symlink() or digest(original) != entry['beforeSha256']:
        raise SystemExit(f"Baseline changed: {entry['path']}; no files written. Refresh preparation explicitly.")
    rebuilt = original.decode('utf-8')
    for edit in entry['edits']:
        if rebuilt.count(edit['before']) != 1:
            raise SystemExit(f"Non-unique source match: {entry['path']}; no files written.")
        rebuilt = rebuilt.replace(edit['before'], edit['after'], 1)
    replacement = rebuilt.encode('utf-8')
    prepared = (prep / entry['path']).read_bytes()
    if replacement != prepared or digest(replacement) != entry['afterSha256']:
        raise SystemExit(f"Prepared bytes differ: {entry['path']}; no files written.")
    plans.append((path, original, replacement))
if not args.apply:
    print(f'VERIFIED {len(plans)} exact prepared files; checkout unchanged. Tests/browser have not run.')
    raise SystemExit(0)
staged = []
try:
    for path, original, replacement in plans:
        temporary = path.with_name(path.name + '.cf-u3-shipyard-prepared.tmp')
        with temporary.open('xb') as output:
            output.write(replacement)
        os.chmod(temporary, path.stat().st_mode & 0o777)
        staged.append((temporary, path))
    # Recheck all sources before the first replacement to reject intervening edits.
    for path, original, _ in plans:
        if path.read_bytes() != original:
            raise SystemExit(f'Intervening change: {path}; no prepared files applied.')
    for temporary, path in staged:
        os.replace(temporary, path)
    print(f'APPLIED {len(plans)} exact prepared files. This is not a verification PASS; run the admitted U3 checks.')
finally:
    for temporary, _ in staged:
        if temporary.exists():
            temporary.unlink()
